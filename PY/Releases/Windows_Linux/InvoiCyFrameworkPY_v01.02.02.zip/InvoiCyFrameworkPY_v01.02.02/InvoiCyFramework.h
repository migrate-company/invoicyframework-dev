/*
 * possolution.h
 *
 *  Created on: Nov 5, 2018
 *      Author: ptesche
 */

#ifndef INVOICYFRAMEWORK_H_
#define INVOICYFRAMEWORK_H_

#ifdef WIN32
#define DECLDIR
#define STDCAL	 __stdcall
#else
#define DECLDIR extern
#define STDCAL
#endif


#ifndef WIN32
extern "C"
{
#endif
/**
* Emitir un documento electrónico o enviar un evento o consulta a InvoiCy
* @param jsonEntrada Datos en formato JSON del documento que se emitirá o enviará a InvoiCy
* @param jsonParametros Datos en formato JSON que contienen los parámetros de envío o consulta
* @return Datos de respuesta de envío/evento/consulta
*/
DECLDIR char * STDCAL InvoiCyFramework_Emitir(char * jsonEntrada, char * jsonParametros);

/**
* Imprime el KuDE del documento informado
* @param xmlDEEmitido XML del documento
* @return Estado de impresión
*/
DECLDIR int STDCAL InvoiCyFramework_ImprimirDE(char * xmlDEEmitido);

/**
* Forzar envío de documentos pendientes
* @return Número entero que indica número de documentos enviados o error. 0 si no hay ningún documento a enviar, un valor mayor a cero indica el número de documentos enviados o -1 en caso de error
*/
DECLDIR int STDCAL InvoiCyFramework_EnviarDocumentosPendientes();

/**
* Obliga a enviar una cantidad específica de documentos pendientes
* @param Número entero que indica el número de documentos a enviar. Si se pasa un valor menor o igual a cero, se enviarán todos los documentos pendientes
* @return Datos de respuesta de envío
*/
DECLDIR char* STDCAL InvoiCyFramework_EnviarDocumentosPendientesCantidad(int cantidad);

/**
* Configura os parâmetros de emissão para o contribuinte estadual
* @param UF N[umero de dois dígitos referente ao código da UF que está sendo configurada
* @param idToken ID referente ao CSC
* @param CSC Código CSC do contribuinte cadastrado na SEFAZ
* @param contingencia Tipo de contingência do NFC-e sendo: 0 = Sem contingência, 1 = contingência offline, 2 = contingência SAT
* @param consultaQRcode URL de consulta do QRCode que será informado no DANFE
* @param consultaChave URL de consulta da chave de acesso do documento que será informado no DANFE
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_InsereParametrosEmissao(int UF, int idToken, char * CSC, int contingencia, char * consultaQRcode, char * consultaChave);


/**
* Envia configurações opcionais relacionadas a UF informada
* @param UF - Código da UF que será configurado
* @param parametro - Nome do parâmetro de configuração
* @param valor - Valor do parâmetro de configuração
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_ConfiguraUF(int UF, char * parametro, char * valor);

/**
* Configurar parámetros de emisión de InvoiCy
* @param RUC - RUC sin formato, solo números
* @param codIntegracion - código de integración ou código de empresa (emp. código)
* @param claveAcceso - Clave de acceso do InvoiCy
* @param clavePartner - Clave de partner
* @return Retorna 1 em caso de sucesso o 0 em caso de error
*/
DECLDIR int STDCAL InvoiCyFramework_ConfigurarInvoicy(char* RUC, char* codIntegracion, char* claveAcceso, char* clavePartner);

/**
* Configurar un parámetro de biblioteca
* @param parametro - Nombre del parámetro
* @param valor - Valor del parámetro
* @return Retorna 1 em caso de sucesso o 0 em caso de error
*/
DECLDIR int STDCAL InvoiCyFramework_Configurar(char* parametro, char* valor);

/**
* Configura el directorio actual que utilizará la biblioteca para almacenar documentos y configuraciones
* @param diretorio - Ruta de directorio
* @return Retorna 1 em caso de sucesso o 0 em caso de error
*/
DECLDIR int STDCAL InvoiCyFramework_ConfigurarDirectorio(char * diretorio);


/**
* Grava um arquivo com o nome e os dados informados no diretorio de trabalho da biblioteca
* @param nome - nome do arquivo
* @param dados - dados do arquivo
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_ArquivoSistema(char * nome, char * dados);


/**
* Alterna entre el modo de producción/homologación
* @param valor - 1 = ambiente de producción / 2 = ambiente de homologación
* @return retorna 1 em caso de sucesso o 0 em caso de error
*/
DECLDIR int STDCAL InvoiCyFramework_AmbienteEmision(int valor);

/**
* Obtiene el número de versión de la biblioteca.
* @return número de versión de la biblioteca
*/
DECLDIR int STDCAL InvoiCyFramework_Version();

/**
* Obtener una lista de todos los documentos aún pendientes de envío
* @return XML que contiene lo informe de documentos pendientes
*/
DECLDIR char * STDCAL InvoiCyFramework_InformePendientes();


/**
* Recupera uma lista de alertas registrados pelo sistema
* @return string no formato XML contendo listagem de alertas
*/
DECLDIR char * STDCAL InvoiCyFramework_Alertas();

/**
* Busca os dados do log da execução atual
* @return Dados do log
*/
DECLDIR char * STDCAL InvoiCyFramework_Log();

/**
* Retorna estado do servico de impressão da biblioteca
* @return 0 = nada ocorrendo / 1 = em impressão
*/
DECLDIR int STDCAL InvoiCyFramework_Servico();


/**
* Busca a data e a hora corrente da UF configurada no InvoiCy
* @param aplicar - indica se a data e hora recebida deve ser aplicada no computador local
* @return string no formato "yyyy-MM-ddTHH:mm:ss"
*/
DECLDIR char * STDCAL InvoiCyFramework_ObtemDataHoraUF(int UF, int aplicar);


/**
* Busca parâmetros configurados no InvoiCy
* @param parametro - identificador do parâmetro desejado
* @return string contendo o valor do parâmetro solicitado
*/
DECLDIR char* STDCAL InvoiCyFramework_ObtemParametro(int identificadorParametro);

/**
* Imprime um texto genérico, utilizando os comandos de layout do framework, ou texto puro
* @param texto - texto a ser impresso
* @return retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_ImprimeTexto(char* texto);

//DECLDIR int STDCAL InvoiCyFramework_ConfiguraDados(char * dadosArquivo);
#ifndef WIN32
}
#endif

#endif /* INVOICYFRAMEWORK_H_ */
