import 'dart:ffi';
import 'dart:io';

import 'excecoes.dart';

/// Resultado de uma carga bem-sucedida: a biblioteca e de onde ela veio.
///
/// Guardar a procedencia importa por causa da atualizacao automatica pai/filho:
/// quando duas InvoiCyFramework podem estar carregadas no mesmo processo,
/// "de onde veio" e a primeira pergunta de qualquer diagnostico.
class BibliotecaCarregada {
  const BibliotecaCarregada(this.biblioteca, this.especificador, this.caminho);

  final DynamicLibrary biblioteca;

  /// A string exatamente como foi passada a `DynamicLibrary.open`.
  ///
  /// **Distinta de [caminho], e a distincao importa.** Reabrir a biblioteca em
  /// outra isolate exige repetir a mesma entrada -- e quando a carga vem do
  /// nome puro (`InvoiCyFramework.dll`), essa entrada NAO e um caminho: e o
  /// nome, com a semantica de deixar o carregador do sistema procurar ao lado
  /// do executavel. Guardar so a forma legivel faria a reabertura falhar
  /// exatamente no caso do app empacotado, que e o caso que importa.
  final String especificador;

  /// Forma legivel, para diagnostico: caminho absoluto quando havia caminho, ou
  /// o nome anotado quando a resolucao ficou por conta do sistema.
  final String caminho;
}

/// Nome do arquivo por plataforma.
String _nomeArquivoNativo() {
  if (Platform.isWindows) {
    return 'InvoiCyFramework.dll';
  }
  if (Platform.isLinux || Platform.isAndroid) {
    return 'libInvoiCyFramework.so';
  }
  throw BibliotecaNativaException(
    'plataforma nao suportada: ${Platform.operatingSystem}. '
    'O SDK cobre Windows, Linux e Android.',
  );
}

/// Caminho, relativo a raiz do pacote, do binario versionado no repositorio.
String? _caminhoNoRepositorio() {
  if (Platform.isWindows) {
    return 'native/windows/x64/InvoiCyFramework.dll';
  }
  if (Platform.isLinux) {
    return 'native/linux/x64/libInvoiCyFramework.so';
  }
  return null;
}

/// Abre a biblioteca nativa, tentando os caminhos em ordem de especificidade.
///
/// A ordem existe porque o binario mora em lugares diferentes conforme o
/// contexto:
///
/// 1. [caminhoExplicito], quando quem chama sabe onde esta;
/// 2. a variavel de ambiente `INVOICY_FRAMEWORK_LIB` -- valvula de escape para
///    diagnostico em campo, sem recompilar nada;
/// 3. o nome puro, que e o caso do app empacotado: o CMake do plugin poe a DLL
///    ao lado do `.exe`, e o carregador do sistema a encontra;
/// 4. o caminho dentro do pacote, que e o caso de `flutter test`.
///
/// No Android nao ha item 4: o `.so` vem do APK e o item 3 resolve.
BibliotecaCarregada abreBibliotecaNativa({String? caminhoExplicito}) {
  final List<String> candidatos = <String>[
    if (caminhoExplicito != null) caminhoExplicito,
    if (Platform.environment['INVOICY_FRAMEWORK_LIB'] != null)
      Platform.environment['INVOICY_FRAMEWORK_LIB']!,
    _nomeArquivoNativo(),
    if (_caminhoNoRepositorio() != null) _caminhoNoRepositorio()!,
  ];

  final List<String> tentados = <String>[];
  Object? ultimoErro;

  for (final String candidato in candidatos) {
    // Resolve para absoluto so para o relato de erro ficar util; a abertura usa
    // o candidato como veio, porque o nome puro tem semantica propria (deixa o
    // carregador do sistema procurar ao lado do executavel).
    final bool pareceCaminho = candidato.contains('/') ||
        candidato.contains(Platform.pathSeparator);
    final String paraRelatar = pareceCaminho
        ? File(candidato).absolute.path
        : '$candidato (resolvido pelo carregador do sistema)';
    tentados.add(paraRelatar);

    try {
      return BibliotecaCarregada(
        DynamicLibrary.open(candidato),
        candidato,
        paraRelatar,
      );
    } catch (erro) {
      // O tipo lancado por DynamicLibrary.open nao e contratual (hoje
      // ArgumentError no Windows). Capturar largo aqui e proposital: a falha
      // real e reportada depois, com a lista de caminhos tentados.
      ultimoErro = erro;
    }
  }

  throw BibliotecaNativaException(
    'nao foi possivel carregar ${_nomeArquivoNativo()}. '
    'Ultimo erro do carregador: $ultimoErro',
    caminhosTentados: tentados,
  );
}
