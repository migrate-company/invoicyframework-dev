package info.migrate.poc_invoicy

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
