library;

import 'package:flutter_test/flutter_test.dart';
import 'package:invoicy_framework/invoicy_framework.dart';

/// Trava a tabela de capacidades por plataforma.
///
/// Ela existe porque o Android nao e uma reimplementacao fiel da ABI: e outro
/// projeto, em Java, que cobre um subconjunto. Esta tabela e a fonte unica
/// consultada pela fachada e pelo POC -- se ela mentir, o SDK mente junto.
///
/// Os testes rodam no desktop, entao verificam a TABELA (o que esta declarado
/// para o Android), nao o comportamento em Android. O comportamento entra na
/// Etapa 5, quando houver ponte.
void main() {
  group('tabela de suporte no Android', () {
    test('as cinco operacoes portaveis tem suporte completo', () {
      // Sao estas que sustentam o POC funcional: se alguma sair da lista, o
      // POC deixa de valer como validacao multiplataforma.
      const List<OperacaoSdk> portaveis = <OperacaoSdk>[
        OperacaoSdk.versao,
        OperacaoSdk.configuraInvoicy,
        OperacaoSdk.ambienteEmissao,
        OperacaoSdk.configura,
        OperacaoSdk.emiteDocumento,
      ];

      for (final OperacaoSdk operacao in portaveis) {
        expect(operacao.android, SuporteAndroid.completo,
            reason: '${operacao.abi} deveria ser portavel');
        expect(operacao.notaAndroid, isNull,
            reason: 'operacao completa nao tem ressalva a declarar');
      }
    });

    test('as degradadas existem no Android, mas com ressalva declarada', () {
      const List<OperacaoSdk> degradadas = <OperacaoSdk>[
        OperacaoSdk.configuraDiretorio,
        OperacaoSdk.arquivoSistema,
      ];

      for (final OperacaoSdk operacao in degradadas) {
        expect(operacao.android, SuporteAndroid.degradado);
        expect(operacao.notaAndroid, isNotNull,
            reason: 'operacao degradada sem explicacao e pior que inutil');
        expect(operacao.notaAndroid, isNotEmpty);
      }
    });

    test('as ausentes estao marcadas como ausentes', () {
      const List<OperacaoSdk> ausentes = <OperacaoSdk>[
        OperacaoSdk.log,
        OperacaoSdk.identidadeModulo,
      ];

      for (final OperacaoSdk operacao in ausentes) {
        expect(operacao.android, SuporteAndroid.ausente);
        expect(operacao.notaAndroid, isNotNull);
      }
    });

    test('toda operacao aponta para uma funcao da ABI', () {
      for (final OperacaoSdk operacao in OperacaoSdk.values) {
        expect(operacao.abi, startsWith('InvoiCyFramework_'),
            reason: 'o nome da ABI e o que permite rastrear ate o C++');
      }
    });
  });

  group('capacidades na plataforma corrente (desktop)', () {
    test('no desktop tudo e completo e disponivel', () {
      // A ABI nativa e a referencia: as restricoes de portabilidade sao do
      // Android.
      for (final OperacaoSdk operacao in OperacaoSdk.values) {
        expect(Capacidades.suporte(operacao), SuporteAndroid.completo);
        expect(Capacidades.disponivel(operacao), isTrue);
      }
    });

    test('so o Log tem ressalva no desktop, e por nao estar implementada', () {
      // Log::conteudoLog() em comum/Log.cpp e um stub que devolve NULL. Nao e
      // problema de portabilidade -- e uma funcao que nao faz nada em lugar
      // nenhum -- e por isso a ressalva dela e geral, nao especifica do
      // Android.
      expect(OperacaoSdk.log.notaGeral, isNotNull);
      expect(Capacidades.ressalva(OperacaoSdk.log), isNotNull);

      for (final OperacaoSdk operacao in OperacaoSdk.values) {
        if (operacao == OperacaoSdk.log) {
          continue;
        }
        expect(operacao.notaGeral, isNull,
            reason: '${operacao.abi} nao deveria ter ressalva geral');
        expect(Capacidades.ressalva(operacao), isNull,
            reason: 'no desktop, so o Log tem ressalva');
      }
    });
  });

  group('Ambiente', () {
    test('os codigos batem com a ABI', () {
      // Trocar 1 e 2 significa emitir em producao achando que e homologacao.
      expect(Ambiente.producao.codigo, 1);
      expect(Ambiente.homologacao.codigo, 2);
    });
  });
}
