# Changelog

## 0.1.0

Primeira versao distribuivel. Uma API Dart, tres plataformas, sem codigo condicional no
aplicativo que consome.

### Plataformas

- **Windows x64** -- `dart:ffi` sobre `InvoiCyFramework.dll`. O CMake do plugin coloca a
  DLL junto do executavel. A DLL e autocontida: nenhum redistribuivel a instalar.
- **Linux x64** -- `dart:ffi` sobre `libInvoiCyFramework.so`, compilada em CentOS 7 para
  alcancar tambem as distribuicoes mais novas. Depende de `libcurl.so.4`,
  `libxml2.so.2`, `libz.so.1` e `libusb-1.0.so.0`; o OpenSSL e estatico.
- **Android (API 24+)** -- `MethodChannel` sobre um shim Java, sobre o AAR
  `info.migrate:invoicyframework-android`. O AAR acompanha o pacote em um repositorio
  Maven em arquivo, entao nao ha repositorio a configurar do lado de quem integra.

### API

- `InvoicyFramework.abre()` -- uma instancia por processo, espelhando a biblioteca, que
  tem estado global.
- **Toda a API e assincrona**, inclusive `versao()`. E o preco de o Android ir por canal
  de plataforma, e o que permite a mesma assinatura nas tres plataformas.
- `configuraInvoicy(ambiente:, cnpj:, chaveAcesso:, chaveParceiro:)` -- o `ambiente` e
  **obrigatorio** e vai primeiro. As credenciais sao gravadas por ambiente; a ordem
  inversa as grava sob o ambiente errado sem produzir erro nenhum. Nesta API a ordem
  errada nao e expressavel.
- `ambienteEmissao`, `configura`, `emiteDocumento`, `configuraDiretorio`,
  `arquivoSistema`, `log`, `identidadeModulo`.
- `emiteDocumento` emite, consulta ou envia evento conforme o **elemento raiz do XML**.
  No desktop roda em isolate separada; no Android, num executor de uma thread. A
  interface nao congela.
- `Ambiente` como enum em vez de `1`/`2` crus.
- Excecoes tipadas -- `BibliotecaNativaException` (com a lista de caminhos tentados),
  `ChamadaNativaException`, `OperacaoNaoSuportadaException` -- em vez de codigos de
  retorno.
- `Capacidades` / `OperacaoSdk` -- o que existe em cada plataforma, consultavel em tempo
  de execucao. Operacao ausente lanca; operacao degradada funciona e carrega a ressalva.

### Codificacao de versao

`versao()` devolve `String` e e a unica representacao tratada como verdade. O inteiro
por tras vem em codificacoes **diferentes** por plataforma -- `15000` no desktop para a
versao 01.50.00, a constante crua no Android -- e cada implementacao decodifica a sua.
`versaoBruta()` existe para diagnostico; nao compare esse numero entre plataformas.

### Fora do escopo desta versao

- `EmiteDocumentoJSON`, por nao existir na fachada Android.
- Impressao, SAT/MFE, relatorios de pendentes, sequenciais e servicos -- as demais
  funcoes das 46 da ABI.
- Apelidos em espanhol e ingles da ABI: a API Dart tem um nome por operacao.
- `InsereParametrosEmissao`, depreciada.
- `AtualizaAgora`, exposta na ABI nativa mas ainda sem ligacao Dart.
- iOS, macOS e web.
