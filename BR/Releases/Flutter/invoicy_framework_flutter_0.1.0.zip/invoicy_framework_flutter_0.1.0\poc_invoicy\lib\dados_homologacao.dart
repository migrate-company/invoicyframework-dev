/// Valores iniciais dos campos do aplicativo de exemplo.
///
/// ============================================================================
///  ATENÇÃO — TROQUE ESTES VALORES ANTES DE USAR
/// ============================================================================
///
/// Os três valores abaixo são de **homologação da Migrate**, e estão aqui só
/// para o aplicativo abrir já preenchido. Eles não emitem nada em seu nome e
/// não servem para produção.
///
///   cnpjInicial            CNPJ de teste da Migrate  -> troque pelo seu
///   chaveAcessoInicial     em branco                 -> preencha com a sua
///   chaveParceiroInicial   chave de teste da Migrate -> troque pela sua
///
/// Você pode trocar de duas formas, e as duas valem:
///
///   1. **Na tela**, a cada execução. Todos os campos são editáveis em tempo
///      de execução, sem recompilar. Bom para um teste rápido.
///   2. **Aqui neste arquivo**, se você for usar o exemplo com frequência e
///      não quiser redigitar. Edite as três constantes e recompile.
///
/// A chave de acesso vem em branco de propósito: é a credencial que de fato
/// autentica, então ela nunca entra no código. Sem preenchê-la, a chamada a
/// `configuraInvoicy` vai falhar com erro de autenticação — o que é o
/// comportamento desejado, e o lembrete de que os outros dois valores também
/// precisam ser os seus.
///
/// Se você emitir em homologação com o CNPJ da Migrate, os documentos vão
/// aparecer na conta de teste **dela**, não na sua. É o motivo prático de
/// trocar, além do óbvio.
///
/// ============================================================================
library;

import 'dart:io';

/// CNPJ do contribuinte, só dígitos.
const String cnpjInicial = '06354976000149';

/// Chave de acesso do invoiCy.
///
/// Deixada em branco de propósito: é a credencial que de fato autentica, e a
/// única que não entra no repositório. Preencha o campo na tela do POC.
const String chaveAcessoInicial = 'informe_sua_chave_de_acesso';

/// Chave do parceiro, para identificação pelo invoiCy.
const String chaveParceiroInicial = 'YPxRwGxIbpWZtwhuC0m+Wg==';

/// XML de entrada da consulta de NFC-e.
///
/// **É o elemento raiz deste XML que decide a operação**, não o parâmetro:
/// `DocumentoGeral.cpp` inspeciona o nó raiz e roteia `<Consulta>` para
/// consulta, `<Documento>` para emissão, `<Evento>` para cancelamento.
///
/// Dentro de `<Consulta>`, os filtros decidem o subtipo: com número, série,
/// chave ou data preenchidos vira `DocConsultaDocumento`; com todos zerados
/// vira `DocConsultaInvoiCy`.
const String xmlEntradaInicial = '''
<Consulta>
	<ModeloDocumento>NFCe</ModeloDocumento>
	<Versao>4.00</Versao>
	<tpAmb>2</tpAmb>
	<CnpjEmissor>06354976000149</CnpjEmissor>
	<NumeroInicial>457237</NumeroInicial>
	<NumeroFinal>457242</NumeroFinal>
	<Serie>133</Serie>
	<ChaveAcesso>13323424232423424252</ChaveAcesso>
	<DataEmissaoInicial>0000-00-00T00:00:00</DataEmissaoInicial>
	<DataEmissaoFinal>0000-00-00T00:00:00</DataEmissaoFinal>
</Consulta>
''';

/// XML de parâmetros. Vazio: nesta consulta não é necessário.
const String xmlParametroInicial = '';

/// Parâmetro inicial do `Configura`.
///
/// Vazio de propósito. O `Configura` aceita as chaves de configuração do C++
/// (AMBIENTE, FRAMEWORK_LITE, EMITIR_SAT, IMPRESSORA_PADRAO, LOG_NIVEL e
/// outras), e qual delas testar depende do que se quer investigar — preencher
/// um valor arbitrário aqui mudaria o comportamento da biblioteca sem que
/// ninguém tivesse pedido.
const String parametroInicial = '';

/// Valor inicial do `Configura`.
const String valorParametroInicial = '';

/// Diretório de trabalho inicial do `ConfiguraDiretorio`.
const String diretorioWindowsInicial = r'C:\migrate\invoicyfw';

/// Equivalente para quando o POC rodar fora do Windows (Etapa 4).
const String diretorioPosixInicial = '/migrate/invoicyfw';

/// O diretório inicial da plataforma corrente.
///
/// Existe como getter, e não como constante única, para o POC não levar um
/// caminho do Windows para dentro do Linux na Etapa 4 — e vice-versa.
String get diretorioInicial =>
    Platform.isWindows ? diretorioWindowsInicial : diretorioPosixInicial;

/// Nome do arquivo da aferição de UTF-8.
///
/// A acentuação agora é exercitada por aqui e pelo conteúdo, já que o diretório
/// padrão deixou de ter acento no nome. A cobertura automatizada continua
/// intacta: o teste em `invoicy_framework/test/trilho_ffi_test.dart` roda com o
/// diretório corrente apontado para uma pasta temporária acentuada.
const String nomeArquivoInicial = 'aferição_de_codificação.txt';

/// Conteúdo da aferição de UTF-8 — acentos, cedilha, ordinal e travessão.
const String conteudoArquivoInicial =
    'Razão Social: JOSÉ AÇÚCAR & CIA LTDA\n'
    'Endereço: Travessa São João, 1º andar — Belém/PA\n'
    'Observação: ção, ções, ãe, õe, ü, ñ, ç';
