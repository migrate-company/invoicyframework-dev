import 'package:flutter/services.dart';

import 'ambiente.dart';
import 'capacidades.dart';
import 'excecoes.dart';
import 'identidade_modulo.dart';
import 'plataforma.dart';
import 'versao.dart';

/// Implementacao para Android, sobre a fachada Java do AAR via MethodChannel.
///
/// O shim Java roda tudo num executor de uma thread, o que reproduz no Android
/// a serializacao que os mutexes internos garantem no nativo -- o contrato de
/// concorrencia do SDK vale igual nas tres plataformas.
class ImplCanal implements ImplPlataforma {
  ImplCanal();

  static const String nomeCanal = 'info.migrate/invoicy_framework';

  static const MethodChannel _canal = MethodChannel(nomeCanal);

  @override
  String get descricao => 'MethodChannel $nomeCanal → AAR '
      'com.migrate.gerentedocumento.InvoiCyFramework';

  /// Traduz o erro da plataforma numa excecao do SDK.
  Future<T> _chama<T>(String metodo, [Map<String, Object?>? argumentos]) async {
    try {
      final T? retorno = await _canal.invokeMethod<T>(metodo, argumentos);
      if (retorno == null && T != Null) {
        throw ChamadaNativaException(
          funcao: metodo,
          codigo: 0,
          detalhe: 'o canal devolveu nulo',
        );
      }
      return retorno as T;
    } on MissingPluginException {
      throw OperacaoNaoSuportadaException(
        operacao: metodo,
        plataforma: Capacidades.plataforma,
        alternativa: 'a fachada Java do AAR nao implementa esta operacao',
      );
    } on PlatformException catch (erro) {
      throw ChamadaNativaException(
        funcao: metodo,
        codigo: 0,
        detalhe: '${erro.message} (${erro.details})',
      );
    }
  }

  @override
  Future<int> versaoBruta() => _chama<int>('versao');

  /// **No Android o retorno de `Versao()` e a constante CRUA**
  /// (`ContextoAplicativo.versaoInt()` devolve `0x014015` direto), e nao o
  /// `atoi(sprintf("%lx", ...))` do desktop. Mesma funcao, codificacao
  /// diferente -- decodificar com a regra do desktop daria "08.60.37" para a
  /// versao 01.40.15.
  @override
  String formataVersao(int bruto) => versaoDeConstanteCrua(bruto);

  @override
  Future<void> configuraInvoicy({
    required Ambiente ambiente,
    required String cnpj,
    required String chaveAcesso,
    required String chaveParceiro,
  }) =>
      // O shim faz AmbienteEmissao antes de ConfiguraInvoicy, como no desktop.
      _chama<void>('configuraInvoicy', <String, Object?>{
        'ambiente': ambiente.codigo,
        'cnpj': cnpj,
        'chaveAcesso': chaveAcesso,
        'chaveParceiro': chaveParceiro,
      });

  @override
  Future<void> ambienteEmissao(Ambiente ambiente) =>
      _chama<void>('ambienteEmissao', <String, Object?>{
        'ambiente': ambiente.codigo,
      });

  @override
  Future<void> configura(String parametro, String valor) =>
      _chama<void>('configura', <String, Object?>{
        'parametro': parametro,
        'valor': valor,
      });

  @override
  Future<String> emiteDocumento(String xmlEntrada, String xmlParametro) =>
      _chama<String>('emiteDocumento', <String, Object?>{
        'xmlEntrada': xmlEntrada,
        'xmlParametro': xmlParametro,
      });

  /// Existe, **mas nao tem efeito**: a fachada Java apenas registra no log.
  /// Chamamos de qualquer forma, para o comportamento ser o da biblioteca e nao
  /// uma invencao nossa. Quem avisa e `Capacidades.ressalva`.
  @override
  Future<void> configuraDiretorio(String diretorio) =>
      _chama<void>('configuraDiretorio', <String, Object?>{
        'diretorio': diretorio,
      });

  /// Grava no **diretorio padrao da biblioteca**, nao no configurado -- o
  /// caminho final nao e previsivel do lado Dart.
  @override
  Future<void> arquivoSistema(String nome, String dados) =>
      _chama<void>('arquivoSistema', <String, Object?>{
        'nome': nome,
        'dados': dados,
      });

  @override
  Future<String> log() async => throw OperacaoNaoSuportadaException(
        operacao: 'InvoiCyFramework_Log',
        plataforma: Capacidades.plataforma,
        alternativa: 'nao existe na fachada Java',
      );

  @override
  Future<IdentidadeModulo> identidadeModulo() async =>
      throw OperacaoNaoSuportadaException(
        operacao: 'InvoiCyFramework_GetModuleIdentity',
        plataforma: Capacidades.plataforma,
        alternativa: 'nao existe na fachada Java, e nao ha o que reportar: a '
            'atualizacao pai/filho e exclusiva do binario nativo',
      );

  @override
  void descarta() {
    // A instancia Java vive no plugin, atrelada ao engine. Nada a liberar aqui.
  }
}
