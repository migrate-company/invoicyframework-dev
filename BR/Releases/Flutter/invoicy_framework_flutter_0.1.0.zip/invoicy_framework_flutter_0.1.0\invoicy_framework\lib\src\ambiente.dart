/// Ambiente de emissao, em vez do inteiro cru da ABI.
///
/// `AmbienteEmissao` aceita 1 e 2, e trocar os dois numeros significa emitir em
/// producao achando que se esta em homologacao. Um enum custa nada e torna esse
/// erro impossivel.
enum Ambiente {
  producao(1),
  homologacao(2);

  const Ambiente(this.codigo);

  /// Valor esperado pela ABI.
  final int codigo;
}
