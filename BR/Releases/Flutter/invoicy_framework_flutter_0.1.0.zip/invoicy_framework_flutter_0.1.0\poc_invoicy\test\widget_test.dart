import 'package:flutter_test/flutter_test.dart';
import 'package:poc_invoicy/main.dart';

/// Teste de fumaça: garante que a tela monta.
///
/// Em `flutter test` a biblioteca nativa não está ao lado do runner, então a
/// carga falha e o app mostra o cartão de erro — comportamento correto, e o que
/// este teste verifica. A validação real do trilho está em
/// `invoicy_framework/test/`.
void main() {
  testWidgets('a tela monta mesmo sem a biblioteca nativa disponível',
      (WidgetTester tester) async {
    await tester.pumpWidget(const AppPoc());
    await tester.pump();

    expect(find.text('InvoiCyFramework · POC'), findsOneWidget);
    expect(find.text('Operações portáveis'), findsOneWidget);
    expect(find.text('Diagnóstico'), findsOneWidget);
  });
}
