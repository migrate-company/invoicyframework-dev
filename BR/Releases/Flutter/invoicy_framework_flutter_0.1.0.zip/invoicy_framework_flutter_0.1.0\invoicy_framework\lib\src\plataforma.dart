import 'ambiente.dart';
import 'identidade_modulo.dart';

/// O que cada plataforma tem de saber fazer.
///
/// **Tudo aqui e assincrono, inclusive o que no desktop seria instantaneo.** Nao
/// e uniformidade decorativa: no Android o caminho e um MethodChannel, e canal
/// de plataforma no Flutter nao tem versao sincrona. Ou a API publica e
/// assincrona nas tres plataformas, ou ela tem formas diferentes por plataforma
/// -- e nesse caso o ERP volta a ter codigo condicional, que e exatamente o que
/// este SDK existe para evitar.
///
/// A decodificacao de versao tambem e responsabilidade da implementacao, e nao
/// da fachada: `Versao()` devolve codificacoes DIFERENTES no desktop e no
/// Android (ver versao.dart).
abstract interface class ImplPlataforma {
  /// Como esta ligado, para diagnostico. No desktop e o caminho da biblioteca;
  /// no Android, o nome do canal.
  String get descricao;

  /// Retorno cru de `Versao()`. A codificacao varia por plataforma.
  Future<int> versaoBruta();

  /// Converte o retorno de [versaoBruta] em texto, com a regra desta
  /// plataforma.
  String formataVersao(int bruto);

  Future<void> configuraInvoicy({
    required Ambiente ambiente,
    required String cnpj,
    required String chaveAcesso,
    required String chaveParceiro,
  });

  Future<void> ambienteEmissao(Ambiente ambiente);

  Future<void> configura(String parametro, String valor);

  Future<String> emiteDocumento(String xmlEntrada, String xmlParametro);

  Future<void> configuraDiretorio(String diretorio);

  Future<void> arquivoSistema(String nome, String dados);

  Future<String> log();

  Future<IdentidadeModulo> identidadeModulo();

  /// Libera o que a implementacao segurava. Nao finaliza a biblioteca nativa.
  void descarta();
}
