import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:invoicy_framework/invoicy_framework.dart';

import 'dados_homologacao.dart';

/// POC do SDK InvoiCyFramework.
///
/// A tela é organizada por **operação**: cada função da ABI ganha um bloco com
/// o seu botão e, logo abaixo, os campos que ela recebe. Nada é fixo em tempo
/// de compilação — tudo se edita com o app rodando, que é o que faz deste um
/// instrumento e não uma demonstração.
///
/// Os blocos vêm em dois grupos, e a divisão é proposital:
///
/// - **Portáveis** — existem no Windows, no Linux e no Android com a mesma
///   semântica. É o que continuará valendo quando o Android entrar.
/// - **Diagnóstico** — específicas do binário nativo. Ausentes ou degradadas no
///   Android; os botões consultam `Capacidades` e se ajustam sozinhos.
void main() {
  runApp(const AppPoc());
}

class AppPoc extends StatelessWidget {
  const AppPoc({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'InvoiCyFramework · POC',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.system,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF00695C),
        brightness: Brightness.light,
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorSchemeSeed: const Color(0xFF00695C),
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: const TelaPoc(),
    );
  }
}

/// Uma operação executada, com o que devolveu e quanto levou.
class Evento {
  Evento({
    required this.rotulo,
    required this.sucesso,
    required this.detalhe,
    required this.duracao,
  }) : instante = DateTime.now();

  final String rotulo;
  final bool sucesso;
  final String detalhe;
  final Duration duracao;
  final DateTime instante;

  String get horario => '${instante.hour.toString().padLeft(2, '0')}:'
      '${instante.minute.toString().padLeft(2, '0')}:'
      '${instante.second.toString().padLeft(2, '0')}';

  String get tempo => duracao.inMilliseconds >= 1
      ? '${duracao.inMilliseconds} ms'
      : '${duracao.inMicroseconds} µs';
}

class TelaPoc extends StatefulWidget {
  const TelaPoc({super.key});

  @override
  State<TelaPoc> createState() => _TelaPocState();
}

class _TelaPocState extends State<TelaPoc> {
  InvoicyFramework? _ifw;
  Object? _falhaDeCarga;
  IdentidadeModulo? _identidade;
  int? _versaoBruta;
  String? _versaoTexto;
  bool _ocupado = false;
  final List<Evento> _eventos = <Evento>[];

  Ambiente _ambiente = Ambiente.homologacao;

  final TextEditingController _cnpj =
      TextEditingController(text: cnpjInicial);
  final TextEditingController _chaveAcesso =
      TextEditingController(text: chaveAcessoInicial);
  final TextEditingController _chaveParceiro =
      TextEditingController(text: chaveParceiroInicial);
  final TextEditingController _parametro =
      TextEditingController(text: parametroInicial);
  final TextEditingController _valorParametro =
      TextEditingController(text: valorParametroInicial);
  final TextEditingController _xmlEntrada =
      TextEditingController(text: xmlEntradaInicial.trim());
  final TextEditingController _xmlParametro =
      TextEditingController(text: xmlParametroInicial);
  final TextEditingController _diretorio =
      TextEditingController(text: diretorioInicial);
  final TextEditingController _nomeArquivo =
      TextEditingController(text: nomeArquivoInicial);
  final TextEditingController _conteudoArquivo =
      TextEditingController(text: conteudoArquivoInicial);

  @override
  void initState() {
    super.initState();
    _carrega();
  }

  @override
  void dispose() {
    for (final TextEditingController c in <TextEditingController>[
      _cnpj,
      _chaveAcesso,
      _chaveParceiro,
      _parametro,
      _valorParametro,
      _xmlEntrada,
      _xmlParametro,
      _diretorio,
      _nomeArquivo,
      _conteudoArquivo,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _carrega() async {
    final Stopwatch cronometro = Stopwatch()..start();
    try {
      final InvoicyFramework ifw = await InvoicyFramework.abre();
      final int bruta = await ifw.versaoBruta();
      final String texto = await ifw.versao();
      final IdentidadeModulo? identidade =
          Capacidades.disponivel(OperacaoSdk.identidadeModulo)
              ? await ifw.identidadeModulo()
              : null;
      cronometro.stop();
      if (!mounted) {
        return;
      }
      setState(() {
        _ifw = ifw;
        _falhaDeCarga = null;
        _versaoBruta = bruta;
        _versaoTexto = texto;
        _identidade = identidade;
        _registra(Evento(
          rotulo: 'Carga da biblioteca',
          sucesso: true,
          detalhe: ifw.comoEstaLigado,
          duracao: cronometro.elapsed,
        ));
      });
    } catch (erro) {
      cronometro.stop();
      if (!mounted) {
        return;
      }
      setState(() {
        _ifw = null;
        _falhaDeCarga = erro;
        _registra(Evento(
          rotulo: 'Carga da biblioteca',
          sucesso: false,
          detalhe: erro.toString(),
          duracao: cronometro.elapsed,
        ));
      });
    }
  }

  void _registra(Evento evento) => _eventos.insert(0, evento);

  /// Executa uma operação do SDK, cronometra e registra o desfecho.
  ///
  /// Há um só executor porque a API do SDK é inteiramente assíncrona nas três
  /// plataformas — no Android o caminho é um MethodChannel, que não tem versão
  /// síncrona, e ter formas diferentes por plataforma devolveria ao ERP o
  /// código condicional que o SDK existe para eliminar.
  Future<void> _executa(
    String rotulo,
    Future<String> Function(InvoicyFramework ifw) acao,
  ) async {
    final InvoicyFramework? ifw = _ifw;
    if (ifw == null || _ocupado) {
      return;
    }
    setState(() => _ocupado = true);

    final Stopwatch cronometro = Stopwatch()..start();
    String detalhe;
    bool sucesso;
    try {
      detalhe = await acao(ifw);
      sucesso = true;
    } catch (erro) {
      detalhe = erro.toString();
      sucesso = false;
    }
    cronometro.stop();

    if (!mounted) {
      return;
    }
    setState(() {
      _ocupado = false;
      _registra(Evento(
        rotulo: rotulo,
        sucesso: sucesso,
        detalhe: detalhe,
        duracao: cronometro.elapsed,
      ));
    });
  }

  void _copiaDiagnostico() {
    final StringBuffer texto = StringBuffer()
      ..writeln('DIAGNÓSTICO — SDK InvoiCyFramework')
      ..writeln('Gerado em ${DateTime.now()}')
      ..writeln('Plataforma: ${Platform.operatingSystem} '
          '${Platform.operatingSystemVersion}')
      ..writeln('Dart: ${Platform.version}')
      ..writeln();

    if (_falhaDeCarga != null) {
      texto
        ..writeln('FALHA NA CARGA:')
        ..writeln(_falhaDeCarga.toString());
    } else {
      texto
        ..writeln('Ligação: ${_ifw?.comoEstaLigado}')
        ..writeln('Versão: $_versaoTexto  (bruta = $_versaoBruta)')
        ..writeln('Identidade: ${_identidade?.jsonBruto ?? "(indisponível)"}');
    }

    texto
      ..writeln()
      ..writeln('HISTÓRICO:');
    for (final Evento e in _eventos.reversed) {
      texto.writeln('[${e.horario}] ${e.sucesso ? "ok  " : "ERRO"} '
          '${e.rotulo} (${e.tempo})\n    ${e.detalhe}');
    }

    Clipboard.setData(ClipboardData(text: texto.toString()));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Diagnóstico copiado')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool livre = _ifw != null && !_ocupado;

    return Scaffold(
      appBar: AppBar(
        title: const Text('InvoiCyFramework · POC'),
        bottom: _ocupado
            ? const PreferredSize(
                preferredSize: Size.fromHeight(4),
                child: LinearProgressIndicator(),
              )
            : null,
        actions: <Widget>[
          IconButton(
            onPressed: _copiaDiagnostico,
            icon: const Icon(Icons.copy_all_outlined),
            tooltip: 'Copiar diagnóstico',
          ),
          IconButton(
            onPressed: _ocupado
                ? null
                : () {
                    InvoicyFramework.descartaInstancia();
                    _carrega();
                  },
            icon: const Icon(Icons.refresh),
            tooltip: 'Recarregar a biblioteca',
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: <Widget>[
          if (_falhaDeCarga != null)
            _CartaoFalha(falha: _falhaDeCarga!)
          else
            _CartaoIdentidade(
              identidade: _identidade,
              versao: _versaoTexto ?? '?',
              versaoBruta: _versaoBruta,
              ligacao: _ifw?.comoEstaLigado ?? '?',
            ),

          const _TituloGrupo(
            titulo: 'Operações portáveis',
            subtitulo: 'Existem no Windows, no Linux e no Android com a mesma '
                'semântica. É o que sustenta o SDK como multiplataforma.',
            selo: '3 plataformas',
          ),

          _Operacao(
            operacao: OperacaoSdk.versao,
            rotulo: 'Versao()',
            icone: Icons.numbers,
            primaria: true,
            habilitado: livre,
            descricao: 'Sem parâmetros. Devolve 15000 para a versão 01.50.00 — '
                'os dígitos decimais do retorno são os hexadecimais da '
                'constante interna.',
            aoTocar: () => _executa(
              'Versao',
              (InvoicyFramework ifw) async =>
                  '${await ifw.versao()}   (bruta = ${await ifw.versaoBruta()})',
            ),
          ),

          _Operacao(
            operacao: OperacaoSdk.configuraInvoicy,
            rotulo: 'ConfiguraInvoicy()',
            icone: Icons.key_outlined,
            primaria: true,
            habilitado: livre,
            descricao: 'O ambiente vai junto porque as credenciais são gravadas '
                'POR ambiente: o SDK chama AmbienteEmissao antes, e a ordem '
                'errada não é expressável.',
            campos: <Widget>[
              _SeletorAmbiente(
                ambiente: _ambiente,
                aoMudar: (Ambiente novo) => setState(() => _ambiente = novo),
              ),
              _Campo(rotulo: 'CNPJ (só dígitos)', controlador: _cnpj),
              _Campo(rotulo: 'Chave de acesso', controlador: _chaveAcesso),
              _Campo(rotulo: 'Chave do parceiro', controlador: _chaveParceiro),
            ],
            aoTocar: () => _executa(
              'ConfiguraInvoicy',
              (InvoicyFramework ifw) async {
                await ifw.configuraInvoicy(
                  ambiente: _ambiente,
                  cnpj: _cnpj.text.trim(),
                  chaveAcesso: _chaveAcesso.text.trim(),
                  chaveParceiro: _chaveParceiro.text.trim(),
                );
                return 'CNPJ ${_cnpj.text.trim()} · '
                    '${_ambiente.name} (tpAmb=${_ambiente.codigo})';
              },
            ),
          ),

          _Operacao(
            operacao: OperacaoSdk.configura,
            rotulo: 'Configura()',
            icone: Icons.tune,
            primaria: true,
            habilitado: livre,
            descricao: 'Parâmetro genérico da biblioteca, por nome. Os nomes '
                'válidos são as chaves de configuração do C++ — AMBIENTE, '
                'FRAMEWORK_LITE, EMITIR_SAT, IMPRESSORA_PADRAO, LOG_NIVEL e '
                'outras. Preencha conforme o que quiser testar.',
            campos: <Widget>[
              _Campo(rotulo: 'Parâmetro', controlador: _parametro),
              _Campo(rotulo: 'Valor', controlador: _valorParametro),
            ],
            aoTocar: () => _executa(
              'Configura',
              (InvoicyFramework ifw) async {
                await ifw.configura(
                  _parametro.text.trim(),
                  _valorParametro.text.trim(),
                );
                return '${_parametro.text.trim()} = '
                    '${_valorParametro.text.trim()}';
              },
            ),
          ),

          _Operacao(
            operacao: OperacaoSdk.emiteDocumento,
            rotulo: 'EmiteDocumento()  ·  consulta',
            icone: Icons.search,
            primaria: true,
            habilitado: livre,
            descricao: 'Roda em isolate separada — a janela continua '
                'respondendo enquanto a rede trabalha. O elemento raiz do XML '
                'de entrada decide a operação.',
            campos: <Widget>[
              _Campo(
                rotulo: 'XML de entrada — a raiz decide a operação '
                    '(<Consulta>, <Documento>, <Evento>…)',
                controlador: _xmlEntrada,
                linhas: 8,
              ),
              _Campo(
                rotulo: 'XML de parâmetros (opcional)',
                controlador: _xmlParametro,
                linhas: 3,
              ),
            ],
            aoTocar: () => _executa(
              'EmiteDocumento (consulta)',
              (InvoicyFramework ifw) => ifw.emiteDocumento(
                _xmlEntrada.text,
                xmlParametro: _xmlParametro.text,
              ),
            ),
          ),

          const _TituloGrupo(
            titulo: 'Diagnóstico',
            subtitulo: 'Operações do binário nativo. Ausentes ou degradadas no '
                'Android — os botões se ajustam sozinhos conforme a plataforma.',
          ),

          _Operacao(
            operacao: OperacaoSdk.configuraDiretorio,
            rotulo: 'ConfiguraDiretorio()',
            icone: Icons.folder_open,
            habilitado: livre,
            descricao: 'O diretório é criado se não existir. A função nativa '
                'devolve 1 sempre, sem validar nada — a validação real é do '
                'lado Dart.',
            campos: <Widget>[
              _Campo(rotulo: 'Diretório de trabalho', controlador: _diretorio),
            ],
            aoTocar: () => _executa(
              'ConfiguraDiretorio',
              (InvoicyFramework ifw) async {
                final Directory destino = Directory(_diretorio.text.trim())
                  ..createSync(recursive: true);
                await ifw.configuraDiretorio(destino.path);
                return destino.path;
              },
            ),
          ),

          _Operacao(
            operacao: OperacaoSdk.arquivoSistema,
            rotulo: 'ArquivoSistema()  ·  aferir UTF-8',
            icone: Icons.spellcheck,
            habilitado: livre,
            descricao: 'Configura o diretório acima, grava o arquivo via '
                r'$BASEDIR/, lê de volta em Dart e compara byte a byte. Prova a '
                'codificação nos dois sentidos e o efeito real do '
                'ConfiguraDiretorio.',
            campos: <Widget>[
              _Campo(rotulo: 'Nome do arquivo', controlador: _nomeArquivo),
              _Campo(
                rotulo: 'Conteúdo',
                controlador: _conteudoArquivo,
                linhas: 4,
              ),
            ],
            aoTocar: () => _executa(
              'ArquivoSistema (aferição de UTF-8)',
              (InvoicyFramework ifw) async {
                final String nome = _nomeArquivo.text.trim();
                final String conteudo = _conteudoArquivo.text;

                final Directory destino = Directory(_diretorio.text.trim())
                  ..createSync(recursive: true);
                await ifw.configuraDiretorio(destino.path);
                await ifw.arquivoSistema('\$BASEDIR/$nome', conteudo);

                final File gravado =
                    File('${destino.path}${Platform.pathSeparator}$nome');
                if (!gravado.existsSync()) {
                  throw StateError(
                      'o arquivo não apareceu em ${destino.path} — ou o nome '
                      'se corrompeu, ou ConfiguraDiretorio não teve efeito. '
                      'Conteúdo do destino: '
                      '${destino.listSync().map((FileSystemEntity e) => e.path).toList()}');
                }
                if (gravado.readAsStringSync() != conteudo) {
                  throw StateError('o conteúdo voltou diferente do enviado — '
                      'a fronteira não está em UTF-8');
                }
                return 'íntegro: ${gravado.path}';
              },
            ),
          ),

          _Operacao(
            operacao: OperacaoSdk.identidadeModulo,
            rotulo: 'GetModuleIdentity()',
            icone: Icons.fingerprint,
            habilitado: livre,
            descricao: 'Sem parâmetros. Diz qual binário atendeu — a primeira '
                'pergunta de qualquer diagnóstico quando há atualização '
                'pai/filho.',
            aoTocar: () => _executa(
              'GetModuleIdentity',
              (InvoicyFramework ifw) async =>
                  (await ifw.identidadeModulo()).jsonBruto,
            ),
          ),

          _Operacao(
            operacao: OperacaoSdk.log,
            rotulo: 'Log()',
            icone: Icons.article_outlined,
            habilitado: livre,
            descricao: 'Sem parâmetros, e devolve SEMPRE vazio: '
                'Log::conteudoLog() no C++ é um stub que retorna NULL, em '
                'todas as plataformas. O botão fica aqui por completude da '
                'ABI.',
            aoTocar: () => _executa(
              'Log',
              (InvoicyFramework ifw) async {
                final String registro = await ifw.log();
                return registro.isEmpty
                    ? '(vazio, como esperado — Log::conteudoLog() é um stub '
                        'que devolve NULL em Log.cpp)'
                    : registro;
              },
            ),
          ),

          const SizedBox(height: 24),
          Text('Histórico', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (_eventos.isEmpty)
            const Text('Nenhuma operação executada ainda.'),
          for (final Evento e in _eventos) _LinhaEvento(evento: e),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Componentes
// ---------------------------------------------------------------------------

class _TituloGrupo extends StatelessWidget {
  const _TituloGrupo({
    required this.titulo,
    required this.subtitulo,
    this.selo,
  });

  final String titulo;
  final String subtitulo;
  final String? selo;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 28, bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Text(titulo, style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(width: 12),
              if (selo != null)
                Chip(
                  label: Text(selo!),
                  visualDensity: VisualDensity.compact,
                ),
            ],
          ),
          const SizedBox(height: 4),
          Text(subtitulo, style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }
}

/// Um bloco de operação: o botão em cima, os campos que ela recebe abaixo.
///
/// O botão sabe se a operação existe na plataforma corrente — é o
/// `Capacidades` em forma de widget. Em vez de o ERP descobrir no clique que a
/// função não existe, o botão já vem desabilitado com a explicação no tooltip,
/// e operação degradada mostra o aviso sem impedir a chamada.
class _Operacao extends StatelessWidget {
  const _Operacao({
    required this.operacao,
    required this.rotulo,
    required this.icone,
    required this.habilitado,
    required this.aoTocar,
    required this.descricao,
    this.campos = const <Widget>[],
    this.primaria = false,
  });

  final OperacaoSdk operacao;
  final String rotulo;
  final IconData icone;
  final bool habilitado;
  final VoidCallback aoTocar;
  final String descricao;
  final List<Widget> campos;
  final bool primaria;

  @override
  Widget build(BuildContext context) {
    final bool disponivel = Capacidades.disponivel(operacao);
    final String? ressalva = Capacidades.ressalva(operacao);
    final bool ativo = habilitado && disponivel;

    final Widget botao = primaria
        ? FilledButton.icon(
            onPressed: ativo ? aoTocar : null,
            icon: Icon(icone),
            label: Text(rotulo),
          )
        : OutlinedButton.icon(
            onPressed: ativo ? aoTocar : null,
            icon: Icon(icone),
            label: Text(rotulo),
          );

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                if (ressalva == null)
                  botao
                else
                  Tooltip(
                    message: disponivel
                        ? 'Em ${Capacidades.plataforma}: $ressalva'
                        : 'Indisponível em ${Capacidades.plataforma}: '
                            '$ressalva',
                    child: botao,
                  ),
                if (ressalva != null) ...<Widget>[
                  const SizedBox(width: 8),
                  Icon(
                    disponivel
                        ? Icons.warning_amber_rounded
                        : Icons.block_outlined,
                    size: 18,
                    color: Theme.of(context).colorScheme.error,
                  ),
                ],
                const Spacer(),
                Text(
                  operacao.abi,
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        fontFamily: 'monospace',
                      ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(descricao, style: Theme.of(context).textTheme.bodySmall),
            if (campos.isNotEmpty) const SizedBox(height: 16),
            for (final Widget campo in campos)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: campo,
              ),
          ],
        ),
      ),
    );
  }
}

class _SeletorAmbiente extends StatelessWidget {
  const _SeletorAmbiente({required this.ambiente, required this.aoMudar});

  final Ambiente ambiente;
  final ValueChanged<Ambiente> aoMudar;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: SegmentedButton<Ambiente>(
        segments: const <ButtonSegment<Ambiente>>[
          ButtonSegment<Ambiente>(
            value: Ambiente.homologacao,
            label: Text('Homologação (2)'),
            icon: Icon(Icons.science_outlined),
          ),
          ButtonSegment<Ambiente>(
            value: Ambiente.producao,
            label: Text('Produção (1)'),
            icon: Icon(Icons.public),
          ),
        ],
        selected: <Ambiente>{ambiente},
        onSelectionChanged: (Set<Ambiente> escolha) => aoMudar(escolha.first),
      ),
    );
  }
}

class _Campo extends StatelessWidget {
  const _Campo({
    required this.rotulo,
    required this.controlador,
    this.linhas = 1,
  });

  final String rotulo;
  final TextEditingController controlador;
  final int linhas;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controlador,
      maxLines: linhas,
      minLines: linhas > 1 ? linhas : null,
      style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
      decoration: InputDecoration(
        labelText: rotulo,
        border: const OutlineInputBorder(),
        isDense: true,
        alignLabelWithHint: linhas > 1,
      ),
    );
  }
}

class _CartaoFalha extends StatelessWidget {
  const _CartaoFalha({required this.falha});

  final Object falha;

  @override
  Widget build(BuildContext context) {
    final ColorScheme cores = Theme.of(context).colorScheme;
    return Card(
      color: cores.errorContainer,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Icon(Icons.error_outline, color: cores.onErrorContainer),
                const SizedBox(width: 8),
                Text('A biblioteca nativa não carregou',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: cores.onErrorContainer,
                        )),
              ],
            ),
            const SizedBox(height: 12),
            SelectableText(
              falha.toString(),
              style: TextStyle(
                fontFamily: 'monospace',
                color: cores.onErrorContainer,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'No app empacotado a DLL fica ao lado do .exe, posta lá pelo '
              'windows/CMakeLists.txt do pacote. Se a lista acima só mostra o '
              'nome puro, o empacotamento é o suspeito.',
              style: TextStyle(color: cores.onErrorContainer),
            ),
          ],
        ),
      ),
    );
  }
}

class _CartaoIdentidade extends StatelessWidget {
  const _CartaoIdentidade({
    required this.identidade,
    required this.versao,
    required this.versaoBruta,
    required this.ligacao,
  });

  final IdentidadeModulo? identidade;
  final String versao;
  final int? versaoBruta;
  final String ligacao;

  @override
  Widget build(BuildContext context) {
    final IdentidadeModulo? id = identidade;
    final ColorScheme cores = Theme.of(context).colorScheme;
    final bool alerta =
        id != null && (id.nomeDivergeDaVersao || !id.pareceInvoicyFramework);

    return Card(
      color: alerta ? cores.errorContainer : null,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Icon(
                  alerta
                      ? Icons.warning_amber_rounded
                      : Icons.check_circle_outline,
                  color: alerta ? cores.onErrorContainer : cores.primary,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text('InvoiCyFramework $versao',
                      style: Theme.of(context).textTheme.titleLarge),
                ),
                if (id != null)
                  Chip(
                    label: Text(id.ehArtefatoVersionado
                        ? '${id.papel} · versionado'
                        : id.papel),
                    visualDensity: VisualDensity.compact,
                  ),
              ],
            ),
            const SizedBox(height: 12),
            _Linha('Ligação', ligacao),
            _Linha('Versao() bruta', versaoBruta?.toString() ?? '?'),
            if (id == null)
              _Linha('Identidade do módulo',
                  'indisponível em ${Capacidades.plataforma}')
            else ...<Widget>[
              _Linha('Arquivo carregado', id.nomeArquivo),
              _Linha('Plataforma', id.plataforma),
              _Linha('versaoNum', id.versaoNum.toString()),
              _Linha('Versão no nome', id.versaoNoNome ?? '(sem sufixo)'),
              _Linha('Compilação', id.compilacao),
              _Linha('PID', id.pid.toString()),
            ],
            if (id != null && id.nomeDivergeDaVersao) ...<Widget>[
              const SizedBox(height: 12),
              Text(
                'ATENÇÃO: o nome do arquivo diz ${id.versaoNoNome} mas o '
                'binário foi compilado como ${id.versao}. A biblioteca pai '
                'deduz a versão do filho pelo NOME — então está acreditando em '
                'algo falso. Artefato renomeado à mão?',
                style: TextStyle(
                  color: cores.onErrorContainer,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
            if (id != null && !id.pareceInvoicyFramework) ...<Widget>[
              const SizedBox(height: 12),
              Text(
                'ATENÇÃO: "${id.nomeArquivo}" não corresponde a nenhuma das '
                'convenções conhecidas.',
                style: TextStyle(
                  color: cores.onErrorContainer,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _Linha extends StatelessWidget {
  const _Linha(this.rotulo, this.valor);

  final String rotulo;
  final String valor;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            width: 150,
            child:
                Text(rotulo, style: Theme.of(context).textTheme.labelMedium),
          ),
          Expanded(
            child: SelectableText(
              valor,
              style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }
}

class _LinhaEvento extends StatelessWidget {
  const _LinhaEvento({required this.evento});

  final Evento evento;

  @override
  Widget build(BuildContext context) {
    final ColorScheme cores = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Icon(
                  evento.sucesso ? Icons.check : Icons.close,
                  size: 18,
                  color: evento.sucesso ? cores.primary : cores.error,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(evento.rotulo,
                      style: Theme.of(context).textTheme.titleSmall),
                ),
                Text('${evento.horario} · ${evento.tempo}',
                    style: Theme.of(context).textTheme.labelSmall),
              ],
            ),
            const SizedBox(height: 6),
            SelectableText(
              evento.detalhe,
              style: TextStyle(
                fontFamily: 'monospace',
                fontSize: 12,
                color: evento.sucesso ? null : cores.error,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
