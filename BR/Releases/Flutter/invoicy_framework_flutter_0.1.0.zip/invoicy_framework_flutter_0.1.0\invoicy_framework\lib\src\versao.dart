/// As duas -- na verdade tres -- codificacoes numericas de versao que a mesma
/// ideia recebe neste produto.
///
/// Esta e a armadilha mais recorrente do InvoiCyFramework, e a unica que produz
/// um numero plausivel e errado em vez de um erro. Ate agora foram encontrados
/// tres casos:
///
/// | Origem | Exemplo | Codificacao |
/// |---|---|---|
/// | `InvoiCyFramework_Versao` (Windows/Linux) | 15000 | `atoi(sprintf("%lx", 0x015000))` -- digitos DECIMAIS do retorno sao os HEXADECIMAIS da constante, e o zero a esquerda se perde |
/// | `versaoNum` de `GetModuleIdentity` | 86016 | a constante crua `0x015000` |
/// | `Versao()` da fachada Android | 86037 | a constante crua `0x014015` -- **codificacao diferente da mesma funcao** |
///
/// Por isso a decodificacao nao mora na fachada: mora na implementacao de cada
/// plataforma, que sabe qual das duas usar. A fachada expoe uma verdade so, a
/// string.
library;

/// Decodifica o retorno de `InvoiCyFramework_Versao` **nativo**.
///
/// Completa com zeros a esquerda antes de agrupar, porque o `%lx` do C++ nao
/// completa e o zero inicial se perde no `atoi`.
String versaoDeDigitosDecimais(int retorno) {
  final String digitos = retorno.toString().padLeft(6, '0');
  final int fim = digitos.length;
  return '${digitos.substring(0, fim - 4)}.'
      '${digitos.substring(fim - 4, fim - 2)}.'
      '${digitos.substring(fim - 2)}';
}

/// Decodifica a constante crua -- `versaoNum` do desktop e `Versao()` do
/// Android.
///
/// Cada octeto e um par de digitos hexadecimais, o mesmo `%02lX`/`%02x` que o
/// C++ e o Java usam para montar a versao em texto.
String versaoDeConstanteCrua(int bruto) {
  String doisDigitos(int octeto) =>
      octeto.toRadixString(16).toUpperCase().padLeft(2, '0');
  return '${doisDigitos((bruto >> 16) & 0xFF)}.'
      '${doisDigitos((bruto >> 8) & 0xFF)}.'
      '${doisDigitos(bruto & 0xFF)}';
}
