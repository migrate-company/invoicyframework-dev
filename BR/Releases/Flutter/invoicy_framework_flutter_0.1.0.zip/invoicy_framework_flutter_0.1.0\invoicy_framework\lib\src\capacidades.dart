import 'dart:io';

/// Quanto de uma operacao existe no Android.
///
/// O Android nao e uma reimplementacao fiel da ABI nativa: e outro projeto, em
/// Java, que cobre um subconjunto. Fingir uniformidade seria o erro caro --
/// melhor a API dizer o que ha, para o ERP esconder o botao em vez de descobrir
/// no clique.
enum SuporteAndroid {
  /// Existe e se comporta como no desktop.
  completo,

  /// Existe, mas com ressalva: nao tem efeito, ou o efeito e outro. A chamada
  /// funciona e nao lanca -- ver [OperacaoSdk.notaAndroid].
  degradado,

  /// Nao existe. A camada Dart lanca `OperacaoNaoSuportadaException`.
  ausente,
}

/// As operacoes do SDK e o que acontece com cada uma no Android.
///
/// Levantado a partir da fachada `com.migrate.gerentedocumento.InvoiCyFramework`
/// e confirmado com quem mantem a biblioteca. Esta tabela e a fonte unica: a
/// fachada Dart consulta daqui, e o POC monta a tela daqui.
enum OperacaoSdk {
  versao(
    abi: 'InvoiCyFramework_Versao',
    android: SuporteAndroid.completo,
  ),
  configuraInvoicy(
    abi: 'InvoiCyFramework_ConfiguraInvoicy',
    android: SuporteAndroid.completo,
  ),
  ambienteEmissao(
    abi: 'InvoiCyFramework_AmbienteEmissao',
    android: SuporteAndroid.completo,
  ),
  configura(
    abi: 'InvoiCyFramework_Configura',
    android: SuporteAndroid.completo,
  ),
  emiteDocumento(
    abi: 'InvoiCyFramework_EmiteDocumento',
    android: SuporteAndroid.completo,
  ),
  configuraDiretorio(
    abi: 'InvoiCyFramework_ConfiguraDiretorio',
    android: SuporteAndroid.degradado,
    notaAndroid: 'a chamada existe mas nao tem efeito: apenas registra no log. '
        'O diretorio de trabalho no Android e definido pela propria biblioteca.',
  ),
  arquivoSistema(
    abi: 'InvoiCyFramework_ArquivoSistema',
    android: SuporteAndroid.degradado,
    notaAndroid: 'grava no diretorio padrao da biblioteca, nao no que voce '
        'configurou -- entao nao da para prever o caminho do arquivo.',
  ),
  log(
    abi: 'InvoiCyFramework_Log',
    android: SuporteAndroid.ausente,
    notaAndroid: 'nao existe na fachada Java.',
    notaGeral: 'devolve SEMPRE vazio: Log::conteudoLog() em Log.cpp e um stub '
        'que retorna NULL, sem variacao por plataforma. Nao depende de '
        'LOG_NIVEL nem de configuracao nenhuma.',
  ),
  identidadeModulo(
    abi: 'InvoiCyFramework_GetModuleIdentity',
    android: SuporteAndroid.ausente,
    notaAndroid: 'nao existe, e nao ha o que reportar: o mecanismo de '
        'atualizacao automatica pai/filho e exclusivo do binario nativo.',
  );

  const OperacaoSdk({
    required this.abi,
    required this.android,
    this.notaAndroid,
    this.notaGeral,
  });

  /// Nome da funcao na ABI nativa, para rastrear ate o C++.
  final String abi;

  /// O que acontece com esta operacao no Android.
  final SuporteAndroid android;

  /// Por que ela e degradada ou ausente **no Android**. Nulo quando o suporte
  /// la e completo.
  final String? notaAndroid;

  /// Ressalva que vale em **todas** as plataformas.
  ///
  /// Distinta de [notaAndroid]: existe para o caso da propria biblioteca nativa
  /// nao implementar a funcao, o que nao e um problema de portabilidade -- e uma
  /// funcao que nao faz nada em lugar nenhum.
  final String? notaGeral;
}

/// O que a plataforma corrente oferece.
///
/// Em Windows e Linux tudo e completo -- a ABI nativa e a referencia. As
/// restricoes valem para o Android.
abstract final class Capacidades {
  /// Suporte da operacao na plataforma em que este codigo esta rodando.
  static SuporteAndroid suporte(OperacaoSdk operacao) =>
      Platform.isAndroid ? operacao.android : SuporteAndroid.completo;

  /// A operacao pode ser chamada aqui? Falso apenas quando ela e ausente.
  ///
  /// Operacao **degradada** devolve `true`: ela funciona, so nao faz
  /// exatamente o mesmo. Quem quiser distinguir consulta [suporte] e
  /// [OperacaoSdk.notaAndroid].
  static bool disponivel(OperacaoSdk operacao) =>
      suporte(operacao) != SuporteAndroid.ausente;

  /// Ressalva a exibir junto da operacao, ou nulo quando nao ha.
  ///
  /// Junta as duas origens possiveis: a que vale em qualquer plataforma
  /// ([OperacaoSdk.notaGeral]) e a especifica do Android
  /// ([OperacaoSdk.notaAndroid]), esta ultima so quando o codigo esta rodando
  /// la.
  static String? ressalva(OperacaoSdk operacao) {
    final List<String> partes = <String>[
      if (operacao.notaGeral != null) operacao.notaGeral!,
      if (suporte(operacao) != SuporteAndroid.completo &&
          operacao.notaAndroid != null)
        operacao.notaAndroid!,
    ];
    return partes.isEmpty ? null : partes.join(' · ');
  }

  /// Nome da plataforma corrente, para mensagens.
  static String get plataforma => Platform.operatingSystem;
}
