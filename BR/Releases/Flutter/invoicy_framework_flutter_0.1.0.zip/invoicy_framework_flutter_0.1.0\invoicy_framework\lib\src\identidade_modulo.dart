import 'dart:convert';

/// Identidade do modulo que **atendeu** a chamada.
///
/// Existe por causa da atualizacao automatica: o processo pode ter duas
/// InvoiCyFramework carregadas (a instalada e a baixada), exportando os mesmos
/// simbolos. Esta e a resposta auto-reportada de quem executou de fato -- o
/// modulo resolve o proprio handle a partir do endereco de uma funcao sua.
///
/// ## Os nomes de arquivo variam, e o formato tem significado
///
/// O par pai/filho usa nomes diferentes de proposito -- nome distinto significa
/// SONAME distinto, o que evita o `dlopen` devolver o handle do modulo ja
/// carregado. Os quatro formatos possiveis:
///
/// | Papel | Windows | Linux |
/// |---|---|---|
/// | pai | `InvoiCyFramework.dll` | `libInvoiCyFramework.so` |
/// | filho | `InvoiCyFramework_01_50_00.dll` | `InvoiCyFramework_01_50_00.so` |
///
/// Note que **o filho no Linux nao tem o prefixo `lib`** (`PREFIX ""` no
/// CMakeLists), enquanto a pai tem. Portanto nenhuma verificacao de nome pode
/// assumir prefixo fixo, nem extensao fixa, nem presenca do sufixo de versao.
///
/// Os digitos do sufixo sao **hexadecimais**, nao decimais:
/// `versaoDoNomeArquivo` em DelegacaoFilho.cpp valida com `isxdigit` e converte
/// com `strtoul(..., 16)`. `_01_50_00` corresponde a `0x015000` -- a mesma
/// codificacao de [versaoNum], e nao a de `InvoiCyFramework_Versao`.
///
/// Uma armadilha registrada: a varredura da pai exige que o nome comece
/// exatamente com `InvoiCyFramework_`. Um filho batizado
/// `libInvoiCyFramework_01_50_00.so` seria ignorado **em silencio**.
/// [versaoNoNome] aceita esse nome e o interpreta, para que o diagnostico
/// mostre o que esta la; e a varredura da pai que o descartaria.
class IdentidadeModulo {
  const IdentidadeModulo({
    required this.papel,
    required this.modulo,
    required this.arquivo,
    required this.versao,
    required this.versaoNum,
    required this.plataforma,
    required this.compilacao,
    required this.pid,
    required this.jsonBruto,
  });

  /// Constroi a partir do JSON de `InvoiCyFramework_GetModuleIdentity`.
  ///
  /// Os nomes dos campos vem de IdentidadeModulo.cpp. Campo ausente vira vazio
  /// ou zero em vez de excecao: esta e uma ferramenta de diagnostico, e falhar
  /// ao diagnosticar e o pior desfecho possivel.
  factory IdentidadeModulo.fromJson(String json) {
    if (json.isEmpty) {
      return IdentidadeModulo.vazia(json);
    }

    Object? decodificado;
    try {
      decodificado = jsonDecode(json);
    } on FormatException {
      // JSON malformado nao pode derrubar um diagnostico. Guardamos o bruto.
      return IdentidadeModulo.vazia(json);
    }
    if (decodificado is! Map<String, Object?>) {
      return IdentidadeModulo.vazia(json);
    }
    final Map<String, Object?> mapa = decodificado;

    String texto(String chave) => mapa[chave]?.toString() ?? '';
    int numero(String chave) {
      final Object? valor = mapa[chave];
      if (valor is int) {
        return valor;
      }
      return int.tryParse(valor?.toString() ?? '') ?? 0;
    }

    return IdentidadeModulo(
      papel: texto('papel'),
      modulo: texto('modulo'),
      arquivo: texto('arquivo'),
      versao: texto('versao'),
      versaoNum: numero('versaoNum'),
      plataforma: texto('plataforma'),
      compilacao: texto('compilacao'),
      pid: numero('pid'),
      jsonBruto: json,
    );
  }

  factory IdentidadeModulo.vazia(String jsonBruto) => IdentidadeModulo(
        papel: '',
        modulo: '',
        arquivo: '',
        versao: '',
        versaoNum: 0,
        plataforma: '',
        compilacao: '',
        pid: 0,
        jsonBruto: jsonBruto,
      );

  /// `pai` ou `filho`. Vem da macro de compilacao do modulo.
  final String papel;

  /// **Nome do arquivo** do modulo, sem diretorio -- apesar do nome do campo.
  /// E o que `identidade_modulo_arquivo` extrai do caminho.
  final String modulo;

  /// **Caminho completo** do modulo carregado -- apesar do nome do campo.
  /// (No C++, `modulo` recebe o basename e `arquivo` recebe o caminho; a
  /// inversao aparente esta na origem, e nao vamos mascara-la aqui.)
  final String arquivo;

  /// Versao formatada pelo proprio C++, como `01.50.00`.
  final String versao;

  /// `VERSAO_CORRENTE` cru, ex. `0x015000` = 86016. Codificacao diferente da
  /// devolvida por `InvoiCyFramework_Versao` -- ver
  /// `InvoicyFramework.formataVersao`.
  final int versaoNum;

  /// `Windows64`, `Windows32` ou `Linux64`, conforme versaoPOS.h.
  final String plataforma;

  /// Data e hora de compilacao do modulo.
  final String compilacao;

  /// PID do processo.
  final int pid;

  /// JSON como veio. Guardado para log: se um campo novo aparecer numa versao
  /// futura da biblioteca, ele nao se perde no caminho.
  final String jsonBruto;

  bool get ehPai => papel == 'pai';
  bool get ehFilho => papel == 'filho';

  /// Reconhece qualquer um dos quatro nomes validos, com ou sem `lib`, com ou
  /// sem sufixo de versao, `.dll` ou `.so`.
  static final RegExp _padraoNome = RegExp(
    r'^(lib)?InvoiCyFramework'
    r'(?:_([0-9A-Fa-f]{2})_([0-9A-Fa-f]{2})_([0-9A-Fa-f]{2}))?'
    r'\.(dll|so)$',
  );

  /// Nome do arquivo, sem diretorio.
  ///
  /// Usa [modulo], que ja e o basename. Se ele vier vazio, deriva de [arquivo]
  /// cortando no ultimo separador -- aceitando `/` e `\`, porque o caminho vem
  /// do sistema onde o modulo roda, nao de onde o Dart roda.
  String get nomeArquivo {
    if (modulo.isNotEmpty) {
      return modulo;
    }
    final int corte = arquivo.lastIndexOf(RegExp(r'[/\\]'));
    return corte < 0 ? arquivo : arquivo.substring(corte + 1);
  }

  /// `dll`, `so`, ou vazio quando o nome nao tem extensao reconhecivel.
  String get extensao {
    final RegExpMatch? m = _padraoNome.firstMatch(nomeArquivo);
    if (m != null) {
      return m.group(5) ?? '';
    }
    final int ponto = nomeArquivo.lastIndexOf('.');
    return ponto < 0 ? '' : nomeArquivo.substring(ponto + 1).toLowerCase();
  }

  /// O nome corresponde a um artefato do InvoiCyFramework?
  ///
  /// Falso nao significa erro: significa que o binario carregado nao foi
  /// batizado por nenhuma das convencoes conhecidas -- informacao util em si.
  bool get pareceInvoicyFramework => _padraoNome.hasMatch(nomeArquivo);

  /// O nome carrega sufixo de versao (`_MM_mm_pp`), marca do artefato filho.
  bool get ehArtefatoVersionado => versaoNoNome != null;

  /// Versao lida do **nome do arquivo**, no formato `01.50.00`, ou `null`
  /// quando o nome nao tem sufixo de versao.
  ///
  /// Mesma regra de `versaoDoNomeArquivo` em DelegacaoFilho.cpp: pares de
  /// digitos hexadecimais separados por `_`, imediatamente antes da extensao.
  String? get versaoNoNome {
    final RegExpMatch? m = _padraoNome.firstMatch(nomeArquivo);
    if (m == null || m.group(2) == null) {
      return null;
    }
    return '${m.group(2)!.toUpperCase()}.'
        '${m.group(3)!.toUpperCase()}.'
        '${m.group(4)!.toUpperCase()}';
  }

  /// A versao no nome do arquivo discorda da versao compilada no binario.
  ///
  /// So faz sentido quando ha versao no nome; sem sufixo, devolve falso. Um
  /// `true` aqui e sinal forte de artefato renomeado a mao -- exatamente o tipo
  /// de coisa que a atualizacao pai/filho torna possivel e dificil de perceber.
  bool get nomeDivergeDaVersao {
    final String? doNome = versaoNoNome;
    if (doNome == null || versao.isEmpty) {
      return false;
    }
    return doNome.toUpperCase() != versao.toUpperCase();
  }

  @override
  String toString() {
    final String sufixo = ehArtefatoVersionado ? ' [versionado]' : '';
    final String alerta = nomeDivergeDaVersao ? ' NOME DIVERGE' : '';
    return 'IdentidadeModulo($papel, $nomeArquivo, versao $versao$sufixo$alerta, '
        '$plataforma, pid $pid)';
  }
}
