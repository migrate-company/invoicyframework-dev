package info.migrate.invoicy_framework;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;

import com.migrate.gerentedocumento.InvoiCyFramework;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;

/**
 * Ponte entre a API Dart do SDK e a fachada Java do InvoiCyFramework.
 *
 * <p>Escrito a mao em vez de gerado por Pigeon, pelo mesmo motivo que as
 * ligacoes FFI: sao cinco metodos, e o que precisa ser lido com atencao aqui --
 * o modelo de threads e a traducao de erro -- e o que codegen esconde. Pigeon
 * passa a valer quando a superficie crescer.
 *
 * <p><b>Modelo de threads.</b> As chamadas do Flutter chegam na thread principal
 * do Android, e {@code EmiteDocumento} faz rede: executa-la ali daria ANR. Tudo
 * roda num executor de <b>uma unica thread</b>, e a escolha do tamanho 1 nao e
 * economia -- e semantica. A biblioteca nativa serializa as chamadas com dois
 * mutexes internos, e um executor de uma thread reproduz isso no Android. Assim
 * o contrato que o SDK promete ("as chamadas sao serializadas") vale igual nas
 * tres plataformas, em vez de ser verdade so no desktop.
 *
 * <p>A resposta volta pela thread principal porque o MethodChannel exige isso.
 */
public class InvoicyFrameworkPlugin implements FlutterPlugin, MethodChannel.MethodCallHandler {

  private static final String CANAL = "info.migrate/invoicy_framework";

  private MethodChannel canal;
  private Context contexto;
  private InvoiCyFramework framework;

  private final ExecutorService executor = Executors.newSingleThreadExecutor();
  private final Handler principal = new Handler(Looper.getMainLooper());

  @Override
  public void onAttachedToEngine(@NonNull FlutterPluginBinding binding) {
    contexto = binding.getApplicationContext();
    canal = new MethodChannel(binding.getBinaryMessenger(), CANAL);
    canal.setMethodCallHandler(this);
  }

  @Override
  public void onDetachedFromEngine(@NonNull FlutterPluginBinding binding) {
    canal.setMethodCallHandler(null);
    canal = null;
    executor.shutdown();
  }

  /**
   * Instancia a fachada sob demanda, com o applicationContext.
   *
   * <p>O construtor Java exige um {@code Context} -- e o equivalente Android do
   * {@code Initialize} da ABI nativa, que no desktop e opcional. Usamos o
   * applicationContext, e nao o da Activity, porque a instancia vive enquanto o
   * engine viver e nao deve segurar referencia a uma tela.
   */
  private InvoiCyFramework framework() {
    if (framework == null) {
      framework = new InvoiCyFramework(contexto);
    }
    return framework;
  }

  @Override
  public void onMethodCall(@NonNull MethodCall chamada, @NonNull MethodChannel.Result resultado) {
    final String metodo = chamada.method;
    final Map<String, Object> argumentos =
        chamada.arguments instanceof Map ? chamada.<Map<String, Object>>arguments() : new HashMap<>();

    executor.execute(
        () -> {
          try {
            final Object valor = executa(metodo, argumentos);
            principal.post(() -> resultado.success(valor));
          } catch (NaoImplementado e) {
            principal.post(() -> resultado.notImplemented());
          } catch (Throwable e) {
            // Qualquer excecao da biblioteca vira erro de plataforma, que o lado
            // Dart converte numa excecao tipada do SDK. Capturamos Throwable, e
            // nao Exception, porque um NoClassDefFoundError do AAR minificado
            // seria justamente o que precisamos ver.
            final String tipo = e.getClass().getName();
            final String mensagem = e.getMessage() == null ? tipo : e.getMessage();
            principal.post(() -> resultado.error("erro_nativo", mensagem, tipo));
          }
        });
  }

  /** Marca um metodo que a fachada Android nao oferece. */
  private static class NaoImplementado extends Exception {}

  private Object executa(String metodo, Map<String, Object> a) throws NaoImplementado {
    switch (metodo) {
      case "versao":
        // ATENCAO: no Android este retorno e a constante CRUA
        // (ContextoAplicativo.versaoInt() = 0x014015), enquanto no desktop
        // InvoiCyFramework_Versao devolve atoi(sprintf("%lx", ...)). Sao
        // codificacoes diferentes da mesma ideia, e quem decodifica e a
        // implementacao Dart desta plataforma -- ver impl_canal.dart.
        return framework().Versao();

      case "configuraInvoicy":
        {
          // A ordem importa: as credenciais sao gravadas por ambiente. Igual ao
          // desktop, o ambiente vai primeiro.
          final int ambiente = ((Number) a.get("ambiente")).intValue();
          exigeUm(framework().AmbienteEmissao(ambiente), "AmbienteEmissao");
          exigeUm(
              framework()
                  .ConfiguraInvoicy(
                      texto(a.get("cnpj")),
                      texto(a.get("chaveAcesso")),
                      texto(a.get("chaveParceiro"))),
              "ConfiguraInvoicy");
          return null;
        }

      case "ambienteEmissao":
        exigeUm(
            framework().AmbienteEmissao(((Number) a.get("ambiente")).intValue()),
            "AmbienteEmissao");
        return null;

      case "configura":
        exigeUm(
            framework().Configura(texto(a.get("parametro")), texto(a.get("valor"))),
            "Configura");
        return null;

      case "emiteDocumento":
        return framework()
            .EmiteDocumento(texto(a.get("xmlEntrada")), texto(a.get("xmlParametro")));

      case "configuraDiretorio":
        // Existe, mas nao tem efeito no Android: a fachada Java apenas registra
        // no log. Chamamos de qualquer forma, para o comportamento ser o da
        // biblioteca e nao uma invencao nossa; a camada Dart e quem avisa.
        exigeUm(framework().ConfiguraDiretorio(texto(a.get("diretorio"))), "ConfiguraDiretorio");
        return null;

      case "arquivoSistema":
        // Grava no diretorio padrao da biblioteca, nao no configurado.
        exigeUm(
            framework().ArquivoSistema(texto(a.get("nome")), texto(a.get("dados"))),
            "ArquivoSistema");
        return null;

      default:
        // log e identidadeModulo caem aqui: nao existem na fachada Java. O lado
        // Dart nem chega a pedir -- Capacidades ja barra antes -- mas se
        // chegasse, notImplemented e a resposta honesta.
        throw new NaoImplementado();
    }
  }

  private static String texto(Object valor) {
    return valor == null ? "" : valor.toString();
  }

  private static void exigeUm(int retorno, String funcao) {
    if (retorno != 1) {
      throw new IllegalStateException(funcao + " devolveu " + retorno + ", esperado 1");
    }
  }
}
