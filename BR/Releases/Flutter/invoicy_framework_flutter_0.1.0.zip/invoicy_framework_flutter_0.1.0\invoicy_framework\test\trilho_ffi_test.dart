library;

import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:invoicy_framework/invoicy_framework.dart';

/// Valida o trilho FFI de ponta a ponta, sem credencial e sem rede.
///
/// O que estes testes provam, em ordem de importância:
///
/// 1. a DLL carrega e os símbolos resolvem por nome — o único ponto que o
///    código-fonte C++ não respondia com certeza, porque o header só aplica
///    `extern "C"` fora do Windows e quem garante o nome é o `Source.def`;
/// 2. strings acentuadas atravessam a fronteira nos dois sentidos, verificado
///    por arquivo gravado pela biblioteca e lido de volta pelo Dart;
/// 3. `ConfiguraDiretorio` teve efeito de verdade — o que o retorno dela,
///    sempre 1, não permite afirmar;
/// 4. a codificação numérica de versão do desktop é interpretada corretamente,
///    por concordância com a string que o próprio C++ formata.
void main() {
  late String raizPacote;
  late Directory areaTrabalho;
  late InvoicyFramework ifw;

  /// Onde o binário nativo mora, e como a identidade deve descrevê-lo, nesta
  /// plataforma. Nulo onde o SDK não tem trilha FFI.
  ///
  /// O teste roda em Windows e em Linux: é a mesma trilha com outro binário, e é
  /// justamente essa igualdade que a Etapa 4 existe para comprovar. Marcá-lo
  /// como exclusivo do Windows, como estava antes, deixava a verificação de
  /// UTF-8 e a de versão sem cobertura no Linux, onde elas valem igual.
  _Alvo? alvo() {
    if (Platform.isWindows) {
      return const _Alvo(
        caminho: 'native/windows/x64/InvoiCyFramework.dll',
        plataforma: 'Windows64',
        extensao: 'dll',
        script: 'sync_native.bat',
      );
    }
    if (Platform.isLinux) {
      return const _Alvo(
        caminho: 'native/linux/x64/libInvoiCyFramework.so',
        plataforma: 'Linux64',
        extensao: 'so',
        script: 'sync_native.sh',
      );
    }
    return null;
  }

  setUpAll(() async {
    final _Alvo? atual = alvo();
    if (atual == null) {
      return;
    }

    raizPacote = Directory.current.path;
    final String caminhoBinario = '$raizPacote/${atual.caminho}';

    if (!File(caminhoBinario).existsSync()) {
      fail('Binário nativo não encontrado em $caminhoBinario.\n'
          'Rode ${atual.script} na raiz de invoicyframeworkflutter.');
    }

    areaTrabalho = Directory.systemTemp.createTempSync('ifw_teste_emissão_');
    Directory.current = areaTrabalho;

    ifw = await InvoicyFramework.abre(caminhoBiblioteca: caminhoBinario);
  });

  tearDownAll(() {
    if (alvo() == null) {
      return;
    }
    Directory.current = raizPacote;
    InvoicyFramework.descartaInstancia();
    // ignore: avoid_print
    print('Área de trabalho da biblioteca: ${areaTrabalho.path}');
  });

  group('codificação de versão (unitário, sem a biblioteca)', () {
    test('formataVersao lê os dígitos decimais do retorno do desktop', () {
      // VersaoFrameworkInt em Util.cpp faz sprintf("%lx", 0x015000) -> "15000"
      // e devolve atoi disso = 15000.
      expect(InvoicyFramework.formataVersao(15000), '01.50.00');
      expect(InvoicyFramework.formataVersao(101), '00.01.01');
    });

    test('formataVersaoNum lê a constante crua', () {
      // Usada por versaoNum do GetModuleIdentity E pelo Versao() do Android.
      expect(InvoicyFramework.formataVersaoNum(0x015000), '01.50.00');
      expect(InvoicyFramework.formataVersaoNum(0x014015), '01.40.15');
    });

    test('as duas codificações convergem para o mesmo texto', () {
      expect(
        InvoicyFramework.formataVersao(15000),
        InvoicyFramework.formataVersaoNum(86016),
      );
    });
  });

  group('carga da biblioteca', () {
    test('informa de onde carregou', () {
      expect(ifw.comoEstaLigado, contains('InvoiCyFramework'));
    });

    test('Versao responde e a versão formatada tem a forma esperada', () async {
      expect(await ifw.versaoBruta(), greaterThan(0));
      expect(await ifw.versao(), matches(RegExp(r'^\d{2}\.\d{2}\.\d{2}$')));

      // ignore: avoid_print
      print('Versão: ${await ifw.versao()}  '
          '(bruta = ${await ifw.versaoBruta()})');
    });
  }, skip: pularSemTrilhaFfi);

  group('GetModuleIdentity — char* de retorno', () {
    test('decodifica o JSON e preenche os campos', () async {
      final IdentidadeModulo identidade = await ifw.identidadeModulo();

      expect(identidade.jsonBruto, isNotEmpty);
      expect(identidade.papel, anyOf('pai', 'filho'));
      expect(identidade.plataforma, alvo()!.plataforma);
      expect(identidade.pid, greaterThan(0));

      // O nome do artefato varia em quatro formatos — os formatos em si estão
      // cobertos em identidade_modulo_test.dart.
      expect(identidade.pareceInvoicyFramework, isTrue,
          reason: 'nome fora das convenções: "${identidade.nomeArquivo}"');
      expect(identidade.extensao, alvo()!.extensao);
      expect(identidade.nomeDivergeDaVersao, isFalse,
          reason: 'a versão no nome (${identidade.versaoNoNome}) discorda da '
              'compilada (${identidade.versao}) — renomeado à mão?');

      // ignore: avoid_print
      print('Identidade: $identidade');
    });

    test('as duas leituras de versão do Dart batem com a string do C++',
        () async {
      // Cruzamento de três fontes independentes: o inteiro de Versao(), o
      // inteiro de versaoNum, e o texto que IdentidadeModulo.cpp monta com
      // %02lX.
      final IdentidadeModulo identidade = await ifw.identidadeModulo();

      expect(await ifw.versao(), identidade.versao,
          reason: 'a decodificação de versão do SDK discorda do C++');
      expect(
        InvoicyFramework.formataVersaoNum(identidade.versaoNum),
        identidade.versao,
      );
    });
  }, skip: pularSemTrilhaFfi);

  group('fronteira de strings — ida e volta com acentuação', () {
    test('ConfiguraDiretorio + ArquivoSistema preservam nome e conteúdo',
        () async {
      // Verifica duas coisas ao mesmo tempo: acentuação sobrevive
      // Dart -> UTF-8 -> C++ -> disco, e ConfiguraDiretorio realmente mudou o
      // diretório de trabalho — o arquivo tem de aparecer LÁ.
      final Directory destino =
          Directory('${areaTrabalho.path}/emissão_ação_çedilha')
            ..createSync(recursive: true);

      await ifw.configuraDiretorio(destino.path);

      const String nomeArquivo = 'aferição_de_codificação.txt';
      const String conteudo = 'Razão Social: JOSÉ AÇÚCAR & CIA LTDA\n'
          'Endereço: Travessa São João, 1º andar — Belém/PA';

      await ifw.arquivoSistema('\$BASEDIR/$nomeArquivo', conteudo);

      final File gravado = File('${destino.path}/$nomeArquivo');
      expect(gravado.existsSync(), isTrue,
          reason: 'o arquivo não apareceu no diretório configurado. Conteúdo '
              'do destino: '
              '${destino.listSync().map((FileSystemEntity e) => e.path).toList()}');

      expect(utf8.decode(gravado.readAsBytesSync()), conteudo,
          reason: 'o conteúdo voltou diferente — a fronteira não está em UTF-8');
    });

    test('recusa diretório vazio antes de chamar o nativo', () async {
      await expectLater(
        ifw.configuraDiretorio(''),
        throwsA(isA<ChamadaNativaException>()),
      );
    });

    test('ArquivoSistema recusa nome vazio', () async {
      await expectLater(
        ifw.arquivoSistema('', 'x'),
        throwsA(isA<ChamadaNativaException>()),
      );
    });
  }, skip: pularSemTrilhaFfi);
}

/// Onde o binário está e o que esperar dele, por plataforma.
class _Alvo {
  const _Alvo({
    required this.caminho,
    required this.plataforma,
    required this.extensao,
    required this.script,
  });

  /// Caminho do binário, relativo à raiz do pacote.
  final String caminho;

  /// Valor que `PLATAFORMA_CORRENTE` de versaoPOS.h reporta aqui.
  final String plataforma;

  final String extensao;

  /// Script que copia o binário do repositório C++ para dentro do pacote.
  final String script;
}

/// Motivo do skip, ou nulo quando há trilha FFI nesta plataforma.
///
/// Os testes de codificação de versão e de parsing de identidade não dependem
/// do binário e rodam em qualquer lugar; os demais precisam dele.
final Object? pularSemTrilhaFfi = Platform.isWindows || Platform.isLinux
    ? null
    : 'sem trilha FFI em ${Platform.operatingSystem}: o SDK cobre Windows, '
        'Linux e Android, e no Android o caminho é MethodChannel';
