/// Excecoes do SDK.
///
/// A ABI nativa comunica falha por codigo de retorno. Traduzir isso para
/// excecoes tipadas e parte do valor do SDK: quem integra escreve try/catch em
/// vez de conferir inteiros.
library;

/// Raiz de todas as excecoes do SDK.
sealed class InvoicyFrameworkException implements Exception {
  const InvoicyFrameworkException(this.mensagem);

  final String mensagem;

  @override
  String toString() => '$runtimeType: $mensagem';
}

/// A biblioteca nativa nao pode ser carregada.
///
/// Em desenvolvimento a causa quase sempre e caminho: no app empacotado a DLL
/// fica ao lado do .exe, e em teste ela e resolvida por caminho relativo ao
/// pacote. [caminhosTentados] mostra exatamente onde se procurou.
final class BibliotecaNativaException extends InvoicyFrameworkException {
  const BibliotecaNativaException(super.mensagem, {this.caminhosTentados = const []});

  final List<String> caminhosTentados;

  @override
  String toString() {
    final buffer = StringBuffer('BibliotecaNativaException: $mensagem');
    if (caminhosTentados.isNotEmpty) {
      buffer.write('\nCaminhos tentados:');
      for (final caminho in caminhosTentados) {
        buffer.write('\n  - $caminho');
      }
    }
    return buffer.toString();
  }
}

/// Uma funcao nativa devolveu codigo de falha.
final class ChamadaNativaException extends InvoicyFrameworkException {
  ChamadaNativaException({
    required this.funcao,
    required this.codigo,
    String? detalhe,
  }) : super(detalhe ?? 'codigo de retorno inesperado');

  /// Nome da funcao exportada, como consta em InvoiCyFramework.h.
  final String funcao;

  /// Codigo devolvido pela biblioteca.
  final int codigo;

  @override
  String toString() =>
      'ChamadaNativaException: $funcao devolveu $codigo ($mensagem)';
}

/// A plataforma corrente nao oferece a operacao pedida.
///
/// Existe porque o Android implementa um subconjunto da ABI nativa. A camada
/// Dart prefere falhar com esta excecao, que diz o que fazer, a fingir sucesso.
final class OperacaoNaoSuportadaException extends InvoicyFrameworkException {
  OperacaoNaoSuportadaException({
    required this.operacao,
    required this.plataforma,
    String? alternativa,
  }) : super(alternativa == null
            ? '$operacao nao existe em $plataforma'
            : '$operacao nao existe em $plataforma. Alternativa: $alternativa');

  final String operacao;
  final String plataforma;
}
