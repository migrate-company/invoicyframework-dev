import 'dart:isolate';

import 'ambiente.dart';
import 'biblioteca_nativa.dart';
import 'bindings.dart';
import 'excecoes.dart';
import 'identidade_modulo.dart';
import 'plataforma.dart';
import 'versao.dart';

/// Implementacao para Windows e Linux, via `dart:ffi`.
class ImplFfi implements ImplPlataforma {
  ImplFfi._(this._bindings, this._especificador, this.descricao);

  /// Abre a biblioteca nativa e monta a implementacao.
  factory ImplFfi.abre({String? caminhoBiblioteca}) {
    final BibliotecaCarregada carregada =
        abreBibliotecaNativa(caminhoExplicito: caminhoBiblioteca);
    return ImplFfi._(
      InvoicyFrameworkBindings(carregada.biblioteca),
      carregada.especificador,
      carregada.caminho,
    );
  }

  final InvoicyFrameworkBindings _bindings;

  /// A entrada exata que abriu a biblioteca, para reabri-la em outra isolate --
  /// nem sempre e um caminho. Ver `BibliotecaCarregada.especificador`.
  final String _especificador;

  @override
  final String descricao;

  void _exigeUm(int retorno, String funcao, {String? detalhe}) {
    if (retorno != 1) {
      throw ChamadaNativaException(
        funcao: funcao,
        codigo: retorno,
        detalhe: detalhe ?? 'esperado 1',
      );
    }
  }

  @override
  Future<int> versaoBruta() async => _bindings.versao();

  /// No desktop o retorno passa por `atoi(sprintf("%lx", ...))`.
  @override
  String formataVersao(int bruto) => versaoDeDigitosDecimais(bruto);

  @override
  Future<void> configuraInvoicy({
    required Ambiente ambiente,
    required String cnpj,
    required String chaveAcesso,
    required String chaveParceiro,
  }) async {
    // A ordem e o ponto. As credenciais sao gravadas por ambiente, e o ambiente
    // vigente e a chave no ConfigEmpresaDB.
    _exigeUm(
      _bindings.ambienteEmissao(ambiente.codigo),
      'InvoiCyFramework_AmbienteEmissao',
    );
    _exigeUm(
      _bindings.configuraInvoicy(cnpj, chaveAcesso, chaveParceiro),
      'InvoiCyFramework_ConfiguraInvoicy',
      detalhe: 'CNPJ invalido, ou alguma das chaves veio vazia',
    );
  }

  @override
  Future<void> ambienteEmissao(Ambiente ambiente) async => _exigeUm(
        _bindings.ambienteEmissao(ambiente.codigo),
        'InvoiCyFramework_AmbienteEmissao',
      );

  @override
  Future<void> configura(String parametro, String valor) async => _exigeUm(
        _bindings.configura(parametro, valor),
        'InvoiCyFramework_Configura',
        detalhe: 'parametro "$parametro"',
      );

  /// Roda em isolate separada: a chamada faz rede, autenticacao e, na emissao,
  /// assinatura digital.
  ///
  /// A isolate **reabre** a biblioteca em vez de receber um handle -- nem
  /// `DynamicLibrary` nem ponteiros de funcao atravessam a fronteira entre
  /// isolates. Reabrir e barato: e o mesmo modulo ja carregado no processo. O
  /// estado da biblioteca (credenciais, ambiente, diretorio) e do PROCESSO,
  /// nao da isolate, entao configurar aqui e emitir la funciona.
  @override
  Future<String> emiteDocumento(String xmlEntrada, String xmlParametro) {
    final String especificador = _especificador;
    return Isolate.run(() {
      final ImplFfi naIsolate =
          ImplFfi.abre(caminhoBiblioteca: especificador);
      return naIsolate._bindings.emiteDocumento(xmlEntrada, xmlParametro);
    });
  }

  @override
  Future<void> configuraDiretorio(String diretorio) async {
    if (diretorio.isEmpty) {
      throw ChamadaNativaException(
        funcao: 'InvoiCyFramework_ConfiguraDiretorio',
        codigo: 0,
        detalhe: 'diretorio vazio',
      );
    }
    // A nativa devolve 1 incondicionalmente -- nao valida existencia nem
    // permissao. A validacao util e esta, do lado Dart.
    _exigeUm(
      _bindings.configuraDiretorio(diretorio),
      'InvoiCyFramework_ConfiguraDiretorio',
    );
  }

  @override
  Future<void> arquivoSistema(String nome, String dados) async {
    if (nome.isEmpty) {
      throw ChamadaNativaException(
        funcao: 'InvoiCyFramework_ArquivoSistema',
        codigo: 0,
        detalhe: 'nome de arquivo vazio',
      );
    }
    _exigeUm(
      _bindings.arquivoSistema(nome, dados),
      'InvoiCyFramework_ArquivoSistema',
      detalhe: 'nao foi possivel gravar "$nome"',
    );
  }

  @override
  Future<String> log() async => _bindings.log();

  @override
  Future<IdentidadeModulo> identidadeModulo() async =>
      IdentidadeModulo.fromJson(_bindings.getModuleIdentity());

  @override
  void descarta() {
    // Nada a fazer: nao chamamos Terminate de proposito. A biblioteca
    // reinicializa sob demanda, e derrubar as threads internas so para
    // descartar um objeto Dart seria caro e surpreendente.
  }
}
