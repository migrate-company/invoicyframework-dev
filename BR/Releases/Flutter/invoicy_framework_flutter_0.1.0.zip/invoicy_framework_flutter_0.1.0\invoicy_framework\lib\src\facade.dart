import 'dart:io';

import 'ambiente.dart';
import 'capacidades.dart';
import 'excecoes.dart';
import 'identidade_modulo.dart';
import 'impl_canal.dart';
import 'impl_ffi.dart';
import 'plataforma.dart';
import 'versao.dart';

/// Fachada do SDK: a API que o ERP consome.
///
/// Uma instancia por processo, espelhando a biblioteca -- que tem estado global.
/// Duas instancias Dart nao dariam duas bibliotecas; dariam a ilusao de
/// isolamento.
///
/// ## Toda a API e assincrona, inclusive `versao()`
///
/// No Android o caminho e um MethodChannel, e canal de plataforma no Flutter
/// nao tem versao sincrona. Duas saidas eram possiveis: API assincrona nas tres
/// plataformas, ou formas diferentes por plataforma. A segunda devolveria ao
/// ERP o codigo condicional que este SDK existe para eliminar -- entao e a
/// primeira, mesmo ao custo de um `await` em algo que no desktop e instantaneo.
///
/// ## Concorrencia
///
/// As chamadas sao serializadas: no nativo pelos dois mutexes internos, no
/// Android por um executor de uma unica thread no shim. Duas chamadas
/// simultaneas nao corrompem estado, mas uma espera a outra -- e isso vale
/// igual nas tres plataformas.
class InvoicyFramework {
  InvoicyFramework._(this._impl);

  final ImplPlataforma _impl;

  static InvoicyFramework? _instancia;

  /// A instancia aberta, ou nulo se [abre] ainda nao foi chamado.
  static InvoicyFramework? get instanciaAberta => _instancia;

  /// Liga o SDK a plataforma corrente.
  ///
  /// No Windows e no Linux carrega a biblioteca nativa; no Android apenas
  /// prepara o canal (a instancia Java e criada sob demanda, com o
  /// applicationContext, na primeira chamada).
  ///
  /// [caminhoBiblioteca] vale so no desktop, para apontar um binario
  /// especifico em diagnostico.
  static Future<InvoicyFramework> abre({String? caminhoBiblioteca}) async {
    final ImplPlataforma impl = Platform.isAndroid
        ? ImplCanal()
        : ImplFfi.abre(caminhoBiblioteca: caminhoBiblioteca);
    final InvoicyFramework fachada = InvoicyFramework._(impl);
    _instancia = fachada;
    return fachada;
  }

  /// Descarta a instancia em memoria, sem finalizar a biblioteca nativa.
  static void descartaInstancia() {
    _instancia?._impl.descarta();
    _instancia = null;
  }

  /// Como o SDK esta ligado: caminho do binario no desktop, canal no Android.
  /// Primeira coisa a olhar em diagnostico.
  String get comoEstaLigado => _impl.descricao;

  // --------------------------------------------------------------------------
  // Operacoes portaveis -- existem nas tres plataformas.
  // --------------------------------------------------------------------------

  /// Versao legivel, no formato `01.50.00`.
  ///
  /// **Esta e a unica representacao de versao que o SDK trata como verdade.**
  /// O inteiro por tras vem em codificacoes diferentes por plataforma (ver
  /// [versaoBruta]), e cada implementacao sabe decodificar a sua.
  Future<String> versao() async => _impl.formataVersao(await _impl.versaoBruta());

  /// Retorno cru de `Versao()`.
  ///
  /// **Nao compare este numero entre plataformas.** No desktop ele passa por
  /// `atoi(sprintf("%lx", VERSAO_CORRENTE))` -- 15000 para a versao 01.50.00.
  /// No Android e a constante crua -- 86037 para a versao 01.40.15. Para exibir
  /// ou comparar versao, use [versao].
  Future<int> versaoBruta() => _impl.versaoBruta();

  /// Define o ambiente e as credenciais do invoiCy, **nesta ordem**.
  ///
  /// [cnpj] sem pontuacao, so digitos.
  ///
  /// O ambiente e obrigatorio aqui porque as credenciais sao gravadas POR
  /// ambiente: `ConfiguraInvoicy` le o `AMBIENTE` vigente e o usa como chave em
  /// `BuscaEmpresa`/`InsereEmpresa`. Chamar na ordem inversa grava as
  /// credenciais sob o ambiente antigo, e a emissao passa a procurar uma
  /// empresa que nao existe -- sem erro nenhum, porque `ConfiguraInvoicy`
  /// devolve 1 de qualquer jeito. Como parametro obrigatorio, a ordem errada
  /// deixa de ser expressavel.
  Future<void> configuraInvoicy({
    required Ambiente ambiente,
    required String cnpj,
    required String chaveAcesso,
    required String chaveParceiro,
  }) {
    _exigeSuporte(OperacaoSdk.configuraInvoicy);
    return _impl.configuraInvoicy(
      ambiente: ambiente,
      cnpj: cnpj,
      chaveAcesso: chaveAcesso,
      chaveParceiro: chaveParceiro,
    );
  }

  /// Alterna entre producao e homologacao, isoladamente.
  ///
  /// **Trocar o ambiente invalida as credenciais ja configuradas**, que ficaram
  /// gravadas sob o ambiente anterior. Depois desta chamada, reenvie
  /// [configuraInvoicy] -- ou use so [configuraInvoicy], que faz as duas coisas
  /// na ordem certa.
  Future<void> ambienteEmissao(Ambiente ambiente) {
    _exigeSuporte(OperacaoSdk.ambienteEmissao);
    return _impl.ambienteEmissao(ambiente);
  }

  /// Parametro generico da biblioteca, por nome.
  Future<void> configura(String parametro, String valor) {
    _exigeSuporte(OperacaoSdk.configura);
    return _impl.configura(parametro, valor);
  }

  /// Emite, consulta, cancela ou inutiliza -- **quem decide e o elemento raiz
  /// de [xmlEntrada]**.
  ///
  /// `DocumentoGeral.cpp` inspeciona esse no e roteia `<Consulta>`,
  /// `<Documento>`, `<Evento>` e os demais para tipos distintos. O
  /// [xmlParametro] complementa, e em varias operacoes vai vazio.
  ///
  /// No desktop roda em isolate separada; no Android, num executor de uma
  /// thread no shim. Em nenhuma das duas a thread da UI bloqueia.
  Future<String> emiteDocumento(
    String xmlEntrada, {
    String xmlParametro = '',
  }) {
    _exigeSuporte(OperacaoSdk.emiteDocumento);
    return _impl.emiteDocumento(xmlEntrada, xmlParametro);
  }

  // --------------------------------------------------------------------------
  // Diagnostico -- ausentes ou degradadas no Android. Ver capacidades.dart.
  // --------------------------------------------------------------------------

  /// Define o diretorio de trabalho da biblioteca.
  ///
  /// **No Android nao tem efeito** -- apenas registra no log; o diretorio e
  /// definido pela propria biblioteca. Nao lanca la, porque a chamada existe.
  Future<void> configuraDiretorio(String diretorio) {
    _exigeSuporte(OperacaoSdk.configuraDiretorio);
    return _impl.configuraDiretorio(diretorio);
  }

  /// Grava um arquivo no diretorio de trabalho da biblioteca.
  ///
  /// Aceita o prefixo `$BASEDIR/` em [nome] no desktop. **No Android o arquivo
  /// vai para o diretorio padrao da biblioteca**, e o caminho final nao e
  /// previsivel do lado Dart.
  Future<void> arquivoSistema(String nome, String dados) {
    _exigeSuporte(OperacaoSdk.arquivoSistema);
    return _impl.arquivoSistema(nome, dados);
  }

  /// Conteudo do log -- **na teoria**.
  ///
  /// Devolve sempre vazio no desktop (`Log::conteudoLog()` em comum/Log.cpp e
  /// um stub que retorna NULL) e **nao existe** no Android.
  Future<String> log() {
    _exigeSuporte(OperacaoSdk.log);
    return _impl.log();
  }

  /// Identidade do modulo que atendeu a chamada.
  ///
  /// **Nao existe no Android**, e nao ha o que reportar la: a atualizacao
  /// automatica pai/filho e exclusiva do binario nativo.
  Future<IdentidadeModulo> identidadeModulo() {
    _exigeSuporte(OperacaoSdk.identidadeModulo);
    return _impl.identidadeModulo();
  }

  // --------------------------------------------------------------------------

  void _exigeSuporte(OperacaoSdk operacao) {
    if (!Capacidades.disponivel(operacao)) {
      throw OperacaoNaoSuportadaException(
        operacao: operacao.abi,
        plataforma: Capacidades.plataforma,
        alternativa: operacao.notaAndroid,
      );
    }
  }

  /// Decodifica o retorno de `Versao()` do **desktop**. Ver versao.dart.
  static String formataVersao(int retornoDeVersao) =>
      versaoDeDigitosDecimais(retornoDeVersao);

  /// Decodifica a constante crua -- `versaoNum` do desktop e `Versao()` do
  /// **Android**. Ver versao.dart.
  static String formataVersaoNum(int bruto) => versaoDeConstanteCrua(bruto);

  @override
  String toString() => 'InvoicyFramework($comoEstaLigado)';
}
