/// SDK Flutter da biblioteca nativa InvoiCyFramework.
///
/// Uma unica API para Windows, Linux e Android. As diferencas entre as
/// plataformas morrem nesta camada -- nunca no codigo de quem usa o SDK.
///
/// ```dart
/// final ifw = await InvoicyFramework.abre();
///
/// await ifw.configuraInvoicy(
///   ambiente: Ambiente.homologacao,
///   cnpj: '06354976000149',
///   chaveAcesso: '...',
///   chaveParceiro: '...',
/// );
///
/// final recibo = await ifw.emiteDocumento(xmlDaConsulta);
/// ```
///
/// Toda a API e assincrona nas tres plataformas -- ver `InvoicyFramework`.
library invoicy_framework;

export 'src/ambiente.dart' show Ambiente;
export 'src/capacidades.dart' show Capacidades, OperacaoSdk, SuporteAndroid;
export 'src/excecoes.dart';
export 'src/facade.dart' show InvoicyFramework;
export 'src/identidade_modulo.dart' show IdentidadeModulo;
