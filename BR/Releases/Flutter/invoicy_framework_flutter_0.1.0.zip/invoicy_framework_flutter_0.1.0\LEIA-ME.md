# SDK Flutter do InvoiCyFramework

Uma única API Dart para emissão de documentos fiscais em **Windows, Linux e
Android**, sobre a biblioteca InvoiCyFramework da Migrate.

O guia completo está em **`docs/GUIA_DE_INTEGRACAO.pdf`** (ou `.md`). Este
arquivo é só o suficiente para você ver o SDK funcionando nos próximos minutos.

---

## 1. Rode o exemplo primeiro

Antes de integrar, confirme que o seu ambiente está pronto. Se o exemplo roda,
qualquer problema seguinte é do seu lado — e isso economiza bastante tempo.

```bash
cd poc_invoicy
flutter pub get
flutter run -d windows      # ou:  -d linux   |   -d <id do dispositivo Android>
```

O `-d` não é opcional: a maioria das máquinas lista Chrome e Edge como
dispositivos, e o SDK não existe na web.

> **Troque as credenciais.** O exemplo abre preenchido com dados de homologação
> **da Migrate**, para rodar com um duplo clique. Antes de usar de verdade,
> substitua CNPJ, chave de acesso e chave de parceiro — nos campos da tela, ou
> direto em `poc_invoicy/lib/dados_homologacao.dart`, que explica os três no
> cabeçalho. A chave de acesso vem em branco de propósito, então a primeira
> chamada falha até você preencher a sua. Seção 9 do guia.

## 2. Integre ao seu aplicativo

No `pubspec.yaml`:

```yaml
dependencies:
  invoicy_framework:
    path: ../invoicy_framework    # ajuste para onde você extraiu
```

```bash
flutter pub get
```

Não há DLL para copiar nem repositório Maven para configurar — o pacote traz
tudo e o próprio build coloca cada coisa no lugar.

## 3. Use

```dart
import 'package:invoicy_framework/invoicy_framework.dart';

final ifw = await InvoicyFramework.abre();

await ifw.configuraInvoicy(
  ambiente: Ambiente.homologacao,
  cnpj: '00000000000000',
  chaveAcesso: 'sua-chave-de-acesso',
  chaveParceiro: 'sua-chave-de-parceiro',
);

final retorno = await ifw.emiteDocumento(xml);
```

Este trecho é idêntico nas três plataformas.

---

## Três coisas que economizam uma tarde

**Toda a API é assíncrona**, inclusive `versao()`. É o preço de o Android usar
canal de plataforma, e o que permite o seu código não ter `if (Platform.is...)`.

**A ordem de configuração importa** — e `configuraInvoicy` já resolve. As
credenciais são gravadas por ambiente; configurá-las antes de definir o ambiente
as grava sob o ambiente errado, **sem erro nenhum**. Se você usar
`ambienteEmissao()` isoladamente para alternar, reenvie as credenciais depois.

**`emiteDocumento` não emite só.** Quem decide a operação é o elemento raiz do
XML: `<Documento>` emite, `<Consulta>` consulta, `<Evento>` cancela. Comece por
uma consulta: exercita rede, autenticação e o caminho inteiro sem criar
documento fiscal.

---

## No Windows, antes de tudo

Ligue o Modo de Desenvolvedor, ou `flutter pub get` vai falhar com *"Building
with plugins requires symlink support"*:

```
start ms-settings:developers
```

É exigência de desenvolvimento. Quem instala o aplicativo compilado não precisa.

---

## O que tem aqui

| | |
|---|---|
| `invoicy_framework/` | O pacote. É isto que entra no seu `pubspec.yaml`. |
| `poc_invoicy/` | Aplicativo de exemplo, com fontes. |
| `docs/` | O guia de integração, em Markdown e PDF. |
| `MANIFESTO.txt` | Versões e SHA256 dos binários. |
| `CHANGELOG.md` | Histórico do SDK. |

*InvoiCyFramework e InvoiCy são produtos da Migrate.*
