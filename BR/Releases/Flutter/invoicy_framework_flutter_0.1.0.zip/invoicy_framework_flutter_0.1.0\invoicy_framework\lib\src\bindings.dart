import 'dart:ffi';

import 'package:ffi/ffi.dart';

/// Ligacoes cruas para a ABI C do InvoiCyFramework.
///
/// Escritas a mao de proposito. No MVP sao tres funcoes, e o que precisa ser
/// lido com atencao aqui -- a conversao de strings e a posse da memoria -- e
/// justamente o que codigo gerado esconde. `ffigen.yaml` ja esta configurado
/// para quando a superficie completa (46 funcoes) entrar.
///
/// Notas sobre a fronteira, colhidas do C++:
///
/// - **Nomes**: no Windows o header so aplica `extern "C"` quando `WIN32` NAO
///   esta definido; quem garante o nome sem decoracao e `Biblioteca/Source.def`.
///   No Linux, `exportmap`. Em ambos, o simbolo e exatamente
///   `InvoiCyFramework_<Funcao>`.
/// - **Convencao de chamada**: `__stdcall` no Windows. Irrelevante em x64, que
///   tem convencao unica. Importaria num alvo x86.
/// - **Posse de memoria**: os `char*` de retorno vem do buffer circular
///   `ultimo_retorno[10]` de InterfaceBiblioteca.cpp. O cliente NAO libera --
///   a biblioteca recicla o slot. Chamar `calloc.free` neles corromperia o
///   heap dela.
/// - **Strings de entrada**: convertidas para UTF-8 e liberadas por nos, que
///   fomos quem alocou.
class InvoicyFrameworkBindings {
  InvoicyFrameworkBindings(DynamicLibrary biblioteca)
      : _versao = biblioteca.lookupFunction<Int32 Function(), int Function()>(
          'InvoiCyFramework_Versao',
        ),
        _configuraDiretorio = biblioteca.lookupFunction<
            Int32 Function(Pointer<Char>), int Function(Pointer<Char>)>(
          'InvoiCyFramework_ConfiguraDiretorio',
        ),
        _getModuleIdentity = biblioteca.lookupFunction<
            Pointer<Char> Function(), Pointer<Char> Function()>(
          'InvoiCyFramework_GetModuleIdentity',
        ),
        _log = biblioteca.lookupFunction<Pointer<Char> Function(),
            Pointer<Char> Function()>(
          'InvoiCyFramework_Log',
        ),
        _arquivoSistema = biblioteca.lookupFunction<
            Int32 Function(Pointer<Char>, Pointer<Char>),
            int Function(Pointer<Char>, Pointer<Char>)>(
          'InvoiCyFramework_ArquivoSistema',
        ),
        _configuraInvoicy = biblioteca.lookupFunction<
            Int32 Function(Pointer<Char>, Pointer<Char>, Pointer<Char>),
            int Function(Pointer<Char>, Pointer<Char>, Pointer<Char>)>(
          'InvoiCyFramework_ConfiguraInvoicy',
        ),
        _configura = biblioteca.lookupFunction<
            Int32 Function(Pointer<Char>, Pointer<Char>),
            int Function(Pointer<Char>, Pointer<Char>)>(
          'InvoiCyFramework_Configura',
        ),
        _ambienteEmissao =
            biblioteca.lookupFunction<Int32 Function(Int32), int Function(int)>(
          'InvoiCyFramework_AmbienteEmissao',
        ),
        _emiteDocumento = biblioteca.lookupFunction<
            Pointer<Char> Function(Pointer<Char>, Pointer<Char>),
            Pointer<Char> Function(Pointer<Char>, Pointer<Char>)>(
          'InvoiCyFramework_EmiteDocumento',
        );

  final int Function() _versao;
  final int Function(Pointer<Char>) _configuraDiretorio;
  final Pointer<Char> Function() _getModuleIdentity;
  final Pointer<Char> Function() _log;
  final int Function(Pointer<Char>, Pointer<Char>) _arquivoSistema;
  final int Function(Pointer<Char>, Pointer<Char>, Pointer<Char>)
      _configuraInvoicy;
  final int Function(Pointer<Char>, Pointer<Char>) _configura;
  final int Function(int) _ambienteEmissao;
  final Pointer<Char> Function(Pointer<Char>, Pointer<Char>) _emiteDocumento;

  /// `int InvoiCyFramework_Versao()`
  ///
  /// Devolve a versao em BCD-hex. Ver [InvoicyFramework.formataVersao].
  int versao() => _versao();

  /// `int InvoiCyFramework_ConfiguraDiretorio(char* diretorio)`
  int configuraDiretorio(String diretorio) {
    final Pointer<Utf8> nativo = diretorio.toNativeUtf8();
    try {
      return _configuraDiretorio(nativo.cast<Char>());
    } finally {
      calloc.free(nativo);
    }
  }

  /// `int InvoiCyFramework_ConfiguraInvoicy(char* CNPJ, char* chaveAcesso,
  /// char* chaveParceiro)`
  int configuraInvoicy(String cnpj, String chaveAcesso, String chaveParceiro) {
    final Pointer<Utf8> a = cnpj.toNativeUtf8();
    final Pointer<Utf8> b = chaveAcesso.toNativeUtf8();
    final Pointer<Utf8> c = chaveParceiro.toNativeUtf8();
    try {
      return _configuraInvoicy(a.cast<Char>(), b.cast<Char>(), c.cast<Char>());
    } finally {
      calloc.free(a);
      calloc.free(b);
      calloc.free(c);
    }
  }

  /// `int InvoiCyFramework_Configura(char* parametro, char* valor)`
  int configura(String parametro, String valor) {
    final Pointer<Utf8> p = parametro.toNativeUtf8();
    final Pointer<Utf8> v = valor.toNativeUtf8();
    try {
      return _configura(p.cast<Char>(), v.cast<Char>());
    } finally {
      calloc.free(p);
      calloc.free(v);
    }
  }

  /// `int InvoiCyFramework_AmbienteEmissao(int valor)` -- 1 producao, 2 homologacao.
  int ambienteEmissao(int valor) => _ambienteEmissao(valor);

  /// `char* InvoiCyFramework_EmiteDocumento(char* xmlEntrada, char* xmlParametro)`
  ///
  /// **Bloqueia**: faz rede, autenticacao e, na emissao, assinatura digital.
  /// Nunca chamar da thread da UI -- a fachada expoe a versao assincrona.
  ///
  /// Apesar do nome, tambem serve consulta, cancelamento e inutilizacao: quem
  /// decide a operacao e o **elemento raiz de `xmlEntrada`**. `DocumentoGeral.cpp`
  /// inspeciona esse no e roteia `<Consulta>`, `<Documento>`, `<Evento>` e os
  /// demais para tipos distintos. O `xmlParametro` complementa, e para varias
  /// operacoes pode ir vazio.
  ///
  /// O retorno vem do buffer circular da biblioteca. Nao liberar.
  String emiteDocumento(String xmlEntrada, String xmlParametro) {
    final Pointer<Utf8> entrada = xmlEntrada.toNativeUtf8();
    final Pointer<Utf8> parametro = xmlParametro.toNativeUtf8();
    try {
      final Pointer<Char> retorno =
          _emiteDocumento(entrada.cast<Char>(), parametro.cast<Char>());
      if (retorno == nullptr) {
        return '';
      }
      return retorno.cast<Utf8>().toDartString();
    } finally {
      calloc.free(entrada);
      calloc.free(parametro);
    }
  }

  /// `int InvoiCyFramework_ArquivoSistema(char* nome, char* dados)`
  ///
  /// Grava um arquivo no diretorio de trabalho da biblioteca. Devolve 1 em
  /// sucesso, 0 em falha -- e aqui o retorno **e** confiavel: vem de
  /// `grava_dados_arquivo`, que so reporta sucesso se o `fopen` e a escrita
  /// funcionaram.
  ///
  /// O nome aceita o prefixo `$BASEDIR/`, que `caminho_traduzido` expande para
  /// o diretorio configurado por `ConfiguraDiretorio` -- com o separador final
  /// ja garantido por `configura_diretorio_base_padrao`. Sem prefixo, o arquivo
  /// cai no diretorio corrente do processo.
  ///
  /// E a peca central do teste de codificacao: nome e conteudo acentuados
  /// atravessam a fronteira, viram um arquivo real, e o Dart le de volta e
  /// compara. De passagem, prova que `ConfiguraDiretorio` teve efeito -- coisa
  /// que o retorno dela, sempre 1, nao permite verificar.
  int arquivoSistema(String nome, String dados) {
    final Pointer<Utf8> nomeNativo = nome.toNativeUtf8();
    final Pointer<Utf8> dadosNativo = dados.toNativeUtf8();
    try {
      return _arquivoSistema(nomeNativo.cast<Char>(), dadosNativo.cast<Char>());
    } finally {
      calloc.free(nomeNativo);
      calloc.free(dadosNativo);
    }
  }

  /// `char* InvoiCyFramework_Log()`
  ///
  /// Conteudo do log da execucao corrente -- **na teoria**.
  ///
  /// Devolve SEMPRE vazio. `Log::conteudoLog()` em comum/Log.cpp e um stub:
  /// `return NULL;`, sem `#ifdef` em volta e sem outra implementacao no
  /// projeto. Nao e questao de nivel de log nem de plataforma; a funcao nao
  /// esta escrita. (`apagaLog` e `copiaLog`, ao lado, tambem sao stubs.)
  ///
  /// Continua ligada porque faz parte da ABI e porque o dia em que o C++ a
  /// implementar, o SDK nao precisa mudar. Ate lá, nao serve para verificar
  /// nada.
  String log() {
    final Pointer<Char> retorno = _log();
    if (retorno == nullptr) {
      return '';
    }
    return retorno.cast<Utf8>().toDartString();
  }

  /// `char* InvoiCyFramework_GetModuleIdentity()`
  ///
  /// Nao inicializa a biblioteca -- pode ser chamada mesmo com a instalacao com
  /// problema. O ponteiro devolvido e do buffer circular da lib: nao liberar.
  String getModuleIdentity() {
    final Pointer<Char> retorno = _getModuleIdentity();
    if (retorno == nullptr) {
      return '';
    }
    return retorno.cast<Utf8>().toDartString();
  }
}
