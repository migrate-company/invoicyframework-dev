library;

import 'package:flutter_test/flutter_test.dart';
import 'package:invoicy_framework/invoicy_framework.dart';

/// Testes puros de parsing do JSON de `GetModuleIdentity`. Sem DLL e sem
/// dependencia de plataforma -- rodam em qualquer lugar, inclusive em CI Linux.
///
/// O ponto destes testes e travar o conhecimento sobre os NOMES dos artefatos,
/// que variam de quatro formas e cujo formato tem significado para o mecanismo
/// pai/filho. Uma verificacao ingenua do tipo
/// `arquivo.contains('InvoiCyFramework.dll')` passa com a pai e falha com o
/// filho -- e a diferenca so aparece depois de uma atualizacao automatica, no
/// cliente, num horario ruim.
void main() {
  /// Monta um JSON no formato exato de IdentidadeModulo.cpp.
  ///
  /// O campo `arquivo` do JSON e escapado pelo C++ (`escapaJson` dobra as
  /// contrabarras), entao fazemos o mesmo aqui -- caso contrario o JSON do
  /// Windows sairia invalido, que e justamente o motivo daquela funcao existir.
  String jsonDe({
    String papel = 'pai',
    String modulo = 'InvoiCyFramework.dll',
    String arquivo = r'C:\Program Files\Migrate\InvoiCyFramework.dll',
    String versao = '01.50.00',
    int versaoNum = 0x015000,
    String plataforma = 'Windows64',
  }) {
    final String arquivoEscapado = arquivo.replaceAll('\\', r'\\');
    return '{"papel":"$papel",'
        '"modulo":"$modulo",'
        '"arquivo":"$arquivoEscapado",'
        '"versao":"$versao",'
        '"versaoNum":$versaoNum,'
        '"plataforma":"$plataforma",'
        '"compilacao":"Aug 31 2026 20:48:12",'
        '"pid":12345}';
  }

  group('campos basicos', () {
    test('decodifica todos os campos', () {
      final IdentidadeModulo id = IdentidadeModulo.fromJson(jsonDe());

      expect(id.papel, 'pai');
      expect(id.ehPai, isTrue);
      expect(id.ehFilho, isFalse);
      expect(id.versao, '01.50.00');
      expect(id.versaoNum, 86016);
      expect(id.plataforma, 'Windows64');
      expect(id.pid, 12345);
      expect(id.jsonBruto, isNotEmpty);
    });

    test('o caminho do Windows volta com contrabarras simples', () {
      // Prova que o escape do C++ e o jsonDecode se cancelam corretamente.
      final IdentidadeModulo id = IdentidadeModulo.fromJson(jsonDe());
      expect(id.arquivo, r'C:\Program Files\Migrate\InvoiCyFramework.dll');
    });

    test('JSON vazio ou malformado nao lanca -- diagnostico nao pode falhar',
        () {
      for (final String entrada in <String>['', '{', 'nao e json', '[]']) {
        final IdentidadeModulo id = IdentidadeModulo.fromJson(entrada);
        expect(id.papel, '');
        expect(id.versaoNum, 0);
        expect(id.jsonBruto, entrada);
      }
    });
  });

  group('nomes de artefato -- os quatro formatos validos', () {
    test('pai no Windows: InvoiCyFramework.dll', () {
      final IdentidadeModulo id =
          IdentidadeModulo.fromJson(jsonDe(modulo: 'InvoiCyFramework.dll'));

      expect(id.pareceInvoicyFramework, isTrue);
      expect(id.extensao, 'dll');
      expect(id.versaoNoNome, isNull);
      expect(id.ehArtefatoVersionado, isFalse);
      expect(id.nomeDivergeDaVersao, isFalse);
    });

    test('pai no Linux: libInvoiCyFramework.so', () {
      final IdentidadeModulo id = IdentidadeModulo.fromJson(jsonDe(
        modulo: 'libInvoiCyFramework.so',
        arquivo: '/opt/migrate/libInvoiCyFramework.so',
        plataforma: 'Linux64',
      ));

      expect(id.pareceInvoicyFramework, isTrue);
      expect(id.extensao, 'so');
      expect(id.versaoNoNome, isNull);
      expect(id.ehArtefatoVersionado, isFalse);
    });

    test('filho no Windows: InvoiCyFramework_01_50_00.dll', () {
      final IdentidadeModulo id = IdentidadeModulo.fromJson(jsonDe(
        papel: 'filho',
        modulo: 'InvoiCyFramework_01_50_00.dll',
      ));

      expect(id.ehFilho, isTrue);
      expect(id.pareceInvoicyFramework, isTrue);
      expect(id.extensao, 'dll');
      expect(id.ehArtefatoVersionado, isTrue);
      expect(id.versaoNoNome, '01.50.00');
      expect(id.nomeDivergeDaVersao, isFalse);
    });

    test('filho no Linux NAO tem prefixo lib', () {
      // PREFIX "" no CMakeLists: o filho sai InvoiCyFramework_MM_mm_pp.so
      // enquanto a pai e libInvoiCyFramework.so. Nome distinto significa
      // SONAME distinto, que e o ponto do arranjo.
      final IdentidadeModulo id = IdentidadeModulo.fromJson(jsonDe(
        papel: 'filho',
        modulo: 'InvoiCyFramework_01_50_00.so',
        arquivo: '/opt/migrate/InvoiCyFramework_01_50_00.so',
        plataforma: 'Linux64',
      ));

      expect(id.pareceInvoicyFramework, isTrue);
      expect(id.extensao, 'so');
      expect(id.versaoNoNome, '01.50.00');
    });
  });

  group('nomes de artefato -- casos de borda', () {
    test('os digitos do sufixo sao hexadecimais, nao decimais', () {
      // versaoDoNomeArquivo valida com isxdigit e converte com strtoul base 16.
      final IdentidadeModulo id = IdentidadeModulo.fromJson(jsonDe(
        papel: 'filho',
        modulo: 'InvoiCyFramework_01_0A_FF.dll',
        versao: '01.0A.FF',
        versaoNum: 0x010AFF,
      ));

      expect(id.versaoNoNome, '01.0A.FF');
      expect(id.nomeDivergeDaVersao, isFalse);
    });

    test('sufixo com digitos incompletos nao e reconhecido como versao', () {
      // O C++ exige exatamente dd_dd_dd. "1_50_0" nao passa, e a varredura da
      // pai ignoraria esse arquivo em silencio.
      final IdentidadeModulo id = IdentidadeModulo.fromJson(
          jsonDe(modulo: 'InvoiCyFramework_1_50_0.dll'));

      expect(id.pareceInvoicyFramework, isFalse);
      expect(id.versaoNoNome, isNull);
    });

    test('nome fora das convencoes nao lanca, so nao e reconhecido', () {
      final IdentidadeModulo id =
          IdentidadeModulo.fromJson(jsonDe(modulo: 'terceiro.dll'));

      expect(id.pareceInvoicyFramework, isFalse);
      expect(id.extensao, 'dll', reason: 'a extensao ainda deve ser deduzida');
      expect(id.versaoNoNome, isNull);
      expect(id.nomeDivergeDaVersao, isFalse);
    });

    test('detecta binario renomeado a mao: nome diz uma versao, binario outra',
        () {
      // O cenario real: alguem copia um artefato sobre o de outra versao, ou
      // renomeia para "forcar" uma atualizacao. A pai deduz a versao DO NOME
      // (versaoDoNomeArquivo) e passa a acreditar em algo falso.
      final IdentidadeModulo id = IdentidadeModulo.fromJson(jsonDe(
        papel: 'filho',
        modulo: 'InvoiCyFramework_01_32_00.dll',
        versao: '01.50.00',
        versaoNum: 0x015000,
      ));

      expect(id.versaoNoNome, '01.32.00');
      expect(id.versao, '01.50.00');
      expect(id.nomeDivergeDaVersao, isTrue,
          reason: 'e o unico jeito de perceber um artefato renomeado');
    });

    test('nomeArquivo cai para o caminho quando modulo vem vazio', () {
      // Defesa contra uma versao futura da lib que deixe de preencher o campo.
      final IdentidadeModulo comContrabarra = IdentidadeModulo.fromJson(jsonDe(
        modulo: '',
        arquivo: r'C:\Migrate\bin\InvoiCyFramework_01_50_00.dll',
      ));
      expect(comContrabarra.nomeArquivo, 'InvoiCyFramework_01_50_00.dll');
      expect(comContrabarra.versaoNoNome, '01.50.00');

      final IdentidadeModulo comBarra = IdentidadeModulo.fromJson(jsonDe(
        modulo: '',
        arquivo: '/opt/migrate/lib/libInvoiCyFramework.so',
        plataforma: 'Linux64',
      ));
      expect(comBarra.nomeArquivo, 'libInvoiCyFramework.so');
      expect(comBarra.extensao, 'so');
    });
  });
}
