/*
 * InvoiCyFramework.h
 *
 *  Created on:    Nov 5, 2018
 *      Author:    Migrate
 *      Objective: Biblioteca para emissão de documentos fiscais eletrônicos
 */

#ifndef INVOICYFRAMEWORK_H_
#define INVOICYFRAMEWORK_H_

#ifdef WIN32
#define DECLDIR
#define STDCAL	 __stdcall
#else
#define DECLDIR extern
#define STDCAL
#endif


#ifndef WIN32
extern "C"
{
#endif

/**
* Inicializa a biblioteca: aloca os recursos, sobe as threads internas e os serviços.
* A chamada é OPCIONAL - todas as demais funções inicializam a biblioteca sob demanda -
* e serve para a AC controlar o momento da inicialização e para reinicializar
* depois de um InvoiCyFramework_Terminate. Chamar mais de uma vez não tem efeito adicional.
* @return 1 = biblioteca inicializada / 0 = falha na inicialização (ex.: sem acesso ao banco)
*/
	DECLDIR int STDCAL InvoiCyFramework_Initialize();

/**
* Finaliza a biblioteca, liberando tudo o que a inicialização alocou (threads, memória,
* arquivo de log e recursos de terceiros). Chamar com a biblioteca já finalizada não tem efeito.
* ATENÇÃO: qualquer chamada posterior a outra função da biblioteca a inicializa novamente
* (inicialização sob demanda).
* @return 1 = biblioteca finalizada
*/
	DECLDIR int STDCAL InvoiCyFramework_Terminate();

/**
* Emite um documento fiscal ou envia um documento para o invoiCy
* @param xmlEntrada Dados em formato XML do documento que será emitido ou enviado para o invoiCy
* @param xmlParametro Dados em formato XML contendo os parâmetros de envio ou consulta
* @return Dados do recibo em formato XML ou o resultado do envio
*/
	DECLDIR char* STDCAL InvoiCyFramework_EmiteDocumento(char* xmlEntrada, char* xmlParametro);
	DECLDIR char* STDCAL InvoiCyFramework_Emitir(char* jsonEntrada, char* jsonParametros);

/**
* Emite um documento fiscal ou envia um documento para o invoiCy
* @param jsonEntrada Dados em formato JSON do documento que será emitido ou enviado para o invoiCy no layout de integração
* @param jsonParametro Dados em formato JSON contendo os parâmetros de envio ou consulta
* @return Dados do recibo em formato JSON ou o resultado do envio
*/
	DECLDIR char* STDCAL InvoiCyFramework_EmiteDocumentoJSON(char* jsonEntrada, char* jsonParametros);

/**
* #### Este método coloca o FW em estado de contingência - As emissões que forem solicitadas na sequência serão realizadas em tpEmis 9 ####
* Descarta o documento informado e emite em contingência
* @param xmlEntrada Dados em formato XML do documento que será descartado e emitido em contingência
* @return Dados do recibo em formato XML ou o resultado do envio
*/
	DECLDIR char* STDCAL InvoiCyFramework_EmiteContingencia(char* xmlEntrada);


/**
* Imprime o documento informado
* @param xmlRecibo Retorno da emissão em formato XML (o mesmo devolvido por EmiteDocumento), ou o
*                  caminho de um arquivo com esse conteúdo. Se for NULL ou vazio, reimprime o
*                  retorno da última emissão (EmiteDocumento/EmiteDocumentoJSON) feita neste processo.
* @return Maior que 0 em caso de sucesso (quantidade de documentos impressos quando o XML traz mais
*         de um DocumentosItem); 0 em caso de falha ou quando não há documento a imprimir
*/
	DECLDIR int STDCAL InvoiCyFramework_ImprimeDocumento(char* xmlRecibo);

/**
* Imprime o documento informado, permite o envio de parâmetros adicionais
* @param xmlRecibo Retorno da emissão em formato XML (o mesmo devolvido por EmiteDocumento), ou o
*                  caminho de um arquivo com esse conteúdo. Se for NULL ou vazio, reimprime o
*                  retorno da última emissão (EmiteDocumento/EmiteDocumentoJSON) feita neste processo.
* @param xmlParametros Parâmetros adicionais de impressão em formato XML (podem ser NULL)
* @return Maior que 0 em caso de sucesso (quantidade de documentos impressos quando o XML traz mais
*         de um DocumentosItem); 0 em caso de falha ou quando não há documento a imprimir
*/
DECLDIR int STDCAL InvoiCyFramework_ImprimeDocumentoEx(char* xmlRecibo, char* xmlParametros);

/**
* Força envio dos documentos pendentes
* @return Inteiro indicando quantidade de documentos enviados. 0 caso não tenha documento a ser enviado ou -1 em caso de erro.
*/
DECLDIR int STDCAL InvoiCyFramework_EnviaDocumentosPendentes();

/**
* Força envio de uma quantidade especificada de documentos pendentes
* @param Inteiro indicando quantidade de documentos que devem ser enviados. Se for passado um valor menor ou igual a zero, serão enviados todos os documentos pendentes.
* @return Dados xml contendo o resultado do envio.
*/
DECLDIR char* STDCAL InvoiCyFramework_EnviaDocumentosPendentesQuantidade(int quantidade);

/**
* Configura os parâmetros de emissão para o contribuinte estadual
* @param UF N[umero de dois dígitos referente ao código da UF que está sendo configurada
* @param idToken ID referente ao CSC
* @param CSC Código CSC do contribuinte cadastrado na SEFAZ
* @param contingencia Tipo de contingência do NFC-e sendo: 0 = Sem contingência, 1 = contingência offline, 2 = contingência SAT
* @param consultaQRcode URL de consulta do QRCode que será informado no DANFE
* @param consultaChave URL de consulta da chave de acesso do documento que será informado no DANFE
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_InsereParametrosEmissao(int UF, int idToken, char * CSC, int contingencia, char * consultaQRcode, char * consultaChave);


/**
* Envia configurações opcionais relacionadas a UF informada
* @param UF - Código da UF que será configurado
* @param parametro - Nome do parâmetro de configuração
* @param valor - Valor do parâmetro de configuração
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_ConfiguraUF(int UF, char * parametro, char * valor);

/**
* Configura os parâmetros de emissão do InvoiCy
* @param CNPJ - CNPJ sem pontos, apenas números do contribuinte
* @param chaveAcesso - Chave de acesso do InvoiCy
* @param chaveParceiro - Chave do parceiro para identificação pelo InvoiCy
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_ConfiguraInvoicy(char* CNPJ, char* chaveAcesso, char* chaveParceiro);
DECLDIR int STDCAL InvoiCyFramework_ConfigurarInvoicy(char* RUC, char* codIntegracion, char* claveAcceso, char* clavePartner);

/**
* Configura os parâmetros de emissão do InvoiCy, definindo o ambiente na mesma chamada.
*
* Equivale a chamar InvoiCyFramework_AmbienteEmissao seguido de
* InvoiCyFramework_ConfiguraInvoicy, nesta ordem - e existe justamente para que a ordem
* não dependa da integração: a empresa é registrada no ambiente informado aqui, e não no
* que estivesse configurado antes.
*
* @param ambienteEmissao - 1 = produção / 2 = homologação
* @param CNPJ - CNPJ sem pontos, apenas números do contribuinte
* @param chaveAcesso - Chave de acesso do InvoiCy
* @param chaveParceiro - Chave do parceiro para identificação pelo InvoiCy
* @return Retorna 1 em caso de sucesso. Retorna 0 sem alterar nada (nem o ambiente) quando o CNPJ
*         é inválido (NULL, tamanho diferente de 14 ou dígito verificador incorreto)
*/
DECLDIR int STDCAL InvoiCyFramework_ConfiguraInvoicyEx(int ambienteEmissao, char* CNPJ, char* chaveAcesso, char* chaveParceiro);
DECLDIR int STDCAL InvoiCyFramework_ConfigurarInvoicyEx(int ambienteEmissao, char* RUC, char* codIntegracion, char* claveAcceso, char* clavePartner);

/**
* Configura um parâmetro da biblioteca
* @param parametro - Nome do parâmetro
* @param valor - Valor do parâmetro
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_Configura(char* parametro, char* valor);
DECLDIR int STDCAL InvoiCyFramework_Configurar(char* parametro, char* valor);

/**
* Configura o diretório corrente que deverá ser utilizado pela biblioteca para armazenar documentos e configurações
* @param diretorio - Caminho do diretório
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_ConfiguraDiretorio(char* diretorio);
DECLDIR int STDCAL InvoiCyFramework_ConfigurarDirectorio(char* directorio);


/**
* Grava um arquivo com o nome e os dados informados no diretorio de trabalho da biblioteca
* @param nome - nome do arquivo
* @param dados - dados do arquivo
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_ArquivoSistema(char * nome, char * dados);


/**
* Alterna entre o modo de produção/homologação
* @param ativa - 1 = ambiente de producao / 2 = ambiente de homologacao
* @return retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_AmbienteEmissao(int valor);
DECLDIR int STDCAL InvoiCyFramework_AmbienteEmision(int valor);


/**
* Configura os parâmetros de emissão do SAT
* @param codigoAtivacao - código de ativação configurado no equipamento SAT
* @param softwareHouseCNPJ - CNPJ da software house do aplicativo comercial associado ao SAT
* @param softwareHouseAssinatura - assinatura do aplicativo comercial associado ao SAT
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_ConfiguraSAT(char* codigoAtivacao, char* softwareHouseCNPJ, char* softwareHouseAssinatura);
DECLDIR int STDCAL InvoiCyFramework_ConfiguraMFE(char* codigoAtivacao, char* softwareHouseCNPJ, char* softwareHouseAssinatura);

/**
* Busca o número da versão da biblioteca
* @return número informando a versão atual da biblioteca
*/
DECLDIR int STDCAL InvoiCyFramework_Versao();
DECLDIR int STDCAL InvoiCyFramework_Version();

/**
* Recupera uma lista com todos os documentos ainda pendentes de envio
* @return string no formato XML contendo listagem de documentos pendentes
*/
DECLDIR char * STDCAL InvoiCyFramework_RelatorioPendentes();

DECLDIR char* STDCAL InvoiCyFramework_RelatorioPendentesErro();
DECLDIR int STDCAL InvoiCyFramework_QuantidadeDocumentosPendentesErro();
DECLDIR int STDCAL InvoiCyFramework_ConfiguraDados(char* dadosArquivo);
DECLDIR int STDCAL InvoiCyFramework_ImprimirDE(char* xmlEntrada);
DECLDIR char* STDCAL InvoiCyFramework_InformePendientes();
DECLDIR int STDCAL InvoiCyFramework_EnviarDocumentosPendientes();
DECLDIR char* STDCAL InvoiCyFramework_EnviarDocumentosPendientesCantidad(int cantidad);

/**
* Recupera uma lista de alertas registrados pelo sistema
* @return string no formato XML contendo listagem de alertas
*/
DECLDIR char * STDCAL InvoiCyFramework_Alertas();

/**
* Busca os dados do log da execução atual
* @return Dados do log
*/
DECLDIR char * STDCAL InvoiCyFramework_Log();

/**
* Retorna estado do servico de impressão da biblioteca
* @return 0 = nada ocorrendo / 1 = em impressão
*/
DECLDIR int STDCAL InvoiCyFramework_Servico();


/**
* Busca a data e a hora corrente da UF configurada no InvoiCy
* @param UF - código IBGE da UF desejada
* @param aplicar - indica se a data e hora recebida deve ser aplicada no computador local
* @return string no formato "yyyy-MM-ddTHH:mm:ss"
*/
DECLDIR char * STDCAL InvoiCyFramework_ObtemDataHoraUF(int UF, int aplicar);


/**
* Busca parâmetros configurados no InvoiCy e informações da impressora
* @param identificadorParametro - identificador do parâmetro desejado:
*        1  = validade do certificado da empresa configurada (CNPJ + AMBIENTE), em XML:
*             <DataValidadeCertificado><CNPJ/><Ambiente/><DataValidade>ddMMyyyyHHmm</DataValidade>
*             <DiasRestantes/></DataValidadeCertificado>. Sem o grupo quando não há validade gravada.
*             Se a empresa configurada não for encontrada, usa a primeira empresa cadastrada.
*        2  = modelo da impressora
*        3  = versão do firmware da impressora
*        4  = status da impressora
*        5  = nome do fabricante da impressora
*        10 = validade do certificado de todas as empresas cadastradas, em XML:
*             <DataValidadeCertificados> com um <DataValidadeCertificado> (mesmo formato do
*             identificador 1) por empresa que tenha validade gravada
*        Os identificadores 1 e 10 atualizam a validade no InvoiCy antes de responder.
*        DiasRestantes é 0 quando o certificado já venceu.
* @return string contendo o valor do parâmetro solicitado; "<erro/>" para identificador desconhecido.
*         A string pertence à biblioteca (não liberar) e vale pelas próximas 10 chamadas.
*/
DECLDIR char* STDCAL InvoiCyFramework_ObtemParametro(int identificadorParametro);

/**
* Imprime um texto genérico, utilizando os comandos de layout do framework, ou texto puro
* @param texto - texto a ser impresso
* @return retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_ImprimeTexto(char* texto);

/**
* Envia o comando de abertura de gaveta (cash drawer) paraa a impressora
* @param pino - pino do conector a ser acionado (0 ou 1)
* @param tON - tempo ON (0-255) em ms
* @param tOFF - tempo OFF (0-255) em ms - especificar um valor > que tON
* @return retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_AbrirGaveta(int pino, int tON, int tOFF);

/**
* Busca o número sequencial do último documento
* @param serie - indica o número da série que se quer obter o sequencial
* @return inteiro que indica o número do último sequencial
*/
DECLDIR int STDCAL InvoiCyFramework_ObtemUltimoSequencialNFCe(int serie);

/**
* Busca o número sequencial do último documento fiscal emitido
* @param cnpj - CNPJ do emitente (14 dígitos, sem pontuação)
* @param tpAmb - ambiente: 1 = produção, 2 = homologação, 0 = ambiente configurado (AMBIENTE)
* @param tpDoc - tipo de documento: "NFCe" ou "NFe"
* @param serie - série (1 a 999)
* @return número do último sequencial emitido; 0 quando a série ainda não tem documento ou os
*         parâmetros são inválidos
*/
DECLDIR int STDCAL InvoiCyFramework_ObtemUltimoSequencialDFe(char* cnpj, int tpAmb, char* tpDoc, int serie);

/**
* Define o número sequencial do ÚLTIMO documento fiscal emitido. O próximo documento emitido
* nesta série receberá sequencial + 1.
* @param cnpj - CNPJ do emitente (14 dígitos, sem pontuação)
* @param tpAmb - ambiente: 1 = produção, 2 = homologação, 0 = ambiente configurado (AMBIENTE)
* @param tpDoc - tipo de documento: "NFCe" ou "NFe"
* @param serie - série (1 a 999)
* @param sequencial - número do último documento emitido (1 a 999999999)
* @return 0 em caso de sucesso; 1 em caso de erro
*/
DECLDIR int STDCAL InvoiCyFramework_DefineSequencialDFe(char* cnpj, int tpAmb, char* tpDoc, int serie, int sequencial);

/**
* Identifica o modulo que ESTA ATENDENDO a chamada.
*
* Com a atualizacao automatica, o processo pode ter duas bibliotecas InvoiCyFramework
* carregadas (a instalada e a baixada), exportando os mesmos simbolos. Esta funcao
* devolve a identidade de quem executou de fato: o modulo resolve o proprio handle a
* partir do endereco de uma funcao sua, e o campo "papel" vem da macro de compilacao.
* Portanto a resposta e auto-reportada, nao inferida.
*
* Nao inicializa a biblioteca: pode ser chamada mesmo com a instalacao com problema.
*
* @return JSON com papel ("pai"/"filho"), modulo, arquivo, versao, plataforma,
*         data/hora de compilacao e pid
*/
DECLDIR char* STDCAL InvoiCyFramework_GetModuleIdentity();

/*
* Dispara AGORA um ciclo completo de atualizacao automatica, de forma sincrona.
*
* Interface DIRETA, e nao via ExecuteCommand: ExecuteCommand fica reservado para
* expansao futura.
*
* Consulta a API, e havendo versao designada baixa, confere o checksum, descompacta,
* valida o conteudo e instala em $APPDIR. A ATIVACAO continua acontecendo na proxima
* inicializacao, quando a delegacao encontra o arquivo e roda o teste de fumaca.
*
* Chamadas concorrentes sao serializadas: duas threads produzem uma execucao de cada
* vez, nunca duas simultaneas.
*
* @return JSON com o desfecho: acao tomada, RetCodigo do servidor, versao instalada e
*         designada, se instalou, e o motivo quando nao instalou
*/
DECLDIR char* STDCAL InvoiCyFramework_AtualizaAgora();

/**
* Chamada genérica de execução de método
* @param commandName - nome do método a ser executado
* @param parameters - JSON contendo os parâmetros do método a ser executado
* @return string contendo uma estrutura JSON de retorno
*/
DECLDIR char* STDCAL InvoiCyFramework_ExecuteCommand(char* commandName, char* parameters);

#ifndef WIN32
}
#endif

#endif /* INVOICYFRAMEWORK_H_ */
