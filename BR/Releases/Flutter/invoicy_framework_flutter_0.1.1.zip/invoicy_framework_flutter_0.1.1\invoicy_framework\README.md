# invoicy_framework

SDK Flutter da biblioteca nativa **InvoiCyFramework** (Migrate). Uma unica API Dart
para Windows, Linux e Android.

> **Integrando pela primeira vez?** O guia completo -- requisitos, instalacao,
> referencia da API e diagnostico -- esta em `docs/GUIA_DE_INTEGRACAO.pdf`, na raiz do
> pacote. Este README e a referencia curta e as notas de quem mexe no proprio SDK.

```dart
import 'package:invoicy_framework/invoicy_framework.dart';

final ifw = await InvoicyFramework.abre();

print(await ifw.versao());     // 01.49.15
print(ifw.comoEstaLigado);     // caminho do binario, ou o canal no Android

await ifw.configuraInvoicy(
  ambiente: Ambiente.homologacao,
  cnpj: '00000000000000',
  chaveAcesso: '...',
  chaveParceiro: '...',
);

final retorno = await ifw.emiteDocumento(xml);
```

## Estado por plataforma

| Plataforma | Mecanismo | Estado |
|---|---|---|
| Windows x64 | `dart:ffi` sobre `InvoiCyFramework.dll` | funcional |
| Linux x64 | `dart:ffi` sobre `libInvoiCyFramework.so` | funcional |
| Android (API 24+) | `MethodChannel` + shim Java sobre o AAR | funcional |

Web, iOS e macOS estao fora: `dart:ffi` nao existe na web, e a biblioteca nativa nao e
compilada para as plataformas da Apple.

## Superficie

| API Dart | Funcao nativa | Android |
|---|---|---|
| `versao()` / `versaoBruta()` | `InvoiCyFramework_Versao` | completo |
| `configuraInvoicy(...)` | `AmbienteEmissao` + `ConfiguraInvoicy` | completo |
| `ambienteEmissao(...)` | `InvoiCyFramework_AmbienteEmissao` | completo |
| `configura(...)` | `InvoiCyFramework_Configura` | completo |
| `emiteDocumento(...)` | `InvoiCyFramework_EmiteDocumento` | completo |
| `configuraDiretorio(...)` | `InvoiCyFramework_ConfiguraDiretorio` | ressalva: nao tem efeito |
| `arquivoSistema(...)` | `InvoiCyFramework_ArquivoSistema` | ressalva: diretorio imprevisivel |
| `log()` | `InvoiCyFramework_Log` | ausente (e **stub no C++**: devolve vazio em toda parte) |
| `identidadeModulo()` | `InvoiCyFramework_GetModuleIdentity` | ausente |

A fonte unica dessa tabela e `lib/src/capacidades.dart` -- a fachada Dart consulta dali,
e o POC monta a tela dali. Consulte em tempo de execucao com
`Capacidades.disponivel(OperacaoSdk.x)` e `Capacidades.ressalva(...)` em vez de testar
`Platform.isAndroid`.

As demais funcoes da ABI (46 no total) entram conforme a necessidade. Os apelidos em
espanhol e ingles (`Emitir`, `Configurar`, `AmbienteEmision`, `Version`, ...) **nao**
entram: a API Dart tem um nome por operacao, e o cliente do Paraguai chama o mesmo
metodo. `InsereParametrosEmissao` tambem nao, por estar depreciada.

## Coisas que voce precisa saber antes de mexer aqui

**Toda a API e assincrona, inclusive `versao()`.** No Android o caminho e um
MethodChannel, e canal de plataforma no Flutter nao tem versao sincrona. Ou a API
publica e assincrona nas tres plataformas, ou ela tem formas diferentes por plataforma
-- e nesse caso o ERP volta a ter codigo condicional, que e exatamente o que este SDK
existe para evitar.

**A ABI expoe a versao em tres codificacoes numericas diferentes.** E o detalhe que mais
facilmente produz um numero plausivel e errado.

| Fonte | Exemplo | Como decodificar |
|---|---|---|
| `InvoiCyFramework_Versao` (desktop) | `15000` | `VersaoFrameworkInt` faz `sprintf("%lx", 0x015000)` -> `"15000"` e devolve o `atoi` disso. Os digitos DECIMAIS do retorno sao os HEXADECIMAIS da constante, e o zero a esquerda se perde. `versaoDeDigitosDecimais`. |
| `versaoNum` de `GetModuleIdentity` | `86016` | A constante crua (`0x015000`). Cada octeto e um par hexadecimal. `versaoDeConstanteCrua`. |
| `Versao()` da fachada Android | `14016` | **Igual ao desktop desde o AAR 1.40.16.** Ate a 1.40.15 devolvia a constante crua (`0x014015` = 81941), uma terceira codificacao. |

Tratar 15000 como BCD-hex daria `03.a9.8`; tratar 86016 como decimal daria `08.60.16`.
Duas maneiras de errar bonito. Por isso a decodificacao mora na implementacao de cada
plataforma, e nao na fachada: `versao()` expoe uma verdade so, a string.

Nota sobre o lado nativo: `sprintf("%lx", ...)` nao completa com zeros, e `atoi` para no
primeiro caractere nao numerico. Enquanto os octetos de versao seguirem BCD (apenas
digitos 0-9), tudo funciona. Uma versao com nibble hexadecimal -- 01.A0.00, por exemplo
-- produziria `"1a000"`, e `atoi` devolveria `1`. Vale saber antes de escolher um numero
de versao criativo.

**Ninguem libera as strings de retorno.** Os `char*` que a biblioteca devolve vem do
buffer circular `ultimo_retorno[10]` de `InterfaceBiblioteca.cpp`. Chamar `free` neles
corromperia o heap da biblioteca. As strings de **entrada**, sim, sao alocadas e
liberadas por nos.

**`ConfiguraDiretorio` devolve 1 sempre.** Ela nao valida se o diretorio existe ou e
gravavel. Retorno 1 significa "a chamada chegou", nao "o diretorio serve" -- por isso a
validacao real acontece do lado Dart.

**As credenciais sao gravadas POR AMBIENTE, e a ordem importa.** `ConfiguraInvoicy` le o
`AMBIENTE` vigente e o usa como chave em `BuscaEmpresa`/`InsereEmpresa`/`AtualizaEmpresa`.
Configurar as credenciais antes de definir o ambiente as grava sob o ambiente errado, e a
emissao depois procura uma empresa que nao existe -- **sem erro nenhum**, porque
`ConfiguraInvoicy` devolve 1 de qualquer jeito. Por isso `configuraInvoicy` exige o
`ambiente` como parametro obrigatorio e faz as duas chamadas na ordem certa: nesta API, a
ordem errada nao e expressavel.

**As chamadas sao serializadas.** A biblioteca tem dois mutexes internos; o shim Android
usa um executor de uma unica thread. Duas chamadas simultaneas nao corrompem estado, mas
uma espera a outra. No desktop cada chamada roda em uma isolate separada, que **reabre a
biblioteca pelo especificador guardado** -- nem `DynamicLibrary` nem ponteiros de funcao
atravessam a fronteira entre isolates, e o estado da biblioteca e do processo, entao
configurar aqui e emitir la funciona.

**Atualizacao pai/filho, e os nomes de arquivo.** O processo pode ter duas
InvoiCyFramework carregadas exportando os mesmos simbolos. `identidadeModulo()` diz qual
respondeu -- e a primeira chamada de qualquer diagnostico, e nao inicializa a biblioteca.

O nome do binario varia em quatro formatos, e o formato tem significado:

| Papel | Windows | Linux |
|---|---|---|
| pai | `InvoiCyFramework.dll` | `libInvoiCyFramework.so` |
| filho | `InvoiCyFramework_01_50_00.dll` | `InvoiCyFramework_01_50_00.so` |

**O filho no Linux nao tem o prefixo `lib`** (`PREFIX ""` no CMakeLists), enquanto a pai
tem -- nome distinto significa SONAME distinto, que e o ponto do arranjo. Nenhuma
verificacao pode assumir prefixo, extensao ou presenca do sufixo de versao: use
`identidade.pareceInvoicyFramework`, `extensao`, `versaoNoNome` e
`ehArtefatoVersionado` em vez de comparar strings.

Os digitos do sufixo sao **hexadecimais** (`isxdigit` + `strtoul base 16` em
`versaoDoNomeArquivo`), a mesma codificacao de `versaoNum`. E a pai deduz a versao do
filho **do nome do arquivo**, aceitando so o padrao exato `dd_dd_dd` -- um nome fora do
padrao e ignorado em silencio. Dai `identidade.nomeDivergeDaVersao`, que aponta o
artefato renomeado a mao: o nome diz uma versao, o binario tem outra, e a pai acredita
no nome.

## Onde o binario e procurado

`abreBibliotecaNativa` tenta, nesta ordem:

1. o caminho passado em `abre(caminhoBiblioteca: ...)`;
2. a variavel de ambiente `INVOICY_FRAMEWORK_LIB` -- valvula de escape para diagnostico
   em campo, sem recompilar nada;
3. o **nome puro**, deixando o carregador do sistema procurar ao lado do executavel: e o
   caso do app empacotado, porque o CMake do plugin poe o binario la;
4. o caminho dentro do pacote (`native/<plataforma>/x64/`): e o caso de `flutter test`.

## Ligacoes escritas a mao

`lib/src/bindings.dart` e manual, nao gerado. Com poucas funcoes, o que precisa ser lido
com atencao e exatamente o que codegen esconde: conversao de strings e posse de memoria.
`ffigen.yaml` esta configurado e comentado para quando a superficie completa entrar.

## Testes

```
flutter pub get
flutter test -r expanded
```

Os testes carregam o binario de `native/` por caminho absoluto e apontam o diretorio
corrente para uma pasta temporaria com acento no nome -- assim o banco e o log que a
biblioteca cria nao caem no repositorio, e o caminho acentuado e exercitado de verdade.

A verificacao mais forte grava, via `ArquivoSistema`, um arquivo de nome e conteudo
acentuados em `$BASEDIR/`, e le de volta com `utf8.decode`. Se ela passa, tres coisas
ficam provadas de uma vez: a conversao UTF-8 na ida, a preservacao no disco, e o efeito
real de `ConfiguraDiretorio`.
