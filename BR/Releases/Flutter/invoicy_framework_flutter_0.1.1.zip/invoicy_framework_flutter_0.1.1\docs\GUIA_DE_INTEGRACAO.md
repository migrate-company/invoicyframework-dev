# SDK Flutter do InvoiCyFramework

**Guia de integração**

Migrate · as versões exatas do pacote que você recebeu estão no `MANIFESTO.txt`

---

## Sumário

1. [O que é](#1-o-que-é)
2. [O que vem no pacote](#2-o-que-vem-no-pacote)
3. [Requisitos](#3-requisitos)
4. [Integrando ao seu aplicativo](#4-integrando-ao-seu-aplicativo)
5. [Primeiro uso](#5-primeiro-uso)
6. [Referência da API](#6-referência-da-api)
7. [Diferenças entre as plataformas](#7-diferenças-entre-as-plataformas)
8. [Versões](#8-versões)
9. [O aplicativo de exemplo](#9-o-aplicativo-de-exemplo)
10. [Distribuindo o seu aplicativo](#10-distribuindo-o-seu-aplicativo)
11. [Diagnóstico](#11-diagnóstico)
12. [O que este SDK ainda não cobre](#12-o-que-este-sdk-ainda-não-cobre)

---

## 1. O que é

O InvoiCyFramework é a biblioteca da Migrate para emissão de documentos fiscais —
NF-e, NFC-e, SAT/MFE, NFS-e e DE do Paraguai. Ela existe em duas formas: uma
biblioteca nativa em C/C++ (`.dll` no Windows, `.so` no Linux) e um AAR em Java
para Android.

Este SDK embrulha as duas e oferece **uma única API Dart** para as três
plataformas. O objetivo é direto: o código do seu aplicativo não deve precisar
saber em qual sistema está rodando.

```dart
// Este trecho é idêntico em Windows, Linux e Android.
final ifw = await InvoicyFramework.abre();
await ifw.configuraInvoicy(
  ambiente: Ambiente.homologacao,
  cnpj: '00000000000000',
  chaveAcesso: '...',
  chaveParceiro: '...',
);
final retorno = await ifw.emiteDocumento(xml);
```

Por baixo, Windows e Linux vão por `dart:ffi` direto na biblioteca nativa, e o
Android vai por um canal de plataforma sobre a fachada Java do AAR. Essa escolha
não aparece no seu código.

### Duas coisas que valem saber desde já

**Toda a API é assíncrona**, inclusive `versao()`, que no desktop seria
instantâneo. O motivo é o Android: canal de plataforma no Flutter não tem forma
síncrona. A alternativa seria a API ter formas diferentes conforme o sistema — e
aí o código condicional que este SDK existe para eliminar voltaria para o seu
aplicativo.

**As três plataformas não são idênticas.** O AAR do Android cobre um subconjunto
da biblioteca nativa. O SDK não finge o contrário: ele declara o que existe onde,
e você pode consultar isso em tempo de execução. A seção 7 traz a tabela.

---

## 2. O que vem no pacote

```
invoicy_framework_flutter_<versão>/
├── LEIA-ME.md                Início rápido
├── MANIFESTO.txt             Versões e SHA256 dos binários
├── CHANGELOG.md              Histórico do SDK
├── docs/
│   ├── GUIA_DE_INTEGRACAO.md    Este documento
│   └── GUIA_DE_INTEGRACAO.pdf
├── invoicy_framework/        O pacote. É isto que entra no seu pubspec.yaml.
│   ├── lib/                     API Dart
│   ├── native/
│   │   ├── windows/x64/InvoiCyFramework.dll
│   │   ├── linux/x64/libInvoiCyFramework.so
│   │   └── include/InvoiCyFramework.h
│   ├── android/
│   │   ├── src/                 Shim Java sobre o AAR
│   │   └── repo/                Repositório Maven com o AAR
│   ├── windows/CMakeLists.txt
│   └── linux/CMakeLists.txt
└── poc_invoicy/              Aplicativo de exemplo, com fontes
```

`invoicy_framework/` e `poc_invoicy/` ficam lado a lado de propósito: o exemplo
referencia o pacote por caminho relativo (`../invoicy_framework`), então ele
compila logo depois de extrair, sem ajuste nenhum.

O `MANIFESTO.txt` traz o SHA256 de cada binário. Vale conferir se você distribui
o aplicativo em ambiente regulado.

---

## 3. Requisitos

### Para desenvolver

| Item | Versão | Observação |
|---|---|---|
| Flutter | 3.19 ou superior | |
| Dart | 3.3 ou superior | Vem com o Flutter |

Além disso, o que a própria plataforma-alvo exige do Flutter:

**Windows** — Visual Studio 2022 com a carga de trabalho *Desenvolvimento para
desktop com C++*. E o **Modo de Desenvolvedor ligado**:

```
start ms-settings:developers
```

Sem ele, `flutter pub get` falha com *"Building with plugins requires symlink
support"* em qualquer projeto que dependa de um plugin. O Flutter cria symlinks
em `windows/flutter/ephemeral/.plugin_symlinks/`, e o Windows só permite symlink
para administrador ou com o Modo de Desenvolvedor ativo. É exigência de
desenvolvimento, não de execução: quem instala o aplicativo compilado não precisa
de nada disso.

**Linux** — as dependências de build do Flutter desktop:

```bash
sudo apt install -y clang cmake ninja-build pkg-config libgtk-3-dev
```

**Android** — Android SDK 36, JDK 17 (exigido pelo Android Gradle Plugin 8.13) e
o NDK que a sua versão do Flutter pedir. Instale os componentes pelo Android
Studio; deixar o Gradle baixá-los sozinho tem dado problema com as
`cmdline-tools` recentes.

### Para executar

O que a máquina do usuário final precisa ter.

**Windows x64** — nada. A `InvoiCyFramework.dll` é autocontida: importa apenas
`KERNEL32`, `WS2_32`, `ADVAPI32`, `CRYPT32` e `WINSPOOL`, todas do sistema.
OpenSSL, curl, libxml2, zlib e o runtime do MSVC estão linkados estaticamente.
Não há redistribuível para instalar.

**Linux x64** — quatro bibliotecas, todas presentes por padrão na maioria das
distribuições:

| Família | Pacotes |
|---|---|
| Debian / Ubuntu | `libcurl4 libxml2 libusb-1.0-0 zlib1g libstdc++6` |
| RHEL / CentOS / Rocky | `libcurl libxml2 libusbx zlib libstdc++` |

O OpenSSL **não** está na lista: ele é linkado estaticamente na biblioteca.

O `.so` deste pacote é compilado em CentOS 7, com glibc 2.17. Isso é
deliberado: um binário compilado em glibc antigo carrega em sistemas mais novos,
enquanto o contrário não vale. Se tiver dúvida sobre um ambiente específico,
`ldd` responde em um segundo:

```bash
ldd invoicy_framework/native/linux/x64/libInvoiCyFramework.so | grep "not found"
```

Silêncio significa que está tudo resolvido.

**Android** — API 24 (Android 7.0) ou superior. Arquiteturas conforme o AAR.

**Não suportados:** web, iOS e macOS. O SDK depende de `dart:ffi` e `dart:io`,
que não existem na web, e a biblioteca nativa não é compilada para as
plataformas da Apple.

---

## 4. Integrando ao seu aplicativo

### 4.1 Onde colocar o pacote

Extraia o zip e deixe `invoicy_framework/` em algum lugar estável — dentro do seu
repositório, ao lado dele, ou numa pasta de dependências da empresa. O caminho é
o que você vai referenciar no `pubspec.yaml`, então evite pasta de downloads.

### 4.2 Declarar a dependência

No `pubspec.yaml` do seu aplicativo:

```yaml
dependencies:
  flutter:
    sdk: flutter

  invoicy_framework:
    path: ../invoicy_framework    # ajuste para o caminho onde você extraiu
```

E então:

```bash
flutter pub get
```

Nada mais. Os binários nativos são colocados junto do executável pelo CMake do
próprio plugin, e o AAR do Android vem do repositório Maven que acompanha o
pacote — não há passo manual de cópia de DLL nem de configuração de repositório.

> Se no futuro a Migrate publicar o pacote num Git privado ou num pub privado,
> a mudança é trocar `path:` por `git:` ou `hosted:`. O seu código Dart não muda.

### 4.3 O que muda em cada plataforma

**Windows e Linux:** nada. O CMake do plugin declara a biblioteca nativa como
artefato acompanhante, e o `flutter build` a copia para junto do executável.

**Android:** o plugin exige `minSdk 24`. Se o seu aplicativo estiver abaixo
disso, ajuste em `android/app/build.gradle.kts`:

```kotlin
android {
    defaultConfig {
        minSdk = 24
    }
}
```

Se você usa ofuscação com R8/ProGuard, mantenha a fachada Java do AAR:

```proguard
-keep class com.migrate.gerentedocumento.** { *; }
```

### 4.4 Verificando que funcionou

Compile o exemplo antes de mexer no seu aplicativo. Se ele roda, o ambiente está
correto e qualquer problema seguinte é do seu lado — o que economiza bastante
tempo de investigação:

```bash
cd poc_invoicy
flutter pub get
flutter run -d windows     # ou -d linux, ou -d <id do dispositivo Android>
```

O `-d` **não é opcional**. A maioria das máquinas tem Chrome e Edge listados como
dispositivos, e o SDK não existe na web: sem o `-d`, o Flutter pode escolher um
alvo em que a compilação falha.

---

## 5. Primeiro uso

```dart
import 'package:invoicy_framework/invoicy_framework.dart';

Future<void> exemplo() async {
  // 1. Liga o SDK à plataforma corrente.
  final ifw = await InvoicyFramework.abre();

  print(await ifw.versao());        // 01.49.15
  print(ifw.comoEstaLigado);        // caminho da biblioteca, ou o canal

  // 2. Ambiente e credenciais, em uma chamada só.
  await ifw.configuraInvoicy(
    ambiente: Ambiente.homologacao,
    cnpj: '00000000000000',          // só dígitos
    chaveAcesso: 'sua-chave-de-acesso',
    chaveParceiro: 'sua-chave-de-parceiro',
  );

  // 3. Operação. Quem decide o que acontece é o elemento raiz do XML.
  final retorno = await ifw.emiteDocumento(xmlDoDocumento);
  print(retorno);
}
```

### A ordem de configuração importa, e o SDK resolve isso por você

As credenciais são gravadas **por ambiente**: internamente, `ConfiguraInvoicy` lê
o ambiente vigente e o usa como chave ao gravar a empresa. Configurar as
credenciais antes de definir o ambiente as grava sob o ambiente errado, e a
emissão depois procura uma empresa que não existe — **sem erro nenhum**, porque
`ConfiguraInvoicy` devolve sucesso de qualquer jeito.

É uma falha silenciosa clássica na integração com a biblioteca nativa. Por isso
`configuraInvoicy` exige o `ambiente` como parâmetro obrigatório e faz as duas
chamadas na ordem certa: nesta API, a ordem errada não é expressável.

Se você usar `ambienteEmissao()` isoladamente para alternar entre produção e
homologação, **reenvie as credenciais depois**.

### Tratamento de erro

O SDK converte código de retorno em exceção tipada. Todas descendem de
`InvoicyFrameworkException`:

```dart
try {
  await ifw.emiteDocumento(xml);
} on OperacaoNaoSuportadaException catch (e) {
  // A plataforma corrente não tem essa operação. e.mensagem diz o porquê
  // e, quando existe, qual a alternativa.
} on ChamadaNativaException catch (e) {
  // A biblioteca devolveu código de falha. e.funcao e e.codigo identificam.
} on BibliotecaNativaException catch (e) {
  // A biblioteca não pôde ser carregada. e.caminhosTentados lista onde
  // se procurou — é a informação que resolve o problema.
}
```

---

## 6. Referência da API

Tudo devolve `Future`. Os nomes em `MAIÚSCULAS` na coluna da direita são as
funções correspondentes na biblioteca nativa, para quem precisa cruzar com a
documentação em C.

### Ciclo de vida

| Membro | O que faz |
|---|---|
| `static Future<InvoicyFramework> abre({String? caminhoBiblioteca})` | Liga o SDK à plataforma. No desktop carrega a biblioteca; no Android prepara o canal. `caminhoBiblioteca` vale só no desktop, para apontar um binário específico em diagnóstico. |
| `static InvoicyFramework? get instanciaAberta` | A instância aberta, ou `null`. |
| `static void descartaInstancia()` | Descarta a instância em memória. Não finaliza a biblioteca nativa. |
| `String get comoEstaLigado` | Caminho do binário no desktop, nome do canal no Android. Primeira coisa a olhar em diagnóstico. |

Use **uma instância por processo**. A biblioteca tem estado global; duas
instâncias Dart não dariam dois estados isolados, dariam a ilusão de isolamento.

### Operações

| Método | Função nativa |
|---|---|
| `Future<String> versao()` | `InvoiCyFramework_Versao` |
| `Future<int> versaoBruta()` | idem, sem decodificar — ver seção 8 |
| `Future<void> configuraInvoicy({required Ambiente ambiente, required String cnpj, required String chaveAcesso, required String chaveParceiro})` | `AmbienteEmissao` + `ConfiguraInvoicy` |
| `Future<void> ambienteEmissao(Ambiente ambiente)` | `InvoiCyFramework_AmbienteEmissao` |
| `Future<void> configura(String parametro, String valor)` | `InvoiCyFramework_Configura` |
| `Future<String> emiteDocumento(String xmlEntrada, {String xmlParametro = ''})` | `InvoiCyFramework_EmiteDocumento` |
| `Future<void> configuraDiretorio(String diretorio)` | `InvoiCyFramework_ConfiguraDiretorio` |
| `Future<void> arquivoSistema(String nome, String dados)` | `InvoiCyFramework_ArquivoSistema` |
| `Future<String> log()` | `InvoiCyFramework_Log` |
| `Future<IdentidadeModulo> identidadeModulo()` | `InvoiCyFramework_GetModuleIdentity` |

### `emiteDocumento` não emite só

O nome vem da ABI nativa, mas **quem decide a operação é o elemento raiz do
XML**, não o método. A biblioteca inspeciona esse nó e roteia:

| Raiz do XML | Operação |
|---|---|
| `<Documento>` | Emissão |
| `<Consulta>` | Consulta |
| `<Evento>` | Cancelamento, carta de correção e demais eventos |

O `xmlParametro` complementa, e em várias operações vai vazio.

Consultar é a melhor forma de validar a integração ponta a ponta antes de emitir
de verdade: exercita rede, autenticação e o caminho XML inteiro, é repetível, e
não queima sequencial nem cria documento fiscal.

### `Ambiente`

```dart
enum Ambiente { producao, homologacao }
```

Existe para não passar `1` e `2` crus. Trocar os dois números significa emitir em
produção achando que se está em homologação — um enum custa nada e torna esse
erro impossível.

### Concorrência

As chamadas são serializadas: no desktop pelos dois mutexes internos da
biblioteca, no Android por um executor de uma única thread. Duas chamadas
simultâneas não corrompem estado, mas uma espera a outra — e isso vale igual nas
três plataformas.

No desktop, cada chamada roda em uma *isolate* separada, e no Android em uma
thread do shim. A interface do seu aplicativo **não congela** durante uma
emissão, que faz rede e assinatura.

---

## 7. Diferenças entre as plataformas

O AAR do Android não é uma reimplementação fiel da biblioteca nativa: é outro
projeto, em Java, que cobre um subconjunto. O SDK declara isso em vez de fingir
uniformidade.

| Operação | Windows | Linux | Android |
|---|---|---|---|
| `versao` | completo | completo | completo |
| `configuraInvoicy` | completo | completo | completo |
| `ambienteEmissao` | completo | completo | completo |
| `configura` | completo | completo | completo |
| `emiteDocumento` | completo | completo | completo |
| `configuraDiretorio` | completo | completo | **ressalva** — existe, mas **não tem efeito**: apenas registra no log. O diretório de trabalho é definido pela própria biblioteca. |
| `arquivoSistema` | completo | completo | **ressalva** — grava no diretório padrão da biblioteca, não no que você configurou. O caminho final não é previsível. |
| `log` | **ressalva** — devolve sempre vazio | **ressalva** — idem | **ausente** |
| `identidadeModulo` | completo | completo | **ausente** |

Uma operação com **ressalva** funciona e não lança exceção — ela só não faz
exatamente o mesmo. Uma operação **ausente** lança
`OperacaoNaoSuportadaException`.

**Sobre `log()`:** ela devolve string vazia em todas as plataformas. A
implementação em C++ (`Log::conteudoLog()`) é um stub que retorna `NULL`. Não
depende de configuração nenhuma. Ela continua exposta porque faz parte da ABI,
mas não sirva de base para diagnóstico.

### Consultando isso em tempo de execução

Em vez de escrever `if (Platform.isAndroid)`, pergunte ao SDK:

```dart
import 'package:invoicy_framework/invoicy_framework.dart';

if (Capacidades.disponivel(OperacaoSdk.identidadeModulo)) {
  final id = await ifw.identidadeModulo();
}

// Ressalva a exibir junto da operação, ou null quando não há.
final aviso = Capacidades.ressalva(OperacaoSdk.configuraDiretorio);
```

- `Capacidades.disponivel(op)` — `false` apenas quando a operação é **ausente**.
  Operação **degradada** devolve `true`: ela funciona, só não faz exatamente o
  mesmo.
- `Capacidades.suporte(op)` — `completo`, `degradado` ou `ausente`.
- `Capacidades.ressalva(op)` — o texto que explica a ressalva, pronto para
  exibir.

Chamar uma operação ausente lança `OperacaoNaoSuportadaException`, com a
explicação e, quando existe, a alternativa. É preferível a fingir sucesso.

---

## 8. Versões

A biblioteca expõe a versão em **codificações numéricas diferentes conforme a
origem**. É a armadilha mais recorrente da integração, e a única que produz um
número plausível e errado em vez de um erro.

| Origem | Exemplo | O que é |
|---|---|---|
| `Versao()` no desktop | `15000` | Os dígitos **decimais** do retorno são os dígitos **hexadecimais** da constante interna, e o zero à esquerda se perde |
| `versaoNum` de `identidadeModulo()` | `86016` | A constante crua |
| `Versao()` no Android | `14016` | Igual ao desktop desde o AAR 1.40.16 |

**A recomendação é simples: use `versao()`, que devolve `String`.** Ela é a única
representação que o SDK trata como verdade, e cada plataforma sabe decodificar a
sua. `versaoBruta()` existe para diagnóstico; **não compare esse número entre
plataformas**.

O `MANIFESTO.txt` do pacote registra as três versões relevantes: a do pacote
Flutter, a da biblioteca nativa e a do AAR.

---

## 9. O aplicativo de exemplo

`poc_invoicy/` é um aplicativo de diagnóstico: um botão por operação, com os
campos de entrada logo abaixo de cada botão, e um painel que mostra o retorno
cru. O cabeçalho exibe a plataforma, a versão da biblioteca e — no desktop — a
identidade do módulo carregado.

Ele serve para três coisas:

1. **Validar o ambiente** antes de você integrar. Se ele roda, o problema
   seguinte é do seu código.
2. **Entender o formato** de cada chamada, com XML de exemplo.
3. **Diagnosticar em campo**, se um cliente seu reportar comportamento
   inesperado: reproduzir ali isola o SDK do seu aplicativo.

Os botões consultam `Capacidades` e se desabilitam sozinhos onde a operação não
existe, com a explicação no tooltip — é também uma demonstração de como tratar
isso na sua interface.

### Troque as credenciais antes de usar

O exemplo abre já preenchido com dados de **homologação da Migrate**, para rodar
com um duplo clique. Os três valores que identificam você no invoiCy estão em
`poc_invoicy/lib/dados_homologacao.dart`:

| Constante | Vem com | O que fazer |
|---|---|---|
| `cnpjInicial` | CNPJ de teste da Migrate | trocar pelo seu |
| `chaveAcessoInicial` | em branco | preencher com a sua |
| `chaveParceiroInicial` | chave de teste da Migrate | trocar pela sua |

Duas formas de trocar, ambas válidas:

1. **Na tela**, a cada execução — todos os campos são editáveis em tempo de
   execução, sem recompilar. Bom para um teste rápido.
2. **No arquivo**, se você vai usar o exemplo com frequência e não quer
   redigitar. Edite as três constantes e recompile.

A chave de acesso vem em branco de propósito: é a credencial que de fato
autentica, e por isso não viaja dentro de um pacote público. Sem preenchê-la,
`configuraInvoicy` falha com erro de autenticação — que é o comportamento
desejado, e o lembrete de que os outros dois valores também precisam ser os seus.

O motivo prático de trocar o CNPJ, além do óbvio: emitir em homologação com o
CNPJ da Migrate faz os documentos aparecerem na conta de teste **dela**, não na
sua.

---

## 10. Distribuindo o seu aplicativo

**Windows.** `flutter build windows` coloca a `InvoiCyFramework.dll` junto do
`.exe`, em `build\windows\x64\runner\Release\`. Distribua a pasta inteira. Não há
redistribuível a instalar.

**Linux.** `flutter build linux` coloca a `libInvoiCyFramework.so` em
`build/linux/x64/release/bundle/lib/`. Distribua o bundle inteiro. Confira as
dependências de sistema da seção 3 no ambiente-alvo.

**Android.** `flutter build apk` ou `flutter build appbundle`. O AAR e o shim
entram no pacote automaticamente.

Em todos os casos, a biblioteca nativa cria arquivos de trabalho (banco de dados,
XMLs de alerta) no diretório configurado por `configuraDiretorio` — ou, no
Android, no diretório padrão dela. Garanta que esse diretório existe e é
gravável pelo usuário que executa o aplicativo. Em Windows, `C:\Program Files\`
não serve.

---

## 11. Diagnóstico

### `BibliotecaNativaException` na inicialização

A exceção lista os caminhos tentados. O SDK procura nesta ordem:

1. O caminho passado em `abre(caminhoBiblioteca: ...)`, se houver.
2. A variável de ambiente `INVOICY_FRAMEWORK_LIB`.
3. O nome puro do arquivo, deixando o carregador do sistema procurar ao lado do
   executável — é o caso do aplicativo empacotado.
4. O caminho dentro do pacote — é o caso de `flutter test`.

A variável `INVOICY_FRAMEWORK_LIB` é uma válvula de escape para diagnóstico em
campo: aponta um binário específico sem recompilar nada.

No Linux, se a biblioteca é encontrada mas não carrega, quase sempre é
dependência de sistema faltando. O `ldd` diz qual:

```bash
ldd caminho/para/libInvoiCyFramework.so | grep "not found"
```

### `flutter pub get` falha com *"Building with plugins requires symlink support"*

Modo de Desenvolvedor desligado no Windows. Seção 3.

### A emissão devolve erro de empresa não encontrada

Quase sempre é ordem de configuração: o ambiente foi trocado depois das
credenciais. Reenvie `configuraInvoicy` — ele faz as duas chamadas na ordem
certa. Ver seção 5.

### O aplicativo Android compila mas quebra ao chamar o SDK

Verifique o `minSdk` (precisa ser 24 ou mais) e, se você usa R8/ProGuard, a regra
de `keep` da seção 4.3.

### Qual binário está respondendo?

No desktop, a biblioteca tem um mecanismo de atualização automática em que o
processo pode ter **duas** InvoiCyFramework carregadas — a instalada e a baixada
— exportando os mesmos símbolos. `identidadeModulo()` diz qual delas atendeu:

```dart
final id = await ifw.identidadeModulo();
print(id.papel);      // pai | filho
print(id.arquivo);    // caminho completo do binário que respondeu
print(id.versao);
```

É a primeira pergunta de qualquer diagnóstico de comportamento divergente, e a
chamada não inicializa a biblioteca — funciona mesmo com a instalação com
problema.

### Suporte

Ao abrir um chamado, inclua:

- O `MANIFESTO.txt` do pacote que você está usando (traz as três versões).
- A saída de `comoEstaLigado` e de `identidadeModulo()`.
- No Linux, a saída de `ldd` na biblioteca.
- O XML de entrada, com as credenciais removidas.

---

## 12. O que este SDK ainda não cobre

Honestidade sobre o escopo evita descoberta tardia.

**A ABI nativa tem 46 funções; este SDK expõe 9.** As escolhidas cobrem
configuração, emissão, consulta e diagnóstico — o caminho principal de um ERP. As
demais (impressão, SAT/MFE, relatórios de pendentes, sequenciais, serviços) podem
entrar conforme a necessidade. Fale com a Migrate.

**`EmiteDocumentoJSON` não está exposta.** O layout de integração em JSON existe
na biblioteca nativa, mas **não** na fachada Android. Expor só no desktop
quebraria a promessa de código único. Se o JSON for necessário para você, é uma
conversa sobre o AAR antes de ser uma conversa sobre o SDK.

**Os apelidos em espanhol e inglês não entram.** A ABI tem `Version`, `Emitir`,
`Configurar`, `AmbienteEmision` e outros, duplicando funções que já existem. A
API Dart tem **um nome por operação** — inclusive para quem integra no Paraguai.

**`InsereParametrosEmissao` não entra.** Está depreciada na biblioteca.

**iOS, macOS e web estão fora**, e não por decisão de escopo: a biblioteca nativa
não é compilada para as plataformas da Apple, e `dart:ffi` não existe na web.

*InvoiCyFramework e InvoiCy são produtos da Migrate.*
