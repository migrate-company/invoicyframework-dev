library;

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:invoicy_framework/invoicy_framework.dart';
import 'package:invoicy_framework/src/impl_canal.dart';

/// Trava o contrato do canal com o shim Java.
///
/// Existe por causa de um defeito que chegou ao cliente: o `_chama<T>` original
/// rejeitava retorno nulo sempre que `T != Null`, e para `T == void` esse teste
/// da verdadeiro. Resultado: TODA operacao de configuracao falhava no Android
/// com `ChamadaNativaException: ... o canal devolveu nulo`, incluindo o
/// `configuraInvoicy`, que e a primeira coisa que qualquer integracao faz.
///
/// O shim responde `success(null)` para as operacoes sem retorno. Isso e o
/// resultado NORMAL delas -- quem confere o codigo da fachada Java e o
/// `exigeUm` do lado Java, que converte retorno != 1 em PlatformException.
///
/// Estes testes rodam no desktop com o canal mockado: eles verificam a camada
/// Dart, nao o AAR.
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  const MethodChannel canal = MethodChannel(ImplCanal.nomeCanal);
  final List<MethodCall> recebidas = <MethodCall>[];
  Object? resposta;
  PlatformException? erro;

  setUp(() {
    recebidas.clear();
    resposta = null;
    erro = null;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(canal, (MethodCall chamada) async {
      recebidas.add(chamada);
      if (erro != null) {
        throw erro!;
      }
      return resposta;
    });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(canal, null);
  });

  final ImplCanal impl = ImplCanal();

  group('operacoes sem retorno aceitam nulo', () {
    test('configuraInvoicy nao lanca quando o shim responde success(null)', () {
      // O caso que quebrou em campo.
      return expectLater(
        impl.configuraInvoicy(
          ambiente: Ambiente.homologacao,
          cnpj: '00000000000000',
          chaveAcesso: 'x',
          chaveParceiro: 'y',
        ),
        completes,
      );
    });

    test('configuraInvoicy manda o ambiente junto, numa chamada so', () async {
      // A ordem (ambiente antes das credenciais) e responsabilidade do shim; o
      // que a camada Dart garante e que o ambiente viaja na mesma chamada, para
      // nao existir janela em que as credenciais sejam gravadas sob o ambiente
      // anterior.
      await impl.configuraInvoicy(
        ambiente: Ambiente.producao,
        cnpj: '123',
        chaveAcesso: 'a',
        chaveParceiro: 'b',
      );
      expect(recebidas.single.method, 'configuraInvoicy');
      expect(
        recebidas.single.arguments,
        <String, Object?>{
          'ambiente': 1,
          'cnpj': '123',
          'chaveAcesso': 'a',
          'chaveParceiro': 'b',
        },
      );
    });

    test('as demais operacoes sem retorno tambem aceitam nulo', () {
      return expectLater(
        Future.wait<void>(<Future<void>>[
          impl.ambienteEmissao(Ambiente.homologacao),
          impl.configura('AMBIENTE', '2'),
          impl.configuraDiretorio('/tmp/x'),
          impl.arquivoSistema('a.txt', 'conteudo'),
        ]),
        completes,
      );
    });
  });

  group('operacoes com retorno exigem valor', () {
    test('versao devolve o inteiro do shim', () async {
      resposta = 14016;
      expect(await impl.versaoBruta(), 14016);
    });

    test('versao lanca se o shim devolver nulo', () {
      resposta = null;
      return expectLater(
        impl.versaoBruta(),
        throwsA(isA<ChamadaNativaException>()),
      );
    });

    test('emiteDocumento devolve a string do shim', () async {
      resposta = '<Retorno/>';
      expect(await impl.emiteDocumento('<Consulta/>', ''), '<Retorno/>');
    });

    test('emiteDocumento lanca se o shim devolver nulo', () {
      resposta = null;
      return expectLater(
        impl.emiteDocumento('<Consulta/>', ''),
        throwsA(isA<ChamadaNativaException>()),
      );
    });
  });

  group('erros da plataforma viram excecao do SDK', () {
    test('PlatformException vira ChamadaNativaException', () {
      erro = PlatformException(code: 'ConfiguraInvoicy', message: 'devolveu 0');
      return expectLater(
        impl.configura('X', 'Y'),
        throwsA(isA<ChamadaNativaException>()),
      );
    });
  });

  group('decodificacao de versao', () {
    test('usa a regra do desktop desde o AAR 1.40.16', () {
      // 0x014016 -> "14016" -> 14016, o mesmo atoi(sprintf("%lx", ...)) do C++.
      expect(impl.formataVersao(14016), '01.40.16');
      expect(impl.formataVersao(15000), '01.50.00');
    });
  });
}
