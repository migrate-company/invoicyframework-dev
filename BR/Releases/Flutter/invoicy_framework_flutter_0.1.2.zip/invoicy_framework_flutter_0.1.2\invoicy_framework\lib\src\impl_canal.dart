import 'package:flutter/services.dart';

import 'ambiente.dart';
import 'capacidades.dart';
import 'excecoes.dart';
import 'identidade_modulo.dart';
import 'plataforma.dart';
import 'versao.dart';

/// Implementacao para Android, sobre a fachada Java do AAR via MethodChannel.
///
/// O shim Java roda tudo num executor de uma thread, o que reproduz no Android
/// a serializacao que os mutexes internos garantem no nativo -- o contrato de
/// concorrencia do SDK vale igual nas tres plataformas.
class ImplCanal implements ImplPlataforma {
  ImplCanal();

  static const String nomeCanal = 'info.migrate/invoicy_framework';

  static const MethodChannel _canal = MethodChannel(nomeCanal);

  @override
  String get descricao => 'MethodChannel $nomeCanal → AAR '
      'com.migrate.gerentedocumento.InvoiCyFramework';

  /// Operacao que **espera** um valor de volta: `versao`, `emiteDocumento`.
  ///
  /// Nulo aqui e erro de verdade -- o shim respondeu `success(null)` para algo
  /// que deveria devolver conteudo.
  Future<T> _pede<T extends Object>(
    String metodo, [
    Map<String, Object?>? argumentos,
  ]) async {
    final T? retorno = await _invoca<T>(metodo, argumentos);
    if (retorno == null) {
      throw ChamadaNativaException(
        funcao: metodo,
        codigo: 0,
        detalhe: 'o canal devolveu nulo',
      );
    }
    return retorno;
  }

  /// Operacao **sem retorno**: configuracao, gravacao de arquivo.
  ///
  /// Para estas o shim responde `success(null)`, e **nulo e o resultado
  /// normal** -- quem confere o codigo da fachada Java e o `exigeUm` do lado
  /// Java, que transforma retorno != 1 em `PlatformException`.
  ///
  /// Esta separacao entre "pede" e "executa" existe porque a versao anterior
  /// tinha um unico `_chama<T>` que rejeitava nulo quando `T != Null`. Para
  /// `T == void` esse teste da verdadeiro, entao TODA operacao de configuracao
  /// falhava no Android com "o canal devolveu nulo", inclusive o
  /// `configuraInvoicy`. Decidir isso por comparacao de tipo em tempo de
  /// execucao era fragil; agora quem chama diz o que espera, e o compilador
  /// ajuda.
  Future<void> _executa(
    String metodo, [
    Map<String, Object?>? argumentos,
  ]) =>
      _invoca<void>(metodo, argumentos);

  /// Traduz o erro da plataforma numa excecao do SDK.
  Future<T?> _invoca<T>(String metodo, Map<String, Object?>? argumentos) async {
    try {
      return await _canal.invokeMethod<T>(metodo, argumentos);
    } on MissingPluginException {
      throw OperacaoNaoSuportadaException(
        operacao: metodo,
        plataforma: Capacidades.plataforma,
        alternativa: 'a fachada Java do AAR nao implementa esta operacao',
      );
    } on PlatformException catch (erro) {
      throw ChamadaNativaException(
        funcao: metodo,
        codigo: 0,
        detalhe: '${erro.message} (${erro.details})',
      );
    }
  }

  @override
  Future<int> versaoBruta() => _pede<int>('versao');

  /// **Mesma codificacao do desktop desde o AAR 1.40.16.**
  ///
  /// Ate a 1.40.15 a fachada Java devolvia a constante crua (`0x014015`), uma
  /// terceira codificacao que so existia no Android; decodificar aquilo com a
  /// regra do desktop dava "08.19.41". A fachada passou a aplicar o mesmo
  /// `atoi(sprintf("%lx", ...))` do C++, entao as duas plataformas devolvem o
  /// mesmo numero para a mesma versao e este metodo e identico ao do
  /// [ImplFfi].
  ///
  /// Mantido como override explicito, e nao herdado, porque a divergencia e uma
  /// propriedade do binario de cada plataforma, nao da fachada Dart: se um AAR
  /// antigo voltar a circular, e aqui que se trata.
  @override
  String formataVersao(int bruto) => versaoDeDigitosDecimais(bruto);

  @override
  Future<void> configuraInvoicy({
    required Ambiente ambiente,
    required String cnpj,
    required String chaveAcesso,
    required String chaveParceiro,
  }) =>
      // O shim faz AmbienteEmissao antes de ConfiguraInvoicy, como no desktop.
      _executa('configuraInvoicy', <String, Object?>{
        'ambiente': ambiente.codigo,
        'cnpj': cnpj,
        'chaveAcesso': chaveAcesso,
        'chaveParceiro': chaveParceiro,
      });

  @override
  Future<void> ambienteEmissao(Ambiente ambiente) =>
      _executa('ambienteEmissao', <String, Object?>{
        'ambiente': ambiente.codigo,
      });

  @override
  Future<void> configura(String parametro, String valor) =>
      _executa('configura', <String, Object?>{
        'parametro': parametro,
        'valor': valor,
      });

  @override
  Future<String> emiteDocumento(String xmlEntrada, String xmlParametro) =>
      _pede<String>('emiteDocumento', <String, Object?>{
        'xmlEntrada': xmlEntrada,
        'xmlParametro': xmlParametro,
      });

  /// Existe, **mas nao tem efeito**: a fachada Java apenas registra no log.
  /// Chamamos de qualquer forma, para o comportamento ser o da biblioteca e nao
  /// uma invencao nossa. Quem avisa e `Capacidades.ressalva`.
  @override
  Future<void> configuraDiretorio(String diretorio) =>
      _executa('configuraDiretorio', <String, Object?>{
        'diretorio': diretorio,
      });

  /// Grava no **diretorio padrao da biblioteca**, nao no configurado -- o
  /// caminho final nao e previsivel do lado Dart.
  @override
  Future<void> arquivoSistema(String nome, String dados) =>
      _executa('arquivoSistema', <String, Object?>{
        'nome': nome,
        'dados': dados,
      });

  @override
  Future<String> log() async => throw OperacaoNaoSuportadaException(
        operacao: 'InvoiCyFramework_Log',
        plataforma: Capacidades.plataforma,
        alternativa: 'nao existe na fachada Java',
      );

  @override
  Future<IdentidadeModulo> identidadeModulo() async =>
      throw OperacaoNaoSuportadaException(
        operacao: 'InvoiCyFramework_GetModuleIdentity',
        plataforma: Capacidades.plataforma,
        alternativa: 'nao existe na fachada Java, e nao ha o que reportar: a '
            'atualizacao pai/filho e exclusiva do binario nativo',
      );

  @override
  void descarta() {
    // A instancia Java vive no plugin, atrelada ao engine. Nada a liberar aqui.
  }
}
