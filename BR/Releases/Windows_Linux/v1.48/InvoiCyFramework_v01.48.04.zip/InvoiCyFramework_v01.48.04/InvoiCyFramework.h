/*
 * possolution.h
 *
 *  Created on: Nov 5, 2018
 *      Author: ptesche
 */

#ifndef INVOICYFRAMEWORK_H_
#define INVOICYFRAMEWORK_H_

#ifdef WIN32
#define DECLDIR
#define STDCAL	 __stdcall
#else
#define DECLDIR extern
#define STDCAL
#endif


#ifndef WIN32
extern "C"
{
#endif
/**
* Emite um documento fiscal ou envia um documento para o invoiCy
* @param xmlEntrada Dados em formato XML do documento que será emitido ou enviado para o invoiCy
* @param xmlParametro Dados em formato XML contendo os parâmetros de envio ou consulta
* @return Dados do recibo em formato XML ou o resultado do envio
*/
	DECLDIR char* STDCAL InvoiCyFramework_EmiteDocumento(char* xmlEntrada, char* xmlParametro);
	DECLDIR char* STDCAL InvoiCyFramework_Emitir(char* jsonEntrada, char* jsonParametros);

/**
* Emite um documento fiscal ou envia um documento para o invoiCy
* @param jsonEntrada Dados em formato JSON do documento que será emitido ou enviado para o invoiCy no layout de integração
* @param jsonParametro Dados em formato JSON contendo os parâmetros de envio ou consulta
* @return Dados do recibo em formato JSON ou o resultado do envio
*/
	DECLDIR char* STDCAL InvoiCyFramework_EmiteDocumentoJSON(char* jsonEntrada, char* jsonParametros);

/**
* #### Este método coloca o FW em estado de contingência - As emissões que forem solicitadas na sequência serão realizadas em tpEmis 9 ####
* Descarta o documento informado e emite em contingência
* @param xmlEntrada Dados em formato XML do documento que será descartado e emitido em contingência
* @return Dados do recibo em formato XML ou o resultado do envio
*/
	DECLDIR char* STDCAL InvoiCyFramework_EmiteContingencia(char* xmlEntrada);


/**
* Imprime o documento informado
* @param xmlEntrada Dados em formato XML do documento que será impresso
* @return Dados do recibo em formato XML ou o resultado do envio
*/
	DECLDIR int STDCAL InvoiCyFramework_ImprimeDocumento(char* xmlRecibo);

/**
* Imprime o documento informado, permite o envio de parâmetros adicionais
* @param xmlEntrada Dados em formato XML do documento que será impresso
* @xmlParametros parâmetros adicionais...
* @return Dados do recibo em formato XML ou o resultado do envio
*/
DECLDIR int STDCAL InvoiCyFramework_ImprimeDocumentoEx(char* xmlRecibo, char* xmlParametros);

/**
* Força envio dos documentos pendentes
* @return Inteiro indicando quantidade de documentos enviados. 0 caso não tenha documento a ser enviado ou -1 em caso de erro.
*/
DECLDIR int STDCAL InvoiCyFramework_EnviaDocumentosPendentes();

/**
* Força envio de uma quantidade especificada de documentos pendentes
* @param Inteiro indicando quantidade de documentos que devem ser enviados. Se for passado um valor menor ou igual a zero, serão enviados todos os documentos pendentes.
* @return Dados xml contendo o resultado do envio.
*/
DECLDIR char* STDCAL InvoiCyFramework_EnviaDocumentosPendentesQuantidade(int quantidade);

/**
* Configura os parâmetros de emissão para o contribuinte estadual
* @param UF N[umero de dois dígitos referente ao código da UF que está sendo configurada
* @param idToken ID referente ao CSC
* @param CSC Código CSC do contribuinte cadastrado na SEFAZ
* @param contingencia Tipo de contingência do NFC-e sendo: 0 = Sem contingência, 1 = contingência offline, 2 = contingência SAT
* @param consultaQRcode URL de consulta do QRCode que será informado no DANFE
* @param consultaChave URL de consulta da chave de acesso do documento que será informado no DANFE
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_InsereParametrosEmissao(int UF, int idToken, char * CSC, int contingencia, char * consultaQRcode, char * consultaChave);


/**
* Envia configurações opcionais relacionadas a UF informada
* @param UF - Código da UF que será configurado
* @param parametro - Nome do parâmetro de configuração
* @param valor - Valor do parâmetro de configuração
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_ConfiguraUF(int UF, char * parametro, char * valor);

/**
* Configura os parâmetros de emissão do InvoiCy
* @param CNPJ - CNPJ sem pontos, apenas números do contribuinte
* @param chaveAcesso - Chave de acesso do InvoiCy
* @param chaveParceiro - Chave do parceiro para identificação pelo InvoiCy
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_ConfiguraInvoicy(char* CNPJ, char* chaveAcesso, char* chaveParceiro);
DECLDIR int STDCAL InvoiCyFramework_ConfigurarInvoicy(char* RUC, char* codIntegracion, char* claveAcceso, char* clavePartner);

/**
* Configura um parâmetro da biblioteca
* @param parametro - Nome do parâmetro
* @param valor - Valor do parâmetro
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_Configura(char* parametro, char* valor);
DECLDIR int STDCAL InvoiCyFramework_Configurar(char* parametro, char* valor);

/**
* Configura o diretório corrente que deverá ser utilizado pela biblioteca para armazenar documentos e configurações
* @param diretorio - Caminho do diretório
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_ConfiguraDiretorio(char* diretorio);
DECLDIR int STDCAL InvoiCyFramework_ConfigurarDirectorio(char* directorio);


/**
* Grava um arquivo com o nome e os dados informados no diretorio de trabalho da biblioteca
* @param nome - nome do arquivo
* @param dados - dados do arquivo
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_ArquivoSistema(char * nome, char * dados);


/**
* Alterna entre o modo de produção/homologação
* @param ativa - 1 = ambiente de producao / 2 = ambiente de homologacao
* @return retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_AmbienteEmissao(int valor);
DECLDIR int STDCAL InvoiCyFramework_AmbienteEmision(int valor);


/**
* Configura os parâmetros de emissão do SAT
* @param codigoAtivacao - código de ativação configurado no equipamento SAT
* @param softwareHouseCNPJ - CNPJ da software house do aplicativo comercial associado ao SAT
* @param softwareHouseAssinatura - assinatura do aplicativo comercial associado ao SAT
* @return Retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_ConfiguraSAT(char* codigoAtivacao, char* softwareHouseCNPJ, char* softwareHouseAssinatura);
DECLDIR int STDCAL InvoiCyFramework_ConfiguraMFE(char* codigoAtivacao, char* softwareHouseCNPJ, char* softwareHouseAssinatura);

/**
* Busca o número da versão da biblioteca
* @return número informando a versão atual da biblioteca
*/
DECLDIR int STDCAL InvoiCyFramework_Versao();
DECLDIR int STDCAL InvoiCyFramework_Version();

/**
* Recupera uma lista com todos os documentos ainda pendentes de envio
* @return string no formato XML contendo listagem de documentos pendentes
*/
DECLDIR char * STDCAL InvoiCyFramework_RelatorioPendentes();


/**
* Recupera uma lista de alertas registrados pelo sistema
* @return string no formato XML contendo listagem de alertas
*/
DECLDIR char * STDCAL InvoiCyFramework_Alertas();

/**
* Busca os dados do log da execução atual
* @return Dados do log
*/
DECLDIR char * STDCAL InvoiCyFramework_Log();

/**
* Retorna estado do servico de impressão da biblioteca
* @return 0 = nada ocorrendo / 1 = em impressão
*/
DECLDIR int STDCAL InvoiCyFramework_Servico();


/**
* Busca a data e a hora corrente da UF configurada no InvoiCy
* @param UF - código IBGE da UF desejada
* @param aplicar - indica se a data e hora recebida deve ser aplicada no computador local
* @return string no formato "yyyy-MM-ddTHH:mm:ss"
*/
DECLDIR char * STDCAL InvoiCyFramework_ObtemDataHoraUF(int UF, int aplicar);


/**
* Busca parâmetros configurados no InvoiCy
* @param parametro - identificador do parâmetro desejado
* @return string contendo o valor do parâmetro solicitado
*/
DECLDIR char* STDCAL InvoiCyFramework_ObtemParametro(int identificadorParametro);

/**
* Imprime um texto genérico, utilizando os comandos de layout do framework, ou texto puro
* @param texto - texto a ser impresso
* @return retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_ImprimeTexto(char* texto);

/**
* Envia o comando de abertura de gaveta (cash drawer) paraa a impressora
* @param pino - pino do conector a ser acionado (0 ou 1)
* @param tON - tempo ON (0-255) em ms
* @param tOFF - tempo OFF (0-255) em ms - especificar um valor > que tON
* @return retorna 1 em caso de sucesso
*/
DECLDIR int STDCAL InvoiCyFramework_AbrirGaveta(int pino, int tON, int tOFF);

/**
* Busca o número sequencial do último documento
* @param serie - indica o número da série que se quer obter o sequencial
* @return inteiro que indica o número do último sequencial
*/
DECLDIR int STDCAL InvoiCyFramework_ObtemUltimoSequencialNFCe(int serie);
DECLDIR int STDCAL InvoiCyFramework_ObtemUltimoSequencialDFe(char* cnpj, int tpAmb, char* tpDoc, int serie);

/**
* Define o número sequencial do próximo documento fiscal
* @param cnpj - indica o cnpj que se quer definir o sequencial
* @param tpAmb - indica o ambiente que se quer definir o sequencial
* @param tpDoc - indica o tipo de documento fiscal que se quer definir o sequencial
* @param serie - indica a série que se quer definir o sequencial
* @param sequencial - indica o número sequencial que se quer definir
* @return inteiro que indica o número do último sequencial
*/
DECLDIR int STDCAL InvoiCyFramework_DefineSequencialDFe(char* cnpj, int tpAmb, char* tpDoc, int serie, int sequencial);

//DECLDIR int STDCAL InvoiCyFramework_ConfiguraDados(char * dadosArquivo);
#ifndef WIN32
}
#endif

#endif /* INVOICYFRAMEWORK_H_ */
