﻿Imports System.Configuration
Imports System.Drawing.Printing
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.Threading
Imports System.Threading.Tasks
Imports System.Windows.Forms
Imports System.Xml
Imports InvoicyFramework_EmissorOffline.InvoiCyFramework_EmissorOffLine.Classes
Imports InvoicyFramework_EmissorOffline.InvoiCyFramework_EmissorOffLine.Classes.Enumeradores
Imports InvoicyFramework_EmissorOffline.InvoiCyFramework_EmissorOffLine.Interfaces


Namespace InvoiCyFramework_EmissorOffLine
    Partial Public Class Form1
        Inherits Form

        Private _emissaoDocumentos As IEmissaoDocumentos
        Private _configuracoesPSLIB As IConfiguracoes
        Private _relatorios As IRelatorios
        Private _config As Configuration
        Private t1 As Thread

        Public Sub New()
            Me._emissaoDocumentos = New EmissaoDocumentos()
            Me._configuracoesPSLIB = New Configuracoes()
            Me._relatorios = New Relatorios()
            Me._config = ConfigurationManager.OpenExeConfiguration(Application.ExecutablePath)
            InitializeComponent()
        End Sub

        Private Sub btnAlertas_Click(ByVal sender As Object, ByVal e As EventArgs)
            Dim alertas As String = Me._relatorios.ExibirAlertas()
            MessageBox.Show(alertas)
        End Sub

        Private Sub CarregarVersao()
            Dim versaoDLL As String = Me._relatorios.VersaoDll().ToString()
            lblVersao.Text = "Versão DLL: " & versaoDLL
        End Sub

        Private Sub CarregarAlertas()
            Dim strAlerta = Me._relatorios.ExibirAlertas()
        End Sub

        Private Sub CarregarLogs()
            Try
                Dim logs As String = Me._relatorios.ExibirLogs()
                txtLogs.Clear()
                txtLogs.Text = logs
                tabControl1.SelectedTab = tabLogs
            Catch
            End Try
        End Sub

        Private Sub SalvarConfiguracoes()
            Me.ConfiguraAmbiente()
            'Me.ConfigurarParametrosEmissao()
            Me.ConfigurarDiretorio()
            'Me.ConfigurarParametrosAdicionaisUF()
            Me.ConfigurarInvoicy()
            'Me.ConfigurarSAT()
            'Me.ConfigurarGerais()
            'Me.ConfigurarImpresssora()
            'Me.ConfigurarAutoPreenchimentoNF()
            'Me.ConfigurarContingencia()
            MessageBox.Show("Configurações salvas com sucesso.")
        End Sub

        Private Sub ConfigurarAutoPreenchimentoNF()
            Dim autoPreenchimento = comboAutopreenchimento.Text
            Dim autoIncremento = comboAutoIncremento.Text
            Me._configuracoesPSLIB.Configurar("AUTO_PREENCHE", comboAutopreenchimento.SelectedIndex.ToString())
            Me._configuracoesPSLIB.Configurar("AUTO_INCREMENTA", comboAutoIncremento.SelectedIndex.ToString())
            SalvarConfiguracoesAppConfig("autoPreenchimento", autoPreenchimento)
            SalvarConfiguracoesAppConfig("autoIncremento", autoIncremento)
        End Sub

        Private Sub ConfigurarSequencialInicial()
            If Not String.IsNullOrEmpty(txtDefineSequencial.Text) AndAlso Not String.IsNullOrEmpty(txtDefineSerie.Text) Then
                Dim serieInicial As Int32 = Convert.ToInt32(txtDefineSerie.Text)
                Dim sequencialInicial As Int32 = Convert.ToInt32(txtDefineSequencial.Text)
                Me._configuracoesPSLIB.DefineSerieSequencialInicial(serieInicial, sequencialInicial)
                SalvarConfiguracoesAppConfig("serieInicial", serieInicial.ToString())
                SalvarConfiguracoesAppConfig("sequencialInicial", sequencialInicial.ToString())
            End If
        End Sub

        Private Sub ConfiguraAmbiente()
            Dim ambiente = comboAmbiente.SelectedIndex
            lblAmbiente.Text = "Ambiente: " & comboAmbiente.Text.ToUpper()
            Me._configuracoesPSLIB.AlterarAmbiente(CType(ambiente, AmbienteEmissao))
            SalvarConfiguracoesAppConfig("ambiente", ambiente.ToString())
        End Sub

        Private Sub CarregarAmbiente()
            Dim ambiente = Convert.ToInt16(_config.AppSettings.Settings("ambiente").Value)
            comboAmbiente.SelectedIndex = ambiente
            Me._configuracoesPSLIB.AlterarAmbiente(CType(ambiente, AmbienteEmissao))
            lblAmbiente.Text = "Ambiente :" & comboAmbiente.Text.ToUpper()
        End Sub

        Private Sub CarregarParametrosEmissaoNFCe()
            Dim uf = _config.AppSettings.Settings("ufEmissao").Value
            Dim token = If(Not String.IsNullOrEmpty(_config.AppSettings.Settings("idTokenCSC").Value), Convert.ToInt16(_config.AppSettings.Settings("idTokenCSC").Value), 0)
            Dim codigoCSC = _config.AppSettings.Settings("codigoCSCContribuinte").Value
            Dim tipoContingencia = If(Not String.IsNullOrEmpty(_config.AppSettings.Settings("tipoContingencia").Value), Convert.ToInt16(_config.AppSettings.Settings("tipoContingencia").Value), 0)
            Dim urlQRCode = _config.AppSettings.Settings("urlQRCode").Value
            Dim urlChaveAcesso = _config.AppSettings.Settings("urlChaveAcesso").Value
            Dim codigoUF As Integer = RetornaCodigoUF(uf)
            Me._configuracoesPSLIB.ConfiguraParametrosEmsisao(codigoUF, token, codigoCSC, tipoContingencia, urlQRCode, urlChaveAcesso)
            comboUF.Text = uf
            txtTokenCSC.Text = token.ToString()
            txtCodigoCSC.Text = codigoCSC
            comboTipoContingencia.SelectedIndex = tipoContingencia
            txtURLConsultaChaveAcesso.Text = urlChaveAcesso
            txtURLQRCode.Text = urlQRCode
        End Sub

        Private Sub CarregarConfiguracoes()
            Me.CarregarVersao()
            'Me.CarregarAmbiente()
            ' Me.CarregarDiretorio()
            'Me.CarregarParametrosInvoicy()
            'Me.CarregarParametrosEmissaoNFCe()
            'Me.CarregarConfiguracoesAdicionaisUF()
            'Me.CarregarConfiguracoesSAT()
            'Me.CarregarAlertas()
            'Me.CarregarGerais()
            ' Me.CarregarImpressora()
            'Me.CarregarAutoPreenchimentoNF()
            'Me.CarregarSequencialInicial()
            'Me.CarregarContingencia()
        End Sub

        Private Sub CarregarAutoPreenchimentoNF()
            Dim autoPreenchimento = _config.AppSettings.Settings("autoPreenchimento").Value
            Dim autoIncremento = _config.AppSettings.Settings("autoIncremento").Value
            comboAutopreenchimento.Text = autoPreenchimento
            comboAutoIncremento.Text = autoIncremento
        End Sub

        Private Sub CarregarGerais()
            Dim tempoVerificacao = _config.AppSettings.Settings("tempoVerificacao").Value
            Dim contingenciaAtraso = _config.AppSettings.Settings("contingenciaAtraso").Value
            Dim timeOutConexao = _config.AppSettings.Settings("timeOutConexao").Value
            Me._configuracoesPSLIB.Configurar("TEMPO_VERIFICACAO", tempoVerificacao)
            Me._configuracoesPSLIB.Configurar("CONTINGENCIA_ATRASO", contingenciaAtraso)
            Me._configuracoesPSLIB.Configurar("WS_TIMEOUT_CONEXAO", timeOutConexao)
            txtTempoVerificacao.Text = tempoVerificacao
            txtAtrasoContingencia.Text = contingenciaAtraso
            txtTimeout.Text = timeOutConexao
        End Sub

        Private Sub ConfigurarGerais()
            Dim tempoVerificacao = txtTempoVerificacao.Text
            Dim contingenciaAtraso = txtAtrasoContingencia.Text
            Dim timeOutConexao = txtTimeout.Text
            Me._configuracoesPSLIB.Configurar("TEMPO_VERIFICACAO", tempoVerificacao)
            Me._configuracoesPSLIB.Configurar("CONTINGENCIA_ATRASO", contingenciaAtraso)
            Me._configuracoesPSLIB.Configurar("WS_TIMEOUT_CONEXAO", timeOutConexao)
            SalvarConfiguracoesAppConfig("tempoVerificacao", tempoVerificacao)
            SalvarConfiguracoesAppConfig("contingenciaAtraso", contingenciaAtraso)
            SalvarConfiguracoesAppConfig("timeOutConexao", timeOutConexao)
        End Sub

        Private Sub ConfigurarImpresssora()
            Dim nomeImpressora = comboImpressoras.Text
            Dim ipImpressora = txtIPImpressora.Text
            Dim portaImpressora = txtPortaImpressora.Text
            Dim config = If(String.IsNullOrEmpty(nomeImpressora), String.Concat(ipImpressora, "|", portaImpressora), String.Concat("IMPRESSORA:", nomeImpressora))
            Me._configuracoesPSLIB.Configurar("IMPRESSORA_CANAL", config)
            SalvarConfiguracoesAppConfig("nomeImpressora", nomeImpressora)
            SalvarConfiguracoesAppConfig("ipImpressora", ipImpressora)
            SalvarConfiguracoesAppConfig("portaImpressora", portaImpressora)
        End Sub

        Private Sub CarregarConfiguracoesAdicionaisUF()
            Dim ufAdicional = _config.AppSettings.Settings("ufAdicional").Value
            Dim codigoUFAdicional As Integer = RetornaCodigoUF(ufAdicional)
            Dim serieMin = _config.AppSettings.Settings("serieMin").Value
            Dim serieMax = _config.AppSettings.Settings("serieMax").Value
            Me._configuracoesPSLIB.ConfiguracoesAdicionaisUF(codigoUFAdicional, "serieMin", serieMin)
            Me._configuracoesPSLIB.ConfiguracoesAdicionaisUF(codigoUFAdicional, "serieMax", serieMax)
            comboAdicionaisUF.Text = ufAdicional
            txtSerieMinima.Text = serieMin
            txtSerieMaxima.Text = serieMax
        End Sub

        Private Sub CarregarParametrosInvoicy()
            Dim cnpj As String = _config.AppSettings.Settings("cnpj").Value
            Dim chaveAcesso As String = _config.AppSettings.Settings("chaveAcesso").Value
            Dim chaveParceiro As String = _config.AppSettings.Settings("chaveParceiro").Value
            Me._configuracoesPSLIB.ConfigurarInvoicy(cnpj, chaveAcesso, chaveParceiro)
            txtCnpj.Text = cnpj
            txtChaveAcesso.Text = chaveAcesso
            txtChaveParceiro.Text = chaveParceiro
        End Sub

        Private Sub CarregarImpressora()
            Dim nomeImpressora As String = _config.AppSettings.Settings("nomeImpressora").Value
            Dim ipImpressora As String = _config.AppSettings.Settings("ipImpressora").Value
            Dim portaImpressora As String = _config.AppSettings.Settings("portaImpressora").Value
            comboImpressoras.Text = nomeImpressora
            txtIPImpressora.Text = ipImpressora
            txtPortaImpressora.Text = portaImpressora

            If Not String.IsNullOrEmpty(ipImpressora) AndAlso Not String.IsNullOrEmpty(portaImpressora) Then
                Dim config = If(String.IsNullOrEmpty(nomeImpressora), String.Concat(ipImpressora, "|", portaImpressora), String.Concat("IMPRESSORA:", nomeImpressora))
                Me._configuracoesPSLIB.Configurar("IMPRESSORA_CANAL", config)
            End If
        End Sub

        Private Sub CarregarContingencia()
            Dim emisisaoEmContingencia As Int16 = Convert.ToInt16(_config.AppSettings.Settings(CStr("emitirContingencia")).Value)
            checkContingencia.Checked = emisisaoEmContingencia = 1
            'Me._configuracoesPSLIB.Configurar("EMITIR_EM_CONTINGENCIA", emisisaoEmContingencia.ToString())
        End Sub

        Private Sub ConfigurarContingencia()
            Dim contingencia As Integer = Convert.ToInt32(checkContingencia.Checked)
            SalvarConfiguracoesAppConfig("emitirContingencia", contingencia.ToString())
            'Me._configuracoesPSLIB.Configurar("EMITIR_EM_CONTINGENCIA", contingencia.ToString())
        End Sub


        Private Sub ListarImpressoras()
            Dim pkInstalledPrinters As String

            For i As Integer = 0 To PrinterSettings.InstalledPrinters.Count - 1
                pkInstalledPrinters = PrinterSettings.InstalledPrinters(i)
                comboImpressoras.Items.Add(pkInstalledPrinters)
            Next
        End Sub

        Private Sub CarregarDiretorio()
            Dim diretorioArmazenamento = _config.AppSettings.Settings("diretorioEmissao").Value
            'Me._configuracoesPSLIB.ConfigurarDiretorio(diretorioArmazenamento)
            txtDiretorioArmazenamento.Text = diretorioArmazenamento
        End Sub

        Private Sub ConfigurarDiretorio()
            If Not String.IsNullOrEmpty(txtDiretorioArmazenamento.Text) Then
                lblErroDiretorio.Visible = False
                Me.SalvarConfiguracoesAppConfig("diretorioEmissao", txtDiretorioArmazenamento.Text)
                Me._configuracoesPSLIB.ConfigurarDiretorio(txtDiretorioArmazenamento.Text)
            Else
                lblErroDiretorio.Visible = True
                txtDiretorioArmazenamento.Focus()
                Throw New Exception("Diretório de armazenamento não foi informado.")
            End If
        End Sub

        Public Sub CarregarSequencialInicial()
            Dim serieInicial As Int32 = Convert.ToInt16(_config.AppSettings.Settings("serieInicial").Value)
            Dim sequencialInicial As Int32 = Convert.ToInt32(_config.AppSettings.Settings("sequencialInicial").Value)
            txtDefineSerie.Text = serieInicial.ToString()
            txtDefineSequencial.Text = sequencialInicial.ToString()
            Me._configuracoesPSLIB.DefineSerieSequencialInicial(serieInicial, sequencialInicial)
        End Sub

        Private Sub btnConfiguraDiretorio_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnConfiguraDiretorio.Click
            Dim dialogResult = folderBrowserDialog1.ShowDialog()

            If dialogResult = dialogResult.OK Then
                txtDiretorioArmazenamento.Text = folderBrowserDialog1.SelectedPath
            End If
        End Sub

        Private Sub SalvarConfiguracoesAppConfig(ByVal chave As String, ByVal valor As String)
            Dim config As Configuration = ConfigurationManager.OpenExeConfiguration(Application.ExecutablePath)
            config.AppSettings.Settings(chave).Value = valor
            config.Save(ConfigurationSaveMode.Modified)
            'ConfigurationManager.RefreshSection(config.AppSettings.SectionInformation.Name)
        End Sub

        Private Sub ConfigurarInvoicy()
            Dim cnpj = txtCnpj.Text
            Dim chaveParceiro = txtChaveParceiro.Text
            Dim chaveAcesso = txtChaveAcesso.Text

            If Not String.IsNullOrEmpty(cnpj) AndAlso Not String.IsNullOrEmpty(chaveAcesso) AndAlso Not String.IsNullOrEmpty(chaveParceiro) Then
                SalvarConfiguracoesAppConfig("cnpj", cnpj)
                SalvarConfiguracoesAppConfig("chaveAcesso", chaveAcesso)
                SalvarConfiguracoesAppConfig("chaveParceiro", chaveParceiro)
                Me._configuracoesPSLIB.ConfigurarInvoicy(cnpj, chaveAcesso, chaveParceiro)
            End If
        End Sub

        Private Sub ConfigurarSAT()
            Dim cnpjSAT = txtCnpj.Text
            Dim codigoAtivacao = txtCodigoAtivacaoSAT.Text
            Dim assinaturaSAT = txtAssinaturaSAT.Text

            If Not String.IsNullOrEmpty(cnpjSAT) AndAlso Not String.IsNullOrEmpty(codigoAtivacao) AndAlso Not String.IsNullOrEmpty(assinaturaSAT) Then
                SalvarConfiguracoesAppConfig("cnpjSAT", cnpjSAT)
                SalvarConfiguracoesAppConfig("codigoSAT", codigoAtivacao)
                SalvarConfiguracoesAppConfig("assinaturaSAT", assinaturaSAT)
                Me._configuracoesPSLIB.ConfiguraSAT(codigoAtivacao, cnpjSAT, assinaturaSAT)
            End If
        End Sub

        Private Sub CarregarConfiguracoesSAT()
            Dim cnpjSAT = _config.AppSettings.Settings("cnpjSAT").Value
            Dim codigoAtivacao = _config.AppSettings.Settings("codigoSAT").Value
            Dim assinaturaSAT = _config.AppSettings.Settings("assinaturaSAT").Value
            Me._configuracoesPSLIB.ConfiguraSAT(codigoAtivacao, cnpjSAT, assinaturaSAT)
            txtCnpjSAT.Text = cnpjSAT
            txtCodigoAtivacaoSAT.Text = codigoAtivacao
            txtAssinaturaSAT.Text = assinaturaSAT
        End Sub

        Private Sub ConfigurarParametrosEmissao()
            Dim uf = comboUF.Text
            Dim token = Integer.Parse(txtTokenCSC.Text)
            Dim csc = txtCodigoCSC.Text
            Dim tipoContingencia = comboTipoContingencia.SelectedIndex
            Dim urlQRCode = txtURLQRCode.Text
            Dim urlChaveAcesso = txtURLConsultaChaveAcesso.Text
            SalvarConfiguracoesAppConfig("ufEmissao", uf)
            SalvarConfiguracoesAppConfig("idTokenCSC", token.ToString())
            SalvarConfiguracoesAppConfig("codigoCSCContribuinte", csc)
            SalvarConfiguracoesAppConfig("tipoContingencia", tipoContingencia.ToString())
            SalvarConfiguracoesAppConfig("urlQRCode", urlQRCode)
            SalvarConfiguracoesAppConfig("urlChaveAcesso", urlChaveAcesso)
            Dim codigoUF As Integer = RetornaCodigoUF(uf)
            Me._configuracoesPSLIB.ConfiguraParametrosEmsisao(codigoUF, token, csc, tipoContingencia, urlQRCode, urlChaveAcesso)
        End Sub

        Private Sub btnEmitir_Click(ByVal sender As Object, ByVal e As EventArgs) Handles tbsEmitir.Click, emitirToolStripMenuItem.Click

            'txtRetornoEmissao.Clear()
            't1 = New Thread(AddressOf Me.Executa)
            't1.Start()

            Me.Executa()

        End Sub

        Private Sub Executa()


            Dim xmlEntrada As Byte() = Encoding.ASCII.GetBytes(txtXmlEntradaEmissao.Text.Trim())
            Dim xmlParametros As Byte() = Encoding.ASCII.GetBytes(txtXMLParametrosEmissao.Text.Trim())
            Me.CarregarContingencia()

            '_configuracoesPSLIB.ConfigurarDiretorio("C:\Users\cs22283\Documents\InvoiCyFWKuiper")
            '_configuracoesPSLIB.AlterarAmbiente(AmbienteEmissao.Homologacao)
            '_configuracoesPSLIB.ConfigurarInvoicy("06354976000149", "eKdz2fcZg9ZMt3DrfF/KSIVoH59Ca6nN", "YPxRwGxIbpWZtwhuC0m+Wg==")
            '_configuracoesPSLIB.Configurar("LOG_DIRETORIO", "Logs")
            '_configuracoesPSLIB.Configurar("LOG_REGISTRO", "1")
            '_configuracoesPSLIB.Configurar("LOG_NIVEL", "2")
            '_configuracoesPSLIB.Configurar("AUTO_PREENCHE", "1")
            '_configuracoesPSLIB.Configurar("AUTO_INCREMENTA", "1")
            '_configuracoesPSLIB.Configurar("TIPO_CONTINGENCIA", "1")
            '_configuracoesPSLIB.Configurar("LAYOUT_IMPRESSAO_DANFENFCE", "0")
            '_configuracoesPSLIB.Configurar("LAYOUT_IMPRESSAO_POS_QRCODE", "1")
            '_configuracoesPSLIB.Configurar("IMPRESSORA_CANAL", "PORTA:AUTO")
            '_configuracoesPSLIB.Configurar("SERIE_INICIAL_NFCE", "1")
            '_configuracoesPSLIB.Configurar("SEQUENCIAL_INICIAL_NFCE", "6014")

            For index As Integer = 1 To 1
                Try

                    Dim tempo As Integer = 500

                    Dim xmlRetorno As String = _emissaoDocumentos.EmitirDocumento(xmlEntrada, xmlParametros)

                    txtRetornoEmissao.Text = xmlRetorno
                    'GC.Collect()
                    Threading.Thread.Sleep(tempo)
                    Dim strDadosEntrada As String = ""

                    strDadosEntrada += "</reset></fontmd></fontnormal>"
                    strDadosEntrada += "        IRMAOS PARREIRA LTDA-EPP        \n"
                    strDadosEntrada += "            FARMACIA-TREINA             \n"
                    strDadosEntrada += "         AV. SAO GABRIEL, 2189          \n"
                    strDadosEntrada += "               COLOMBO/PR               \n"
                    strDadosEntrada += "   CNPJ:02186163000136 IE:9015099566    \n"
                    strDadosEntrada += "----------------------------------------\n"
                    strDadosEntrada += "      ** NAO E DOCUMENTO FISCAL **      \n"
                    strDadosEntrada += "\n"
                    strDadosEntrada += "----------------------------------------\n"
                    strDadosEntrada += "Codigo         Descricao                \n"
                    strDadosEntrada += "V.Unitario      Qtde               Valor\n"
                    strDadosEntrada += "----------------------------------------\n"
                    strDadosEntrada += "7898315341764  LIXA UNHAS PRETA AVUL PQ4\n"
                    strDadosEntrada += "         0,10 x 1                   0,10\n"
                    strDadosEntrada += "----------------------------------------\n"
                    strDadosEntrada += "\n"
                    strDadosEntrada += "Compra   $...............           0,10\n"
                    strDadosEntrada += "A Pagar  $...............           0,10\n"
                    strDadosEntrada += "\n"
                    strDadosEntrada += "            *** A Prazo ***             \n"
                    strDadosEntrada += "            CHAVE DE ACESSO             \n"
                    strDadosEntrada += "     4123 0402 1861 6300 0136 6500      \n"
                    strDadosEntrada += "        6000 0002 1110 0045 3650        \n"
                    strDadosEntrada += "Empresa: MARIA DA GRACA SOUZA SABOIA\n"
                    strDadosEntrada += "Fone...: 36217709\n"
                    strDadosEntrada += "Celular: 987719351\n"
                    strDadosEntrada += "Nome...: 10 - MARIA DA GRACA SOUZA\n"
                    strDadosEntrada += "Debitos: 1428,85\n"
                    strDadosEntrada += "Cx/Vd: 25-SUPORTE HIPER    0070111\n"
                    strDadosEntrada += "\n"
                    strDadosEntrada += "                     20/04/2023 17:08:04\n"
                    strDadosEntrada += "\n"
                    strDadosEntrada += "\n"
                    strDadosEntrada += "\n</cutter cut=""full""></drawer pin=""0"" t1=""10"" t2=""5"">"

                    Dim dadosEntrada As Byte() = Encoding.ASCII.GetBytes(strDadosEntrada.Trim())

                    Dim intRetorno As Integer = _emissaoDocumentos.ImprimeTexto(dadosEntrada)
                    Threading.Thread.Sleep(tempo)


                Catch ex As Exception
                    txtRetornoEmissao.Text = ex.Message
                End Try

                Thread.Sleep(100)
            Next

        End Sub



        Private Sub btnLog_Click(ByVal sender As Object, ByVal e As EventArgs)
            Dim logs As String = Me._relatorios.ExibirLogs()
        End Sub

        Private Sub btnEnviarPendentes_Click(ByVal sender As Object, ByVal e As EventArgs)
            Dim retorno = Me._emissaoDocumentos.EnviarDocumentosPendentes()
            txtRetornoEmissao.Clear()
            txtRetornoEmissao.Text = "Total de documentos enviados: " & retorno.ToString()
        End Sub

        Private Sub btnEmitirContingencia_Click(ByVal sender As Object, ByVal e As EventArgs) Handles emitirEmContingênciaToolStripMenuItem.Click

            Dim xmlEntrada As Byte() = Encoding.ASCII.GetBytes(txtXmlEntradaEmissao.Text.Trim())
            Dim retornoContingencia = Me._emissaoDocumentos.EmitirContingencia(xmlEntrada)
            txtRetornoEmissao.Clear()
            txtRetornoEmissao.Text = retornoContingencia
        End Sub

        Private Sub ConfigurarParametrosAdicionaisUF()
            Dim codigoUF As Integer = RetornaCodigoUF(comboAdicionaisUF.Text)
            SalvarConfiguracoesAppConfig("ufAdicional", comboAdicionaisUF.Text)
            SalvarConfiguracoesAppConfig("serieMin", txtSerieMinima.Text)
            SalvarConfiguracoesAppConfig("serieMax", txtSerieMaxima.Text)
            Dim retConfigSerieMinima = Me._configuracoesPSLIB.ConfiguracoesAdicionaisUF(codigoUF, "serieMin", txtSerieMinima.Text)
            Dim retConfigSerieMaxima = Me._configuracoesPSLIB.ConfiguracoesAdicionaisUF(codigoUF, "serieMax", txtSerieMaxima.Text)
        End Sub

        Private Function RetornaCodigoUF(ByVal uf As String) As Integer
            Dim codigoUF As Integer = 0

            Select Case uf
                Case "AC"
                    codigoUF = 12
                    Exit Select
                Case "AL"
                    codigoUF = 27
                    Exit Select
                Case "AM"
                    codigoUF = 13
                    Exit Select
                Case "AP"
                    codigoUF = 16
                    Exit Select
                Case "BA"
                    codigoUF = 29
                    Exit Select
                Case "CE"
                    codigoUF = 23
                    Exit Select
                Case "DF"
                    codigoUF = 53
                    Exit Select
                Case "ES"
                    codigoUF = 32
                    Exit Select
                Case "GO"
                    codigoUF = 52
                    Exit Select
                Case "MA"
                    codigoUF = 21
                    Exit Select
                Case "MG"
                    codigoUF = 31
                    Exit Select
                Case "MS"
                    codigoUF = 50
                    Exit Select
                Case "MT"
                    codigoUF = 51
                    Exit Select
                Case "PA"
                    codigoUF = 15
                    Exit Select
                Case "PB"
                    codigoUF = 25
                    Exit Select
                Case "PE"
                    codigoUF = 26
                    Exit Select
                Case "PI"
                    codigoUF = 22
                    Exit Select
                Case "PR"
                    codigoUF = 41
                    Exit Select
                Case "RJ"
                    codigoUF = 33
                    Exit Select
                Case "RN"
                    codigoUF = 24
                    Exit Select
                Case "RO"
                    codigoUF = 11
                    Exit Select
                Case "RR"
                    codigoUF = 14
                    Exit Select
                Case "RS"
                    codigoUF = 43
                    Exit Select
                Case "SC"
                    codigoUF = 42
                    Exit Select
                Case "SE"
                    codigoUF = 28
                    Exit Select
                Case "SP"
                    codigoUF = 35
                    Exit Select
                Case "TO"
                    codigoUF = 17
                    Exit Select
                Case Else
            End Select

            Return codigoUF
        End Function

        Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
            Me.CarregarConfiguracoes()
            ListarImpressoras()
            comboAplicaDataHora.SelectedIndex = 1
        End Sub

        Private Sub btnSalvarConfiguracoes_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSalvarConfiguracoes.Click

            Try
                Me.SalvarConfiguracoes()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)


            End Try


        End Sub

        Private Sub toolStripButton1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles toolStripButton1.Click
            CarregarConfiguracoes()
            MessageBox.Show("Configurações carregadas com sucesso.")
        End Sub

        Private Sub pendentesToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles pendentesToolStripMenuItem.Click
            Dim docsPendentes As String = Me._relatorios.DocumentosPendentes()
            Dim doc As XmlDocument = New XmlDocument()
            doc.LoadXml(docsPendentes)
            Dim elemList As XmlNodeList = doc.GetElementsByTagName("Quantidade")
            Dim total = elemList(0).InnerText
            MessageBox.Show("Documentos pendentes:" & total)
        End Sub

        Private Sub btnCancelarNF_Click(ByVal sender As Object, ByVal e As EventArgs) Handles tsbCanclearNF.Click
            Dim xmlCancelamento As Byte() = Encoding.ASCII.GetBytes(txtXmlEntradaEmissao.Text.Trim())
            Dim xmlParametro As Byte() = Encoding.ASCII.GetBytes(txtXMLParametrosEmissao.Text.Trim())
            Dim doc As XmlDocument = New XmlDocument()
            doc.LoadXml(txtXmlEntradaEmissao.Text.Trim())
            Dim xmlNode As XmlNode = doc.GetElementsByTagName("EveDesc")(0)

            If xmlNode IsNot Nothing Then

                If Not xmlNode.InnerText.Contains("Cancelament") Then
                    MessageBox.Show("Esse não é um xml de cancelamento.")
                Else
                    Dim retornoCancelamento = InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_EmiteDocumento(xmlCancelamento, xmlParametro)

                    If retornoCancelamento IsNot Nothing Then
                        txtRetornoEmissao.Text = Marshal.PtrToStringAnsi(retornoCancelamento)
                    End If
                End If
            Else
                MessageBox.Show("Sem dados para cancelar.")
            End If
        End Sub

        Private Sub logsToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles logsToolStripMenuItem.Click
            CarregarLogs()
        End Sub

        Private Sub btnDefinirSequencial_Click(sender As Object, e As EventArgs) Handles btnDefinirSequencial.Click

            If (Not String.IsNullOrEmpty(txtDefineSerie.Text) And Not String.IsNullOrEmpty(txtDefineSequencial.Text)) Then
                Dim serieInicial As Int32 = Convert.ToInt32(txtDefineSerie.Text)
                Dim sequencialInicial As Int32 = Convert.ToInt32(txtDefineSequencial.Text)
                Me._configuracoesPSLIB.DefineSerieSequencialInicial(serieInicial, sequencialInicial)
            End If
        End Sub

        Private Sub btnDataHoraUF_Click(sender As Object, e As EventArgs) Handles btnDataHoraUF.Click
            Dim codigoUF As Integer = RetornaCodigoUF(comboAdicionaisUF.Text)
            Dim aplicarDataHora As Integer = comboAplicaDataHora.SelectedIndex
            txtDataHoraUF.Text = Me._configuracoesPSLIB.ObtemDataHoraUF(codigoUF, aplicarDataHora)
        End Sub

        Private Sub stpClearXml_Click(sender As Object, e As EventArgs) Handles stpClearXml.Click
            Me.txtXmlEntradaEmissao.Clear()
        End Sub

        Private Sub txtXmlEntradaEmissao_TextChanged(sender As Object, e As EventArgs) Handles txtXmlEntradaEmissao.TextChanged
            tbsEmitir.Enabled = txtXmlEntradaEmissao.TextLength > 50
            emitirToolStripMenuItem.Enabled = tbsEmitir.Enabled
            tsbCanclearNF.Enabled = tbsEmitir.Enabled
        End Sub

        Private Sub tsbCarregarLogs_Click(sender As Object, e As EventArgs) Handles tsbCarregarLogs.Click
            CarregarLogs()

        End Sub

        Private Sub tsbLimparLogs_Click(sender As Object, e As EventArgs) Handles tsbLimparLogs.Click
            txtLogs.Clear()

        End Sub
    End Class
End Namespace
