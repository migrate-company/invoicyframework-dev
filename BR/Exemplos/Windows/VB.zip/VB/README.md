
## POC Emissão Offline

Esta POC tem por objectivo testar as funcionalidades da biblioteca, inicialmente chamada pslib.dll mas modificada para InvoiCyFramework.dll.
As configurações estão salvas no arquivo App.config. (nos binários é InvoiCyFramework.exe.config).

---

## Projeto

Monolito do tipo Windows Forms.

---

## .NET Framework

.NET Framework versão 4.5
