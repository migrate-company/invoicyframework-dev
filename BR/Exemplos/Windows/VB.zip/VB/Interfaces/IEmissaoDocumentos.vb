Namespace InvoiCyFramework_EmissorOffLine.Interfaces
    Public Interface IEmissaoDocumentos
        Function ExibirAlertas() As String

        Function EmitirDocumento(xmlEntrada As Byte(), xmlParametro As Byte()) As String
        Function EmitirContingencia(xmlEntrada As Byte()) As String
        Function EnviarDocumentosPendentes() As Integer
        Function ImprimeTexto(dadosEntrada As Byte()) As Integer
    End Interface
End Namespace
