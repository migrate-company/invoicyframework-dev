Namespace InvoiCyFramework_EmissorOffLine.Interfaces
	Public Interface IRelatorios
		Function ExibirAlertas() As String
		Function VersaoDll() As Integer
		Function ExibirLogs() As String
		Function DocumentosPendentes() As String
	End Interface
End Namespace
