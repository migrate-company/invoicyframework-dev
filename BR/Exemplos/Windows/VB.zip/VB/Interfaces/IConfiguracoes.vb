﻿Imports InvoicyFramework_EmissorOffline.InvoiCyFramework_EmissorOffLine.Classes.Enumeradores
Namespace InvoiCyFramework_EmissorOffLine.Interfaces

    Public Interface IConfiguracoes
        Function AlterarAmbiente(ambiente As AmbienteEmissao) As Boolean
        Function ConfigurarDiretorio(diretorio As String) As Boolean

        Function ConfigurarInvoicy(cnpj As String, chaveAcesso As String, chaveParceiro As String) As Boolean

        Function ConfiguraSAT(codigoAtivacao As String, softwareHouseCNPJ As String, softwareHouseAssinatura As String) As Boolean
        Function ConfiguraParametrosEmsisao(uf As Int32, idToken As Int32, csc As String, contingencia As Int32, urlQRCode As String,
                                             urlChaveAcesso As String) As Boolean
        Function ConfiguraEnderecoInvoicy(url As String) As Boolean
        Function ConfiguracoesAdicionaisUF(UF As Int32, parametro As String, valor As String) As Int32

        Function Configurar(parametro As String, valor As String) As Int32


        Function DefineSerieSequencialInicial(serie As Int32, sequencial As Int32) As Int32

        Function ObtemDataHoraUF(UF As Integer, aplicar As Integer) As String


    End Interface
End Namespace
