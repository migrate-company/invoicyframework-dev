﻿Namespace InvoiCyFramework_EmissorOffLine
    Partial Class Form1
        Private components As System.ComponentModel.IContainer = Nothing

        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing AndAlso (components IsNot Nothing) Then
                components.Dispose()
            End If

            MyBase.Dispose(disposing)
        End Sub

        Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
            Me.toolStrip1 = New System.Windows.Forms.ToolStrip()
            Me.btnSalvarConfiguracoes = New System.Windows.Forms.ToolStripButton()
            Me.toolStripButton1 = New System.Windows.Forms.ToolStripButton()
            Me.toolStripDropDownButton1 = New System.Windows.Forms.ToolStripDropDownButton()
            Me.pendentesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
            Me.logsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
            Me.btnEmitirMenu = New System.Windows.Forms.ToolStripDropDownButton()
            Me.emitirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
            Me.emitirEmContingênciaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
            Me.EmitirDocumentosPendentesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
            Me.tsbCanclearNF = New System.Windows.Forms.ToolStripButton()
            Me.tabControl1 = New System.Windows.Forms.TabControl()
            Me.tabConfigs = New System.Windows.Forms.TabPage()
            Me.groupBox9 = New System.Windows.Forms.GroupBox()
            Me.txtDataHoraUF = New System.Windows.Forms.TextBox()
            Me.Label31 = New System.Windows.Forms.Label()
            Me.comboAplicaDataHora = New System.Windows.Forms.ComboBox()
            Me.btnDataHoraUF = New System.Windows.Forms.Button()
            Me.label17 = New System.Windows.Forms.Label()
            Me.txtSerieMaxima = New System.Windows.Forms.TextBox()
            Me.label16 = New System.Windows.Forms.Label()
            Me.txtSerieMinima = New System.Windows.Forms.TextBox()
            Me.label15 = New System.Windows.Forms.Label()
            Me.comboAdicionaisUF = New System.Windows.Forms.ComboBox()
            Me.groupBox5 = New System.Windows.Forms.GroupBox()
            Me.checkContingencia = New System.Windows.Forms.CheckBox()
            Me.GroupBox12 = New System.Windows.Forms.GroupBox()
            Me.btnDefinirSequencial = New System.Windows.Forms.Button()
            Me.Label30 = New System.Windows.Forms.Label()
            Me.Label29 = New System.Windows.Forms.Label()
            Me.txtDefineSequencial = New System.Windows.Forms.TextBox()
            Me.txtDefineSerie = New System.Windows.Forms.TextBox()
            Me.label28 = New System.Windows.Forms.Label()
            Me.comboAutoIncremento = New System.Windows.Forms.ComboBox()
            Me.label27 = New System.Windows.Forms.Label()
            Me.comboAutopreenchimento = New System.Windows.Forms.ComboBox()
            Me.txtURLConsultaChaveAcesso = New System.Windows.Forms.TextBox()
            Me.label14 = New System.Windows.Forms.Label()
            Me.txtURLQRCode = New System.Windows.Forms.TextBox()
            Me.label13 = New System.Windows.Forms.Label()
            Me.label12 = New System.Windows.Forms.Label()
            Me.comboTipoContingencia = New System.Windows.Forms.ComboBox()
            Me.txtCodigoCSC = New System.Windows.Forms.TextBox()
            Me.label11 = New System.Windows.Forms.Label()
            Me.txtTokenCSC = New System.Windows.Forms.TextBox()
            Me.label10 = New System.Windows.Forms.Label()
            Me.label9 = New System.Windows.Forms.Label()
            Me.comboUF = New System.Windows.Forms.ComboBox()
            Me.groupBox11 = New System.Windows.Forms.GroupBox()
            Me.comboImpressoras = New System.Windows.Forms.ComboBox()
            Me.txtPortaImpressora = New System.Windows.Forms.TextBox()
            Me.txtIPImpressora = New System.Windows.Forms.TextBox()
            Me.label26 = New System.Windows.Forms.Label()
            Me.label25 = New System.Windows.Forms.Label()
            Me.label24 = New System.Windows.Forms.Label()
            Me.groupBox10 = New System.Windows.Forms.GroupBox()
            Me.label22 = New System.Windows.Forms.Label()
            Me.label23 = New System.Windows.Forms.Label()
            Me.txtTimeout = New System.Windows.Forms.TextBox()
            Me.label20 = New System.Windows.Forms.Label()
            Me.label21 = New System.Windows.Forms.Label()
            Me.txtAtrasoContingencia = New System.Windows.Forms.TextBox()
            Me.label19 = New System.Windows.Forms.Label()
            Me.label18 = New System.Windows.Forms.Label()
            Me.txtTempoVerificacao = New System.Windows.Forms.TextBox()
            Me.groupBox4 = New System.Windows.Forms.GroupBox()
            Me.txtCnpjSAT = New System.Windows.Forms.TextBox()
            Me.label8 = New System.Windows.Forms.Label()
            Me.txtAssinaturaSAT = New System.Windows.Forms.TextBox()
            Me.label7 = New System.Windows.Forms.Label()
            Me.txtCodigoAtivacaoSAT = New System.Windows.Forms.TextBox()
            Me.label6 = New System.Windows.Forms.Label()
            Me.groupBox3 = New System.Windows.Forms.GroupBox()
            Me.txtChaveParceiro = New System.Windows.Forms.TextBox()
            Me.label5 = New System.Windows.Forms.Label()
            Me.txtChaveAcesso = New System.Windows.Forms.TextBox()
            Me.txtCnpj = New System.Windows.Forms.TextBox()
            Me.label4 = New System.Windows.Forms.Label()
            Me.label3 = New System.Windows.Forms.Label()
            Me.groupBox2 = New System.Windows.Forms.GroupBox()
            Me.lblErroDiretorio = New System.Windows.Forms.Label()
            Me.btnConfiguraDiretorio = New System.Windows.Forms.Button()
            Me.txtDiretorioArmazenamento = New System.Windows.Forms.TextBox()
            Me.label2 = New System.Windows.Forms.Label()
            Me.groupBox1 = New System.Windows.Forms.GroupBox()
            Me.label1 = New System.Windows.Forms.Label()
            Me.comboAmbiente = New System.Windows.Forms.ComboBox()
            Me.tabEmissao = New System.Windows.Forms.TabPage()
            Me.groupBox8 = New System.Windows.Forms.GroupBox()
            Me.txtRetornoEmissao = New System.Windows.Forms.TextBox()
            Me.groupBox7 = New System.Windows.Forms.GroupBox()
            Me.txtXMLParametrosEmissao = New System.Windows.Forms.TextBox()
            Me.groupBox6 = New System.Windows.Forms.GroupBox()
            Me.toolStrip2 = New System.Windows.Forms.ToolStrip()
            Me.stpClearXml = New System.Windows.Forms.ToolStripButton()
            Me.tbsEmitir = New System.Windows.Forms.ToolStripButton()
            Me.txtXmlEntradaEmissao = New System.Windows.Forms.TextBox()
            Me.tabLogs = New System.Windows.Forms.TabPage()
            Me.txtLogs = New System.Windows.Forms.TextBox()
            Me.folderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
            Me.panel1 = New System.Windows.Forms.Panel()
            Me.lblAmbiente = New System.Windows.Forms.Label()
            Me.lblVersao = New System.Windows.Forms.Label()
            Me.ToolStrip3 = New System.Windows.Forms.ToolStrip()
            Me.tsbLimparLogs = New System.Windows.Forms.ToolStripButton()
            Me.tsbCarregarLogs = New System.Windows.Forms.ToolStripButton()
            Me.toolStrip1.SuspendLayout()
            Me.tabControl1.SuspendLayout()
            Me.tabConfigs.SuspendLayout()
            Me.groupBox9.SuspendLayout()
            Me.groupBox5.SuspendLayout()
            Me.GroupBox12.SuspendLayout()
            Me.groupBox11.SuspendLayout()
            Me.groupBox10.SuspendLayout()
            Me.groupBox4.SuspendLayout()
            Me.groupBox3.SuspendLayout()
            Me.groupBox2.SuspendLayout()
            Me.groupBox1.SuspendLayout()
            Me.tabEmissao.SuspendLayout()
            Me.groupBox8.SuspendLayout()
            Me.groupBox7.SuspendLayout()
            Me.groupBox6.SuspendLayout()
            Me.toolStrip2.SuspendLayout()
            Me.tabLogs.SuspendLayout()
            Me.panel1.SuspendLayout()
            Me.ToolStrip3.SuspendLayout()
            Me.SuspendLayout()
            '
            'toolStrip1
            '
            Me.toolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnSalvarConfiguracoes, Me.toolStripButton1, Me.toolStripDropDownButton1, Me.btnEmitirMenu, Me.tsbCanclearNF})
            Me.toolStrip1.Location = New System.Drawing.Point(0, 0)
            Me.toolStrip1.Name = "toolStrip1"
            Me.toolStrip1.Size = New System.Drawing.Size(1483, 26)
            Me.toolStrip1.TabIndex = 2
            Me.toolStrip1.Text = "toolStrip1"
            '
            'btnSalvarConfiguracoes
            '
            Me.btnSalvarConfiguracoes.Image = CType(resources.GetObject("btnSalvarConfiguracoes.Image"), System.Drawing.Image)
            Me.btnSalvarConfiguracoes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
            Me.btnSalvarConfiguracoes.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.btnSalvarConfiguracoes.Name = "btnSalvarConfiguracoes"
            Me.btnSalvarConfiguracoes.Size = New System.Drawing.Size(65, 23)
            Me.btnSalvarConfiguracoes.Text = "Salvar"
            Me.btnSalvarConfiguracoes.ToolTipText = "Salvar configurações"
            '
            'toolStripButton1
            '
            Me.toolStripButton1.Image = CType(resources.GetObject("toolStripButton1.Image"), System.Drawing.Image)
            Me.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.toolStripButton1.Name = "toolStripButton1"
            Me.toolStripButton1.Size = New System.Drawing.Size(82, 23)
            Me.toolStripButton1.Text = "Atualizar"
            '
            'toolStripDropDownButton1
            '
            Me.toolStripDropDownButton1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.pendentesToolStripMenuItem, Me.logsToolStripMenuItem})
            Me.toolStripDropDownButton1.Image = CType(resources.GetObject("toolStripDropDownButton1.Image"), System.Drawing.Image)
            Me.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.toolStripDropDownButton1.Name = "toolStripDropDownButton1"
            Me.toolStripDropDownButton1.Size = New System.Drawing.Size(98, 23)
            Me.toolStripDropDownButton1.Text = "Relatórios"
            '
            'pendentesToolStripMenuItem
            '
            Me.pendentesToolStripMenuItem.Name = "pendentesToolStripMenuItem"
            Me.pendentesToolStripMenuItem.Size = New System.Drawing.Size(223, 24)
            Me.pendentesToolStripMenuItem.Text = "Documentos Pendentes"
            '
            'logsToolStripMenuItem
            '
            Me.logsToolStripMenuItem.Name = "logsToolStripMenuItem"
            Me.logsToolStripMenuItem.Size = New System.Drawing.Size(223, 24)
            Me.logsToolStripMenuItem.Text = "Logs"
            '
            'btnEmitirMenu
            '
            Me.btnEmitirMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.emitirToolStripMenuItem, Me.emitirEmContingênciaToolStripMenuItem, Me.EmitirDocumentosPendentesToolStripMenuItem})
            Me.btnEmitirMenu.Image = CType(resources.GetObject("btnEmitirMenu.Image"), System.Drawing.Image)
            Me.btnEmitirMenu.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.btnEmitirMenu.Name = "btnEmitirMenu"
            Me.btnEmitirMenu.Size = New System.Drawing.Size(87, 23)
            Me.btnEmitirMenu.Text = "Emissão"
            '
            'emitirToolStripMenuItem
            '
            Me.emitirToolStripMenuItem.Name = "emitirToolStripMenuItem"
            Me.emitirToolStripMenuItem.Size = New System.Drawing.Size(262, 24)
            Me.emitirToolStripMenuItem.Text = "Emitir"
            '
            'emitirEmContingênciaToolStripMenuItem
            '
            Me.emitirEmContingênciaToolStripMenuItem.Name = "emitirEmContingênciaToolStripMenuItem"
            Me.emitirEmContingênciaToolStripMenuItem.Size = New System.Drawing.Size(262, 24)
            Me.emitirEmContingênciaToolStripMenuItem.Text = "Emitir em contingência"
            '
            'EmitirDocumentosPendentesToolStripMenuItem
            '
            Me.EmitirDocumentosPendentesToolStripMenuItem.Name = "EmitirDocumentosPendentesToolStripMenuItem"
            Me.EmitirDocumentosPendentesToolStripMenuItem.Size = New System.Drawing.Size(262, 24)
            Me.EmitirDocumentosPendentesToolStripMenuItem.Text = "Emitir Documentos Pendentes"
            '
            'tsbCanclearNF
            '
            Me.tsbCanclearNF.Enabled = False
            Me.tsbCanclearNF.Image = CType(resources.GetObject("tsbCanclearNF.Image"), System.Drawing.Image)
            Me.tsbCanclearNF.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.tsbCanclearNF.Name = "tsbCanclearNF"
            Me.tsbCanclearNF.Size = New System.Drawing.Size(102, 23)
            Me.tsbCanclearNF.Text = "Cancelar NF"
            '
            'tabControl1
            '
            Me.tabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.tabControl1.Controls.Add(Me.tabConfigs)
            Me.tabControl1.Controls.Add(Me.tabEmissao)
            Me.tabControl1.Controls.Add(Me.tabLogs)
            Me.tabControl1.Location = New System.Drawing.Point(12, 71)
            Me.tabControl1.Multiline = True
            Me.tabControl1.Name = "tabControl1"
            Me.tabControl1.SelectedIndex = 0
            Me.tabControl1.Size = New System.Drawing.Size(1459, 923)
            Me.tabControl1.TabIndex = 4
            '
            'tabConfigs
            '
            Me.tabConfigs.AutoScroll = True
            Me.tabConfigs.Controls.Add(Me.groupBox9)
            Me.tabConfigs.Controls.Add(Me.groupBox5)
            Me.tabConfigs.Controls.Add(Me.groupBox11)
            Me.tabConfigs.Controls.Add(Me.groupBox10)
            Me.tabConfigs.Controls.Add(Me.groupBox4)
            Me.tabConfigs.Controls.Add(Me.groupBox3)
            Me.tabConfigs.Controls.Add(Me.groupBox2)
            Me.tabConfigs.Controls.Add(Me.groupBox1)
            Me.tabConfigs.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.tabConfigs.Location = New System.Drawing.Point(4, 22)
            Me.tabConfigs.Name = "tabConfigs"
            Me.tabConfigs.Padding = New System.Windows.Forms.Padding(3)
            Me.tabConfigs.Size = New System.Drawing.Size(1451, 897)
            Me.tabConfigs.TabIndex = 0
            Me.tabConfigs.Text = "Configurações"
            Me.tabConfigs.UseVisualStyleBackColor = True
            '
            'groupBox9
            '
            Me.groupBox9.Controls.Add(Me.txtDataHoraUF)
            Me.groupBox9.Controls.Add(Me.Label31)
            Me.groupBox9.Controls.Add(Me.comboAplicaDataHora)
            Me.groupBox9.Controls.Add(Me.btnDataHoraUF)
            Me.groupBox9.Controls.Add(Me.label17)
            Me.groupBox9.Controls.Add(Me.txtSerieMaxima)
            Me.groupBox9.Controls.Add(Me.label16)
            Me.groupBox9.Controls.Add(Me.txtSerieMinima)
            Me.groupBox9.Controls.Add(Me.label15)
            Me.groupBox9.Controls.Add(Me.comboAdicionaisUF)
            Me.groupBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.groupBox9.Location = New System.Drawing.Point(568, 361)
            Me.groupBox9.Name = "groupBox9"
            Me.groupBox9.Size = New System.Drawing.Size(773, 341)
            Me.groupBox9.TabIndex = 10
            Me.groupBox9.TabStop = False
            Me.groupBox9.Text = "Configs. adicionais da UF"
            '
            'txtDataHoraUF
            '
            Me.txtDataHoraUF.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtDataHoraUF.Location = New System.Drawing.Point(16, 160)
            Me.txtDataHoraUF.Multiline = True
            Me.txtDataHoraUF.Name = "txtDataHoraUF"
            Me.txtDataHoraUF.ScrollBars = System.Windows.Forms.ScrollBars.Both
            Me.txtDataHoraUF.Size = New System.Drawing.Size(741, 161)
            Me.txtDataHoraUF.TabIndex = 15
            '
            'Label31
            '
            Me.Label31.AutoSize = True
            Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label31.Location = New System.Drawing.Point(17, 91)
            Me.Label31.Name = "Label31"
            Me.Label31.Size = New System.Drawing.Size(50, 16)
            Me.Label31.TabIndex = 14
            Me.Label31.Text = "Aplicar"
            '
            'comboAplicaDataHora
            '
            Me.comboAplicaDataHora.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.comboAplicaDataHora.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.comboAplicaDataHora.FormattingEnabled = True
            Me.comboAplicaDataHora.ImeMode = System.Windows.Forms.ImeMode.NoControl
            Me.comboAplicaDataHora.Items.AddRange(New Object() {"Não", "Sim"})
            Me.comboAplicaDataHora.Location = New System.Drawing.Point(16, 110)
            Me.comboAplicaDataHora.Name = "comboAplicaDataHora"
            Me.comboAplicaDataHora.Size = New System.Drawing.Size(121, 24)
            Me.comboAplicaDataHora.TabIndex = 13
            '
            'btnDataHoraUF
            '
            Me.btnDataHoraUF.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnDataHoraUF.Location = New System.Drawing.Point(153, 111)
            Me.btnDataHoraUF.Name = "btnDataHoraUF"
            Me.btnDataHoraUF.Size = New System.Drawing.Size(124, 23)
            Me.btnDataHoraUF.TabIndex = 12
            Me.btnDataHoraUF.Text = "Data/Hora UF"
            Me.btnDataHoraUF.UseVisualStyleBackColor = True
            '
            'label17
            '
            Me.label17.AutoSize = True
            Me.label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label17.Location = New System.Drawing.Point(317, 27)
            Me.label17.Name = "label17"
            Me.label17.Size = New System.Drawing.Size(90, 16)
            Me.label17.TabIndex = 7
            Me.label17.Text = "Série Máxima"
            '
            'txtSerieMaxima
            '
            Me.txtSerieMaxima.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtSerieMaxima.Location = New System.Drawing.Point(317, 47)
            Me.txtSerieMaxima.Name = "txtSerieMaxima"
            Me.txtSerieMaxima.Size = New System.Drawing.Size(100, 22)
            Me.txtSerieMaxima.TabIndex = 6
            '
            'label16
            '
            Me.label16.AutoSize = True
            Me.label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label16.Location = New System.Drawing.Point(197, 27)
            Me.label16.Name = "label16"
            Me.label16.Size = New System.Drawing.Size(86, 16)
            Me.label16.TabIndex = 5
            Me.label16.Text = "Série Mínima"
            '
            'txtSerieMinima
            '
            Me.txtSerieMinima.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtSerieMinima.Location = New System.Drawing.Point(197, 47)
            Me.txtSerieMinima.Name = "txtSerieMinima"
            Me.txtSerieMinima.Size = New System.Drawing.Size(100, 22)
            Me.txtSerieMinima.TabIndex = 4
            '
            'label15
            '
            Me.label15.AutoSize = True
            Me.label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label15.Location = New System.Drawing.Point(16, 27)
            Me.label15.Name = "label15"
            Me.label15.Size = New System.Drawing.Size(26, 16)
            Me.label15.TabIndex = 3
            Me.label15.Text = "UF"
            '
            'comboAdicionaisUF
            '
            Me.comboAdicionaisUF.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.comboAdicionaisUF.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.comboAdicionaisUF.FormattingEnabled = True
            Me.comboAdicionaisUF.Items.AddRange(New Object() {"AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MG", "MS", "MT", "PA", "PB", "PE", "PI", "PR", "RJ", "RN", "RO", "RR", "RS", "SC", "SE", "SP", "TO"})
            Me.comboAdicionaisUF.Location = New System.Drawing.Point(16, 46)
            Me.comboAdicionaisUF.Name = "comboAdicionaisUF"
            Me.comboAdicionaisUF.Size = New System.Drawing.Size(140, 24)
            Me.comboAdicionaisUF.TabIndex = 2
            '
            'groupBox5
            '
            Me.groupBox5.Controls.Add(Me.checkContingencia)
            Me.groupBox5.Controls.Add(Me.GroupBox12)
            Me.groupBox5.Controls.Add(Me.label28)
            Me.groupBox5.Controls.Add(Me.comboAutoIncremento)
            Me.groupBox5.Controls.Add(Me.label27)
            Me.groupBox5.Controls.Add(Me.comboAutopreenchimento)
            Me.groupBox5.Controls.Add(Me.txtURLConsultaChaveAcesso)
            Me.groupBox5.Controls.Add(Me.label14)
            Me.groupBox5.Controls.Add(Me.txtURLQRCode)
            Me.groupBox5.Controls.Add(Me.label13)
            Me.groupBox5.Controls.Add(Me.label12)
            Me.groupBox5.Controls.Add(Me.comboTipoContingencia)
            Me.groupBox5.Controls.Add(Me.txtCodigoCSC)
            Me.groupBox5.Controls.Add(Me.label11)
            Me.groupBox5.Controls.Add(Me.txtTokenCSC)
            Me.groupBox5.Controls.Add(Me.label10)
            Me.groupBox5.Controls.Add(Me.label9)
            Me.groupBox5.Controls.Add(Me.comboUF)
            Me.groupBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.groupBox5.Location = New System.Drawing.Point(568, 19)
            Me.groupBox5.Name = "groupBox5"
            Me.groupBox5.Size = New System.Drawing.Size(773, 336)
            Me.groupBox5.TabIndex = 8
            Me.groupBox5.TabStop = False
            Me.groupBox5.Text = "Parâmetros Emsissão"
            '
            'checkContingencia
            '
            Me.checkContingencia.AutoSize = True
            Me.checkContingencia.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.checkContingencia.Location = New System.Drawing.Point(20, 270)
            Me.checkContingencia.Name = "checkContingencia"
            Me.checkContingencia.Size = New System.Drawing.Size(139, 20)
            Me.checkContingencia.TabIndex = 18
            Me.checkContingencia.Text = "Emitir contingência"
            Me.checkContingencia.UseVisualStyleBackColor = True
            '
            'GroupBox12
            '
            Me.GroupBox12.Controls.Add(Me.btnDefinirSequencial)
            Me.GroupBox12.Controls.Add(Me.Label30)
            Me.GroupBox12.Controls.Add(Me.Label29)
            Me.GroupBox12.Controls.Add(Me.txtDefineSequencial)
            Me.GroupBox12.Controls.Add(Me.txtDefineSerie)
            Me.GroupBox12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.GroupBox12.Location = New System.Drawing.Point(376, 200)
            Me.GroupBox12.Name = "GroupBox12"
            Me.GroupBox12.Size = New System.Drawing.Size(381, 124)
            Me.GroupBox12.TabIndex = 16
            Me.GroupBox12.TabStop = False
            Me.GroupBox12.Text = "Definir Sequencial Inicial"
            '
            'btnDefinirSequencial
            '
            Me.btnDefinirSequencial.Location = New System.Drawing.Point(217, 46)
            Me.btnDefinirSequencial.Name = "btnDefinirSequencial"
            Me.btnDefinirSequencial.Size = New System.Drawing.Size(75, 23)
            Me.btnDefinirSequencial.TabIndex = 4
            Me.btnDefinirSequencial.Text = "Definir"
            Me.btnDefinirSequencial.UseVisualStyleBackColor = True
            '
            'Label30
            '
            Me.Label30.AutoSize = True
            Me.Label30.Location = New System.Drawing.Point(121, 28)
            Me.Label30.Name = "Label30"
            Me.Label30.Size = New System.Drawing.Size(76, 16)
            Me.Label30.TabIndex = 3
            Me.Label30.Text = "Sequencial"
            '
            'Label29
            '
            Me.Label29.AutoSize = True
            Me.Label29.Location = New System.Drawing.Point(21, 28)
            Me.Label29.Name = "Label29"
            Me.Label29.Size = New System.Drawing.Size(40, 16)
            Me.Label29.TabIndex = 2
            Me.Label29.Text = "Série"
            '
            'txtDefineSequencial
            '
            Me.txtDefineSequencial.Location = New System.Drawing.Point(124, 47)
            Me.txtDefineSequencial.Name = "txtDefineSequencial"
            Me.txtDefineSequencial.Size = New System.Drawing.Size(87, 22)
            Me.txtDefineSequencial.TabIndex = 1
            Me.txtDefineSequencial.Text = "0"
            '
            'txtDefineSerie
            '
            Me.txtDefineSerie.Location = New System.Drawing.Point(21, 47)
            Me.txtDefineSerie.Name = "txtDefineSerie"
            Me.txtDefineSerie.Size = New System.Drawing.Size(82, 22)
            Me.txtDefineSerie.TabIndex = 0
            Me.txtDefineSerie.Text = "0"
            '
            'label28
            '
            Me.label28.AutoSize = True
            Me.label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label28.Location = New System.Drawing.Point(183, 207)
            Me.label28.Name = "label28"
            Me.label28.Size = New System.Drawing.Size(125, 16)
            Me.label28.TabIndex = 15
            Me.label28.Text = "Auto incremento NF"
            '
            'comboAutoIncremento
            '
            Me.comboAutoIncremento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.comboAutoIncremento.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.comboAutoIncremento.FormattingEnabled = True
            Me.comboAutoIncremento.Items.AddRange(New Object() {"Não", "Sim"})
            Me.comboAutoIncremento.Location = New System.Drawing.Point(186, 228)
            Me.comboAutoIncremento.Name = "comboAutoIncremento"
            Me.comboAutoIncremento.Size = New System.Drawing.Size(142, 24)
            Me.comboAutoIncremento.TabIndex = 14
            '
            'label27
            '
            Me.label27.AutoSize = True
            Me.label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label27.Location = New System.Drawing.Point(17, 209)
            Me.label27.Name = "label27"
            Me.label27.Size = New System.Drawing.Size(148, 16)
            Me.label27.TabIndex = 13
            Me.label27.Text = "Auto preenchimento NF"
            '
            'comboAutopreenchimento
            '
            Me.comboAutopreenchimento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.comboAutopreenchimento.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.comboAutopreenchimento.FormattingEnabled = True
            Me.comboAutopreenchimento.Items.AddRange(New Object() {"Não", "Sim"})
            Me.comboAutopreenchimento.Location = New System.Drawing.Point(20, 230)
            Me.comboAutopreenchimento.Name = "comboAutopreenchimento"
            Me.comboAutopreenchimento.Size = New System.Drawing.Size(142, 24)
            Me.comboAutopreenchimento.TabIndex = 12
            '
            'txtURLConsultaChaveAcesso
            '
            Me.txtURLConsultaChaveAcesso.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtURLConsultaChaveAcesso.Location = New System.Drawing.Point(373, 162)
            Me.txtURLConsultaChaveAcesso.Name = "txtURLConsultaChaveAcesso"
            Me.txtURLConsultaChaveAcesso.Size = New System.Drawing.Size(384, 22)
            Me.txtURLConsultaChaveAcesso.TabIndex = 11
            '
            'label14
            '
            Me.label14.AutoSize = True
            Me.label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label14.Location = New System.Drawing.Point(373, 142)
            Me.label14.Name = "label14"
            Me.label14.Size = New System.Drawing.Size(214, 16)
            Me.label14.TabIndex = 10
            Me.label14.Text = "URL consulta da chave de acesso"
            '
            'txtURLQRCode
            '
            Me.txtURLQRCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtURLQRCode.Location = New System.Drawing.Point(373, 104)
            Me.txtURLQRCode.Name = "txtURLQRCode"
            Me.txtURLQRCode.Size = New System.Drawing.Size(384, 22)
            Me.txtURLQRCode.TabIndex = 9
            '
            'label13
            '
            Me.label13.AutoSize = True
            Me.label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label13.Location = New System.Drawing.Point(373, 84)
            Me.label13.Name = "label13"
            Me.label13.Size = New System.Drawing.Size(144, 16)
            Me.label13.TabIndex = 8
            Me.label13.Text = "URL consulta QRCode"
            '
            'label12
            '
            Me.label12.AutoSize = True
            Me.label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label12.Location = New System.Drawing.Point(373, 27)
            Me.label12.Name = "label12"
            Me.label12.Size = New System.Drawing.Size(157, 16)
            Me.label12.TabIndex = 7
            Me.label12.Text = "Tipo contingência NFC-e"
            '
            'comboTipoContingencia
            '
            Me.comboTipoContingencia.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.comboTipoContingencia.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.comboTipoContingencia.FormattingEnabled = True
            Me.comboTipoContingencia.Items.AddRange(New Object() {"Sem contingência", "Contingência Offline", "Contingência SAT"})
            Me.comboTipoContingencia.Location = New System.Drawing.Point(373, 46)
            Me.comboTipoContingencia.Name = "comboTipoContingencia"
            Me.comboTipoContingencia.Size = New System.Drawing.Size(266, 24)
            Me.comboTipoContingencia.TabIndex = 6
            '
            'txtCodigoCSC
            '
            Me.txtCodigoCSC.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtCodigoCSC.Location = New System.Drawing.Point(17, 162)
            Me.txtCodigoCSC.Name = "txtCodigoCSC"
            Me.txtCodigoCSC.Size = New System.Drawing.Size(344, 22)
            Me.txtCodigoCSC.TabIndex = 5
            '
            'label11
            '
            Me.label11.AutoSize = True
            Me.label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label11.Location = New System.Drawing.Point(17, 142)
            Me.label11.Name = "label11"
            Me.label11.Size = New System.Drawing.Size(210, 16)
            Me.label11.TabIndex = 4
            Me.label11.Text = "CSC (Código CSC do contribuinte)"
            '
            'txtTokenCSC
            '
            Me.txtTokenCSC.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtTokenCSC.Location = New System.Drawing.Point(17, 104)
            Me.txtTokenCSC.Name = "txtTokenCSC"
            Me.txtTokenCSC.Size = New System.Drawing.Size(243, 22)
            Me.txtTokenCSC.TabIndex = 3
            '
            'label10
            '
            Me.label10.AutoSize = True
            Me.label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label10.Location = New System.Drawing.Point(17, 84)
            Me.label10.Name = "label10"
            Me.label10.Size = New System.Drawing.Size(63, 16)
            Me.label10.TabIndex = 2
            Me.label10.Text = "ID Token"
            '
            'label9
            '
            Me.label9.AutoSize = True
            Me.label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label9.Location = New System.Drawing.Point(17, 27)
            Me.label9.Name = "label9"
            Me.label9.Size = New System.Drawing.Size(26, 16)
            Me.label9.TabIndex = 1
            Me.label9.Text = "UF"
            '
            'comboUF
            '
            Me.comboUF.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.comboUF.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.comboUF.FormattingEnabled = True
            Me.comboUF.Items.AddRange(New Object() {"AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MG", "MS", "MT", "PA", "PB", "PE", "PI", "PR", "RJ", "RN", "RO", "RR", "RS", "SC", "SE", "SP", "TO"})
            Me.comboUF.Location = New System.Drawing.Point(17, 46)
            Me.comboUF.Name = "comboUF"
            Me.comboUF.Size = New System.Drawing.Size(140, 24)
            Me.comboUF.TabIndex = 0
            '
            'groupBox11
            '
            Me.groupBox11.Controls.Add(Me.comboImpressoras)
            Me.groupBox11.Controls.Add(Me.txtPortaImpressora)
            Me.groupBox11.Controls.Add(Me.txtIPImpressora)
            Me.groupBox11.Controls.Add(Me.label26)
            Me.groupBox11.Controls.Add(Me.label25)
            Me.groupBox11.Controls.Add(Me.label24)
            Me.groupBox11.Location = New System.Drawing.Point(8, 721)
            Me.groupBox11.Name = "groupBox11"
            Me.groupBox11.Size = New System.Drawing.Size(533, 151)
            Me.groupBox11.TabIndex = 7
            Me.groupBox11.TabStop = False
            Me.groupBox11.Text = "Impressora"
            '
            'comboImpressoras
            '
            Me.comboImpressoras.FormattingEnabled = True
            Me.comboImpressoras.Location = New System.Drawing.Point(69, 24)
            Me.comboImpressoras.Name = "comboImpressoras"
            Me.comboImpressoras.Size = New System.Drawing.Size(442, 24)
            Me.comboImpressoras.TabIndex = 6
            '
            'txtPortaImpressora
            '
            Me.txtPortaImpressora.Location = New System.Drawing.Point(69, 96)
            Me.txtPortaImpressora.Name = "txtPortaImpressora"
            Me.txtPortaImpressora.Size = New System.Drawing.Size(224, 23)
            Me.txtPortaImpressora.TabIndex = 5
            '
            'txtIPImpressora
            '
            Me.txtIPImpressora.Location = New System.Drawing.Point(69, 59)
            Me.txtIPImpressora.Name = "txtIPImpressora"
            Me.txtIPImpressora.Size = New System.Drawing.Size(224, 23)
            Me.txtIPImpressora.TabIndex = 4
            '
            'label26
            '
            Me.label26.AutoSize = True
            Me.label26.Location = New System.Drawing.Point(21, 99)
            Me.label26.Name = "label26"
            Me.label26.Size = New System.Drawing.Size(42, 17)
            Me.label26.TabIndex = 2
            Me.label26.Text = "Porta"
            '
            'label25
            '
            Me.label25.AutoSize = True
            Me.label25.Location = New System.Drawing.Point(21, 59)
            Me.label25.Name = "label25"
            Me.label25.Size = New System.Drawing.Size(20, 17)
            Me.label25.TabIndex = 1
            Me.label25.Text = "IP"
            '
            'label24
            '
            Me.label24.AutoSize = True
            Me.label24.Location = New System.Drawing.Point(18, 27)
            Me.label24.Name = "label24"
            Me.label24.Size = New System.Drawing.Size(45, 17)
            Me.label24.TabIndex = 0
            Me.label24.Text = "Nome"
            '
            'groupBox10
            '
            Me.groupBox10.Controls.Add(Me.label22)
            Me.groupBox10.Controls.Add(Me.label23)
            Me.groupBox10.Controls.Add(Me.txtTimeout)
            Me.groupBox10.Controls.Add(Me.label20)
            Me.groupBox10.Controls.Add(Me.label21)
            Me.groupBox10.Controls.Add(Me.txtAtrasoContingencia)
            Me.groupBox10.Controls.Add(Me.label19)
            Me.groupBox10.Controls.Add(Me.label18)
            Me.groupBox10.Controls.Add(Me.txtTempoVerificacao)
            Me.groupBox10.Location = New System.Drawing.Point(6, 521)
            Me.groupBox10.Name = "groupBox10"
            Me.groupBox10.Size = New System.Drawing.Size(535, 181)
            Me.groupBox10.TabIndex = 6
            Me.groupBox10.TabStop = False
            Me.groupBox10.Text = "Gerais"
            '
            'label22
            '
            Me.label22.AutoSize = True
            Me.label22.Location = New System.Drawing.Point(268, 113)
            Me.label22.Name = "label22"
            Me.label22.Size = New System.Drawing.Size(70, 17)
            Me.label22.TabIndex = 8
            Me.label22.Text = "segundos"
            '
            'label23
            '
            Me.label23.AutoSize = True
            Me.label23.Location = New System.Drawing.Point(9, 113)
            Me.label23.Name = "label23"
            Me.label23.Size = New System.Drawing.Size(118, 17)
            Me.label23.TabIndex = 7
            Me.label23.Text = "Timeout Conexão"
            '
            'txtTimeout
            '
            Me.txtTimeout.Location = New System.Drawing.Point(162, 110)
            Me.txtTimeout.Name = "txtTimeout"
            Me.txtTimeout.Size = New System.Drawing.Size(100, 23)
            Me.txtTimeout.TabIndex = 6
            '
            'label20
            '
            Me.label20.AutoSize = True
            Me.label20.Location = New System.Drawing.Point(268, 80)
            Me.label20.Name = "label20"
            Me.label20.Size = New System.Drawing.Size(70, 17)
            Me.label20.TabIndex = 5
            Me.label20.Text = "segundos"
            '
            'label21
            '
            Me.label21.AutoSize = True
            Me.label21.Location = New System.Drawing.Point(9, 80)
            Me.label21.Name = "label21"
            Me.label21.Size = New System.Drawing.Size(134, 17)
            Me.label21.TabIndex = 4
            Me.label21.Text = "Contingência atraso"
            '
            'txtAtrasoContingencia
            '
            Me.txtAtrasoContingencia.Location = New System.Drawing.Point(162, 77)
            Me.txtAtrasoContingencia.Name = "txtAtrasoContingencia"
            Me.txtAtrasoContingencia.Size = New System.Drawing.Size(100, 23)
            Me.txtAtrasoContingencia.TabIndex = 3
            '
            'label19
            '
            Me.label19.AutoSize = True
            Me.label19.Location = New System.Drawing.Point(268, 51)
            Me.label19.Name = "label19"
            Me.label19.Size = New System.Drawing.Size(70, 17)
            Me.label19.TabIndex = 2
            Me.label19.Text = "segundos"
            '
            'label18
            '
            Me.label18.AutoSize = True
            Me.label18.Location = New System.Drawing.Point(9, 51)
            Me.label18.Name = "label18"
            Me.label18.Size = New System.Drawing.Size(126, 17)
            Me.label18.TabIndex = 1
            Me.label18.Text = "Tempo Verificação"
            '
            'txtTempoVerificacao
            '
            Me.txtTempoVerificacao.Location = New System.Drawing.Point(162, 48)
            Me.txtTempoVerificacao.Name = "txtTempoVerificacao"
            Me.txtTempoVerificacao.Size = New System.Drawing.Size(100, 23)
            Me.txtTempoVerificacao.TabIndex = 0
            '
            'groupBox4
            '
            Me.groupBox4.Controls.Add(Me.txtCnpjSAT)
            Me.groupBox4.Controls.Add(Me.label8)
            Me.groupBox4.Controls.Add(Me.txtAssinaturaSAT)
            Me.groupBox4.Controls.Add(Me.label7)
            Me.groupBox4.Controls.Add(Me.txtCodigoAtivacaoSAT)
            Me.groupBox4.Controls.Add(Me.label6)
            Me.groupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.groupBox4.Location = New System.Drawing.Point(6, 361)
            Me.groupBox4.Name = "groupBox4"
            Me.groupBox4.Size = New System.Drawing.Size(535, 142)
            Me.groupBox4.TabIndex = 3
            Me.groupBox4.TabStop = False
            Me.groupBox4.Text = "Configurações SAT"
            '
            'txtCnpjSAT
            '
            Me.txtCnpjSAT.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtCnpjSAT.Location = New System.Drawing.Point(132, 65)
            Me.txtCnpjSAT.Name = "txtCnpjSAT"
            Me.txtCnpjSAT.Size = New System.Drawing.Size(217, 23)
            Me.txtCnpjSAT.TabIndex = 6
            '
            'label8
            '
            Me.label8.AutoSize = True
            Me.label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label8.Location = New System.Drawing.Point(6, 71)
            Me.label8.Name = "label8"
            Me.label8.Size = New System.Drawing.Size(43, 17)
            Me.label8.TabIndex = 5
            Me.label8.Text = "CNPJ"
            '
            'txtAssinaturaSAT
            '
            Me.txtAssinaturaSAT.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtAssinaturaSAT.Location = New System.Drawing.Point(132, 101)
            Me.txtAssinaturaSAT.Name = "txtAssinaturaSAT"
            Me.txtAssinaturaSAT.Size = New System.Drawing.Size(336, 23)
            Me.txtAssinaturaSAT.TabIndex = 3
            '
            'label7
            '
            Me.label7.AutoSize = True
            Me.label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label7.Location = New System.Drawing.Point(6, 104)
            Me.label7.Name = "label7"
            Me.label7.Size = New System.Drawing.Size(79, 17)
            Me.label7.TabIndex = 2
            Me.label7.Text = "Assintatura"
            '
            'txtCodigoAtivacaoSAT
            '
            Me.txtCodigoAtivacaoSAT.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtCodigoAtivacaoSAT.Location = New System.Drawing.Point(133, 36)
            Me.txtCodigoAtivacaoSAT.Name = "txtCodigoAtivacaoSAT"
            Me.txtCodigoAtivacaoSAT.Size = New System.Drawing.Size(335, 23)
            Me.txtCodigoAtivacaoSAT.TabIndex = 1
            '
            'label6
            '
            Me.label6.AutoSize = True
            Me.label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label6.Location = New System.Drawing.Point(6, 39)
            Me.label6.Name = "label6"
            Me.label6.Size = New System.Drawing.Size(129, 17)
            Me.label6.TabIndex = 0
            Me.label6.Text = "Código de ativação"
            '
            'groupBox3
            '
            Me.groupBox3.Controls.Add(Me.txtChaveParceiro)
            Me.groupBox3.Controls.Add(Me.label5)
            Me.groupBox3.Controls.Add(Me.txtChaveAcesso)
            Me.groupBox3.Controls.Add(Me.txtCnpj)
            Me.groupBox3.Controls.Add(Me.label4)
            Me.groupBox3.Controls.Add(Me.label3)
            Me.groupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.groupBox3.Location = New System.Drawing.Point(6, 185)
            Me.groupBox3.Name = "groupBox3"
            Me.groupBox3.Size = New System.Drawing.Size(535, 160)
            Me.groupBox3.TabIndex = 2
            Me.groupBox3.TabStop = False
            Me.groupBox3.Text = "Configurações Invoicy"
            '
            'txtChaveParceiro
            '
            Me.txtChaveParceiro.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtChaveParceiro.Location = New System.Drawing.Point(133, 102)
            Me.txtChaveParceiro.Name = "txtChaveParceiro"
            Me.txtChaveParceiro.Size = New System.Drawing.Size(335, 23)
            Me.txtChaveParceiro.TabIndex = 5
            '
            'label5
            '
            Me.label5.AutoSize = True
            Me.label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label5.Location = New System.Drawing.Point(6, 105)
            Me.label5.Name = "label5"
            Me.label5.Size = New System.Drawing.Size(125, 17)
            Me.label5.TabIndex = 4
            Me.label5.Text = "Chave do Parceiro"
            '
            'txtChaveAcesso
            '
            Me.txtChaveAcesso.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtChaveAcesso.Location = New System.Drawing.Point(133, 65)
            Me.txtChaveAcesso.Name = "txtChaveAcesso"
            Me.txtChaveAcesso.Size = New System.Drawing.Size(335, 23)
            Me.txtChaveAcesso.TabIndex = 3
            '
            'txtCnpj
            '
            Me.txtCnpj.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtCnpj.Location = New System.Drawing.Point(132, 34)
            Me.txtCnpj.Name = "txtCnpj"
            Me.txtCnpj.Size = New System.Drawing.Size(176, 23)
            Me.txtCnpj.TabIndex = 2
            '
            'label4
            '
            Me.label4.AutoSize = True
            Me.label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label4.Location = New System.Drawing.Point(6, 34)
            Me.label4.Name = "label4"
            Me.label4.Size = New System.Drawing.Size(43, 17)
            Me.label4.TabIndex = 1
            Me.label4.Text = "CNPJ"
            '
            'label3
            '
            Me.label3.AutoSize = True
            Me.label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label3.Location = New System.Drawing.Point(6, 65)
            Me.label3.Name = "label3"
            Me.label3.Size = New System.Drawing.Size(118, 17)
            Me.label3.TabIndex = 0
            Me.label3.Text = "Chave de Acesso"
            '
            'groupBox2
            '
            Me.groupBox2.Controls.Add(Me.lblErroDiretorio)
            Me.groupBox2.Controls.Add(Me.btnConfiguraDiretorio)
            Me.groupBox2.Controls.Add(Me.txtDiretorioArmazenamento)
            Me.groupBox2.Controls.Add(Me.label2)
            Me.groupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.groupBox2.Location = New System.Drawing.Point(6, 98)
            Me.groupBox2.Name = "groupBox2"
            Me.groupBox2.Size = New System.Drawing.Size(535, 79)
            Me.groupBox2.TabIndex = 1
            Me.groupBox2.TabStop = False
            Me.groupBox2.Text = "Diretório de armazenamento"
            '
            'lblErroDiretorio
            '
            Me.lblErroDiretorio.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.lblErroDiretorio.ForeColor = System.Drawing.Color.Red
            Me.lblErroDiretorio.Location = New System.Drawing.Point(79, 54)
            Me.lblErroDiretorio.Name = "lblErroDiretorio"
            Me.lblErroDiretorio.Size = New System.Drawing.Size(270, 22)
            Me.lblErroDiretorio.TabIndex = 3
            Me.lblErroDiretorio.Text = "Informe o diretório de armazenamento"
            Me.lblErroDiretorio.Visible = False
            '
            'btnConfiguraDiretorio
            '
            Me.btnConfiguraDiretorio.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnConfiguraDiretorio.Location = New System.Drawing.Point(415, 20)
            Me.btnConfiguraDiretorio.Name = "btnConfiguraDiretorio"
            Me.btnConfiguraDiretorio.Size = New System.Drawing.Size(97, 31)
            Me.btnConfiguraDiretorio.TabIndex = 2
            Me.btnConfiguraDiretorio.Text = "Selecionar"
            Me.btnConfiguraDiretorio.UseVisualStyleBackColor = True
            '
            'txtDiretorioArmazenamento
            '
            Me.txtDiretorioArmazenamento.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.txtDiretorioArmazenamento.Location = New System.Drawing.Point(79, 24)
            Me.txtDiretorioArmazenamento.Name = "txtDiretorioArmazenamento"
            Me.txtDiretorioArmazenamento.Size = New System.Drawing.Size(320, 23)
            Me.txtDiretorioArmazenamento.TabIndex = 1
            '
            'label2
            '
            Me.label2.AutoSize = True
            Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label2.Location = New System.Drawing.Point(6, 27)
            Me.label2.Name = "label2"
            Me.label2.Size = New System.Drawing.Size(63, 17)
            Me.label2.TabIndex = 0
            Me.label2.Text = "Caminho"
            '
            'groupBox1
            '
            Me.groupBox1.Controls.Add(Me.label1)
            Me.groupBox1.Controls.Add(Me.comboAmbiente)
            Me.groupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.groupBox1.Location = New System.Drawing.Point(6, 19)
            Me.groupBox1.Name = "groupBox1"
            Me.groupBox1.Size = New System.Drawing.Size(535, 73)
            Me.groupBox1.TabIndex = 0
            Me.groupBox1.TabStop = False
            Me.groupBox1.Text = "Ambiente"
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label1.Location = New System.Drawing.Point(6, 27)
            Me.label1.Name = "label1"
            Me.label1.Size = New System.Drawing.Size(67, 17)
            Me.label1.TabIndex = 1
            Me.label1.Text = "Ambiente"
            '
            'comboAmbiente
            '
            Me.comboAmbiente.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.comboAmbiente.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.comboAmbiente.FormattingEnabled = True
            Me.comboAmbiente.Items.AddRange(New Object() {"Documento XML", "Produção", "Homologação"})
            Me.comboAmbiente.Location = New System.Drawing.Point(79, 27)
            Me.comboAmbiente.Name = "comboAmbiente"
            Me.comboAmbiente.Size = New System.Drawing.Size(229, 24)
            Me.comboAmbiente.TabIndex = 0
            '
            'tabEmissao
            '
            Me.tabEmissao.Controls.Add(Me.groupBox8)
            Me.tabEmissao.Controls.Add(Me.groupBox7)
            Me.tabEmissao.Controls.Add(Me.groupBox6)
            Me.tabEmissao.Location = New System.Drawing.Point(4, 22)
            Me.tabEmissao.Name = "tabEmissao"
            Me.tabEmissao.Padding = New System.Windows.Forms.Padding(3)
            Me.tabEmissao.Size = New System.Drawing.Size(1451, 897)
            Me.tabEmissao.TabIndex = 1
            Me.tabEmissao.Text = "Emissão/Consultas"
            Me.tabEmissao.UseVisualStyleBackColor = True
            '
            'groupBox8
            '
            Me.groupBox8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.groupBox8.Controls.Add(Me.txtRetornoEmissao)
            Me.groupBox8.Location = New System.Drawing.Point(6, 620)
            Me.groupBox8.Name = "groupBox8"
            Me.groupBox8.Size = New System.Drawing.Size(1439, 271)
            Me.groupBox8.TabIndex = 5
            Me.groupBox8.TabStop = False
            Me.groupBox8.Text = "Retorno emissão"
            '
            'txtRetornoEmissao
            '
            Me.txtRetornoEmissao.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.txtRetornoEmissao.Location = New System.Drawing.Point(6, 19)
            Me.txtRetornoEmissao.Multiline = True
            Me.txtRetornoEmissao.Name = "txtRetornoEmissao"
            Me.txtRetornoEmissao.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
            Me.txtRetornoEmissao.Size = New System.Drawing.Size(1417, 235)
            Me.txtRetornoEmissao.TabIndex = 0
            '
            'groupBox7
            '
            Me.groupBox7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.groupBox7.Controls.Add(Me.txtXMLParametrosEmissao)
            Me.groupBox7.Location = New System.Drawing.Point(9, 532)
            Me.groupBox7.Name = "groupBox7"
            Me.groupBox7.Size = New System.Drawing.Size(1439, 82)
            Me.groupBox7.TabIndex = 2
            Me.groupBox7.TabStop = False
            Me.groupBox7.Text = "XML Parâmetros"
            '
            'txtXMLParametrosEmissao
            '
            Me.txtXMLParametrosEmissao.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.txtXMLParametrosEmissao.Location = New System.Drawing.Point(6, 19)
            Me.txtXMLParametrosEmissao.Multiline = True
            Me.txtXMLParametrosEmissao.Name = "txtXMLParametrosEmissao"
            Me.txtXMLParametrosEmissao.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
            Me.txtXMLParametrosEmissao.Size = New System.Drawing.Size(1417, 57)
            Me.txtXMLParametrosEmissao.TabIndex = 0
            '
            'groupBox6
            '
            Me.groupBox6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.groupBox6.Controls.Add(Me.toolStrip2)
            Me.groupBox6.Controls.Add(Me.txtXmlEntradaEmissao)
            Me.groupBox6.Location = New System.Drawing.Point(6, 6)
            Me.groupBox6.Name = "groupBox6"
            Me.groupBox6.Size = New System.Drawing.Size(1439, 520)
            Me.groupBox6.TabIndex = 1
            Me.groupBox6.TabStop = False
            Me.groupBox6.Text = "XML Entrada"
            '
            'toolStrip2
            '
            Me.toolStrip2.Dock = System.Windows.Forms.DockStyle.Right
            Me.toolStrip2.ImageScalingSize = New System.Drawing.Size(32, 32)
            Me.toolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.stpClearXml, Me.tbsEmitir})
            Me.toolStrip2.Location = New System.Drawing.Point(1399, 16)
            Me.toolStrip2.Name = "toolStrip2"
            Me.toolStrip2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
            Me.toolStrip2.Size = New System.Drawing.Size(37, 501)
            Me.toolStrip2.Stretch = True
            Me.toolStrip2.TabIndex = 2
            Me.toolStrip2.Text = "toolStrip2"
            '
            'stpClearXml
            '
            Me.stpClearXml.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
            Me.stpClearXml.Image = CType(resources.GetObject("stpClearXml.Image"), System.Drawing.Image)
            Me.stpClearXml.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.stpClearXml.Name = "stpClearXml"
            Me.stpClearXml.Size = New System.Drawing.Size(34, 36)
            Me.stpClearXml.ToolTipText = "Apagar conteúdo"
            '
            'tbsEmitir
            '
            Me.tbsEmitir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
            Me.tbsEmitir.Enabled = False
            Me.tbsEmitir.Image = CType(resources.GetObject("tbsEmitir.Image"), System.Drawing.Image)
            Me.tbsEmitir.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.tbsEmitir.Name = "tbsEmitir"
            Me.tbsEmitir.Size = New System.Drawing.Size(34, 36)
            Me.tbsEmitir.ToolTipText = "Emitir"
            '
            'txtXmlEntradaEmissao
            '
            Me.txtXmlEntradaEmissao.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.txtXmlEntradaEmissao.Location = New System.Drawing.Point(6, 28)
            Me.txtXmlEntradaEmissao.MaxLength = 1000000000
            Me.txtXmlEntradaEmissao.Multiline = True
            Me.txtXmlEntradaEmissao.Name = "txtXmlEntradaEmissao"
            Me.txtXmlEntradaEmissao.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
            Me.txtXmlEntradaEmissao.Size = New System.Drawing.Size(1375, 486)
            Me.txtXmlEntradaEmissao.TabIndex = 0
            '
            'tabLogs
            '
            Me.tabLogs.Controls.Add(Me.ToolStrip3)
            Me.tabLogs.Controls.Add(Me.txtLogs)
            Me.tabLogs.Location = New System.Drawing.Point(4, 22)
            Me.tabLogs.Name = "tabLogs"
            Me.tabLogs.Padding = New System.Windows.Forms.Padding(3)
            Me.tabLogs.Size = New System.Drawing.Size(1451, 897)
            Me.tabLogs.TabIndex = 2
            Me.tabLogs.Text = "Logs"
            Me.tabLogs.UseVisualStyleBackColor = True
            '
            'txtLogs
            '
            Me.txtLogs.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.txtLogs.Location = New System.Drawing.Point(3, 3)
            Me.txtLogs.Multiline = True
            Me.txtLogs.Name = "txtLogs"
            Me.txtLogs.ScrollBars = System.Windows.Forms.ScrollBars.Both
            Me.txtLogs.Size = New System.Drawing.Size(1405, 891)
            Me.txtLogs.TabIndex = 0
            '
            'folderBrowserDialog1
            '
            Me.folderBrowserDialog1.RootFolder = System.Environment.SpecialFolder.MyComputer
            '
            'panel1
            '
            Me.panel1.AutoScroll = True
            Me.panel1.Controls.Add(Me.lblAmbiente)
            Me.panel1.Controls.Add(Me.lblVersao)
            Me.panel1.Dock = System.Windows.Forms.DockStyle.Top
            Me.panel1.Location = New System.Drawing.Point(0, 26)
            Me.panel1.Name = "panel1"
            Me.panel1.Size = New System.Drawing.Size(1483, 30)
            Me.panel1.TabIndex = 5
            '
            'lblAmbiente
            '
            Me.lblAmbiente.AutoSize = True
            Me.lblAmbiente.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.lblAmbiente.ForeColor = System.Drawing.Color.Blue
            Me.lblAmbiente.Location = New System.Drawing.Point(220, 12)
            Me.lblAmbiente.Name = "lblAmbiente"
            Me.lblAmbiente.Size = New System.Drawing.Size(0, 16)
            Me.lblAmbiente.TabIndex = 1
            '
            'lblVersao
            '
            Me.lblVersao.AutoSize = True
            Me.lblVersao.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.lblVersao.ForeColor = System.Drawing.Color.Blue
            Me.lblVersao.Location = New System.Drawing.Point(19, 12)
            Me.lblVersao.Name = "lblVersao"
            Me.lblVersao.Size = New System.Drawing.Size(0, 16)
            Me.lblVersao.TabIndex = 0
            '
            'ToolStrip3
            '
            Me.ToolStrip3.Dock = System.Windows.Forms.DockStyle.Right
            Me.ToolStrip3.ImageScalingSize = New System.Drawing.Size(32, 32)
            Me.ToolStrip3.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsbLimparLogs, Me.tsbCarregarLogs})
            Me.ToolStrip3.Location = New System.Drawing.Point(1411, 3)
            Me.ToolStrip3.Name = "ToolStrip3"
            Me.ToolStrip3.Size = New System.Drawing.Size(37, 891)
            Me.ToolStrip3.TabIndex = 1
            Me.ToolStrip3.Text = "ToolStrip3"
            '
            'tsbLimparLogs
            '
            Me.tsbLimparLogs.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
            Me.tsbLimparLogs.Image = CType(resources.GetObject("tsbLimparLogs.Image"), System.Drawing.Image)
            Me.tsbLimparLogs.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.tsbLimparLogs.Name = "tsbLimparLogs"
            Me.tsbLimparLogs.Size = New System.Drawing.Size(34, 36)
            Me.tsbLimparLogs.Text = "ToolStripButton2"
            '
            'tsbCarregarLogs
            '
            Me.tsbCarregarLogs.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
            Me.tsbCarregarLogs.Image = CType(resources.GetObject("tsbCarregarLogs.Image"), System.Drawing.Image)
            Me.tsbCarregarLogs.ImageTransparentColor = System.Drawing.Color.Magenta
            Me.tsbCarregarLogs.Name = "tsbCarregarLogs"
            Me.tsbCarregarLogs.Size = New System.Drawing.Size(34, 36)
            Me.tsbCarregarLogs.Text = "ToolStripButton3"
            '
            'Form1
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.AutoScroll = True
            Me.AutoSize = True
            Me.ClientSize = New System.Drawing.Size(1483, 1021)
            Me.Controls.Add(Me.panel1)
            Me.Controls.Add(Me.tabControl1)
            Me.Controls.Add(Me.toolStrip1)
            Me.Name = "Form1"
            Me.Text = "Emissão de documentos"
            Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
            Me.toolStrip1.ResumeLayout(False)
            Me.toolStrip1.PerformLayout()
            Me.tabControl1.ResumeLayout(False)
            Me.tabConfigs.ResumeLayout(False)
            Me.groupBox9.ResumeLayout(False)
            Me.groupBox9.PerformLayout()
            Me.groupBox5.ResumeLayout(False)
            Me.groupBox5.PerformLayout()
            Me.GroupBox12.ResumeLayout(False)
            Me.GroupBox12.PerformLayout()
            Me.groupBox11.ResumeLayout(False)
            Me.groupBox11.PerformLayout()
            Me.groupBox10.ResumeLayout(False)
            Me.groupBox10.PerformLayout()
            Me.groupBox4.ResumeLayout(False)
            Me.groupBox4.PerformLayout()
            Me.groupBox3.ResumeLayout(False)
            Me.groupBox3.PerformLayout()
            Me.groupBox2.ResumeLayout(False)
            Me.groupBox2.PerformLayout()
            Me.groupBox1.ResumeLayout(False)
            Me.groupBox1.PerformLayout()
            Me.tabEmissao.ResumeLayout(False)
            Me.groupBox8.ResumeLayout(False)
            Me.groupBox8.PerformLayout()
            Me.groupBox7.ResumeLayout(False)
            Me.groupBox7.PerformLayout()
            Me.groupBox6.ResumeLayout(False)
            Me.groupBox6.PerformLayout()
            Me.toolStrip2.ResumeLayout(False)
            Me.toolStrip2.PerformLayout()
            Me.tabLogs.ResumeLayout(False)
            Me.tabLogs.PerformLayout()
            Me.panel1.ResumeLayout(False)
            Me.panel1.PerformLayout()
            Me.ToolStrip3.ResumeLayout(False)
            Me.ToolStrip3.PerformLayout()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

        Private toolStrip1 As System.Windows.Forms.ToolStrip
        Private tabControl1 As System.Windows.Forms.TabControl
        Private tabConfigs As System.Windows.Forms.TabPage
        Private groupBox1 As System.Windows.Forms.GroupBox
        Private label1 As System.Windows.Forms.Label
        Private comboAmbiente As System.Windows.Forms.ComboBox
        Private groupBox2 As System.Windows.Forms.GroupBox
        Private txtDiretorioArmazenamento As System.Windows.Forms.TextBox
        Private label2 As System.Windows.Forms.Label
        Friend WithEvents btnConfiguraDiretorio As System.Windows.Forms.Button
        Private folderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
        Private groupBox3 As System.Windows.Forms.GroupBox
        Private txtChaveParceiro As System.Windows.Forms.TextBox
        Private label5 As System.Windows.Forms.Label
        Private txtChaveAcesso As System.Windows.Forms.TextBox
        Private txtCnpj As System.Windows.Forms.TextBox
        Private label4 As System.Windows.Forms.Label
        Private label3 As System.Windows.Forms.Label
        Private groupBox4 As System.Windows.Forms.GroupBox
        Private txtAssinaturaSAT As System.Windows.Forms.TextBox
        Private label7 As System.Windows.Forms.Label
        Private txtCodigoAtivacaoSAT As System.Windows.Forms.TextBox
        Private label6 As System.Windows.Forms.Label
        Private txtCnpjSAT As System.Windows.Forms.TextBox
        Private label8 As System.Windows.Forms.Label
        Private tabEmissao As System.Windows.Forms.TabPage
        Private groupBox7 As System.Windows.Forms.GroupBox
        Private txtXMLParametrosEmissao As System.Windows.Forms.TextBox
        Private groupBox6 As System.Windows.Forms.GroupBox
        Friend WithEvents txtXmlEntradaEmissao As System.Windows.Forms.TextBox
        Private groupBox8 As System.Windows.Forms.GroupBox
        Private txtRetornoEmissao As System.Windows.Forms.TextBox
        Private panel1 As System.Windows.Forms.Panel
        Private lblVersao As System.Windows.Forms.Label
        Private lblAmbiente As System.Windows.Forms.Label
        Friend WithEvents btnSalvarConfiguracoes As System.Windows.Forms.ToolStripButton
        Private groupBox10 As System.Windows.Forms.GroupBox
        Private label19 As System.Windows.Forms.Label
        Private label18 As System.Windows.Forms.Label
        Private txtTempoVerificacao As System.Windows.Forms.TextBox
        Private label22 As System.Windows.Forms.Label
        Private label23 As System.Windows.Forms.Label
        Private txtTimeout As System.Windows.Forms.TextBox
        Private label20 As System.Windows.Forms.Label
        Private label21 As System.Windows.Forms.Label
        Private txtAtrasoContingencia As System.Windows.Forms.TextBox
        Friend WithEvents toolStripButton1 As System.Windows.Forms.ToolStripButton
        Friend WithEvents toolStripDropDownButton1 As System.Windows.Forms.ToolStripDropDownButton
        Friend WithEvents pendentesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
        Private groupBox11 As System.Windows.Forms.GroupBox
        Private txtPortaImpressora As System.Windows.Forms.TextBox
        Private txtIPImpressora As System.Windows.Forms.TextBox
        Private label26 As System.Windows.Forms.Label
        Private label25 As System.Windows.Forms.Label
        Private label24 As System.Windows.Forms.Label
        Private comboImpressoras As System.Windows.Forms.ComboBox
        Friend WithEvents logsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
        Private tabLogs As System.Windows.Forms.TabPage
        Private txtLogs As System.Windows.Forms.TextBox
        Private groupBox5 As System.Windows.Forms.GroupBox
        Private txtURLConsultaChaveAcesso As System.Windows.Forms.TextBox
        Private label14 As System.Windows.Forms.Label
        Private txtURLQRCode As System.Windows.Forms.TextBox
        Private label13 As System.Windows.Forms.Label
        Private label12 As System.Windows.Forms.Label
        Private comboTipoContingencia As System.Windows.Forms.ComboBox
        Private txtCodigoCSC As System.Windows.Forms.TextBox
        Private label11 As System.Windows.Forms.Label
        Private txtTokenCSC As System.Windows.Forms.TextBox
        Private label10 As System.Windows.Forms.Label
        Private label9 As System.Windows.Forms.Label
        Private comboUF As System.Windows.Forms.ComboBox
        Private groupBox9 As System.Windows.Forms.GroupBox
        Private label17 As System.Windows.Forms.Label
        Private txtSerieMaxima As System.Windows.Forms.TextBox
        Private label16 As System.Windows.Forms.Label
        Private txtSerieMinima As System.Windows.Forms.TextBox
        Private label15 As System.Windows.Forms.Label
        Private comboAdicionaisUF As System.Windows.Forms.ComboBox
        Private label27 As System.Windows.Forms.Label
        Private comboAutopreenchimento As System.Windows.Forms.ComboBox
        Private label28 As System.Windows.Forms.Label
        Private comboAutoIncremento As System.Windows.Forms.ComboBox
        Friend WithEvents GroupBox12 As Windows.Forms.GroupBox
        Friend WithEvents Label30 As Windows.Forms.Label
        Friend WithEvents Label29 As Windows.Forms.Label
        Friend WithEvents txtDefineSequencial As Windows.Forms.TextBox
        Friend WithEvents txtDefineSerie As Windows.Forms.TextBox
        Friend WithEvents btnDefinirSequencial As Windows.Forms.Button
        Private WithEvents Label31 As Windows.Forms.Label
        Private WithEvents comboAplicaDataHora As Windows.Forms.ComboBox
        Private WithEvents btnDataHoraUF As Windows.Forms.Button
        Private WithEvents txtDataHoraUF As Windows.Forms.TextBox
        Private WithEvents checkContingencia As Windows.Forms.CheckBox
        Private WithEvents toolStrip2 As Windows.Forms.ToolStrip
        Private WithEvents stpClearXml As Windows.Forms.ToolStripButton
        Private WithEvents tbsEmitir As Windows.Forms.ToolStripButton
        Friend WithEvents btnEmitirMenu As Windows.Forms.ToolStripDropDownButton
        Friend WithEvents emitirToolStripMenuItem As Windows.Forms.ToolStripMenuItem
        Friend WithEvents emitirEmContingênciaToolStripMenuItem As Windows.Forms.ToolStripMenuItem
        Friend WithEvents EmitirDocumentosPendentesToolStripMenuItem As Windows.Forms.ToolStripMenuItem
        Friend WithEvents tsbCanclearNF As Windows.Forms.ToolStripButton
        Friend WithEvents lblErroDiretorio As Windows.Forms.Label
        Friend WithEvents ToolStrip3 As Windows.Forms.ToolStrip
        Friend WithEvents tsbLimparLogs As Windows.Forms.ToolStripButton
        Friend WithEvents tsbCarregarLogs As Windows.Forms.ToolStripButton
    End Class
End Namespace
