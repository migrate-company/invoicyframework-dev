Imports System.Runtime.InteropServices
Imports InvoicyFramework_EmissorOffline.InvoiCyFramework_EmissorOffLine.Interfaces

Namespace InvoiCyFramework_EmissorOffLine.Classes
    Public Class Relatorios
        Implements IRelatorios
        Public Function DocumentosPendentes() As String Implements IRelatorios.DocumentosPendentes
            Dim retornoPendentes = InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_RelatorioPendentes()
            Return Marshal.PtrToStringAnsi(retornoPendentes)
        End Function

        Public Function ExibirAlertas() As String Implements IRelatorios.ExibirAlertas
            Dim retornoAlertas = InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_Alertas()
            Return Marshal.PtrToStringAnsi(retornoAlertas)
        End Function

        Public Function ExibirLogs() As String Implements IRelatorios.ExibirLogs
            Dim retornoLogs = InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_Log()
            Return Marshal.PtrToStringAnsi(retornoLogs)
        End Function

        Public Function VersaoDll() As Integer Implements IRelatorios.VersaoDll
            Return InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_Versao()
        End Function
    End Class
End Namespace
