Imports System.Runtime.InteropServices
Imports InvoicyFramework_EmissorOffline.InvoiCyFramework_EmissorOffLine.Interfaces
Imports InvoicyFramework_EmissorOffline.InvoiCyFramework_EmissorOffLine.Lib

Namespace InvoiCyFramework_EmissorOffLine.Classes
    Public Class EmissaoDocumentos

        Implements IEmissaoDocumentos
        Private Shared retorno As IntPtr
        Private Shared sss As String
        Public Function EmitirContingencia(xmlEntrada As Byte()) As String Implements IEmissaoDocumentos.EmitirContingencia
            Dim retornContingencia As IntPtr = InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_EmiteContingencia(xmlEntrada)
            Return Marshal.PtrToStringAnsi(retornContingencia)
        End Function

        Public Function EmitirDocumento(xmlEntrada As Byte(), xmlParametro As Byte()) As String Implements IEmissaoDocumentos.EmitirDocumento

            Try
                'Dim
                retorno = InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_EmiteDocumento(xmlEntrada, xmlParametro)
                'Return System.Net.WebUtility.HtmlDecode(Marshal.PtrToStringAnsi(retorno))


                If retorno = IntPtr.Zero Then Return ""
                Dim len As Integer = 0

                While System.Runtime.InteropServices.Marshal.ReadByte(retorno, len) <> 0
                    len += 1
                End While

                If len = 0 Then Return ""
                Dim array As Byte() = New Byte(len - 1) {}
                System.Runtime.InteropServices.Marshal.Copy(retorno, array, 0, len)
                Return System.Text.Encoding.UTF8.GetString(array)


                'sss = Marshal.PtrToStringAnsi(retorno)
                'Return sss
            Catch ex As System.Exception

                Return String.Concat("erro: ", ex.Message)
            End Try



        End Function

        Public Function EnviarDocumentosPendentes() As Integer Implements IEmissaoDocumentos.EnviarDocumentosPendentes
            Return InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_EnviaDocumentosPendentes()
        End Function

        Public Function ExibirAlertas() As String Implements IEmissaoDocumentos.ExibirAlertas
            Dim retornoAlerta = InvoiCyFramework.InvoiCyFramework_Alertas()
            Return Marshal.PtrToStringAnsi(retornoAlerta)
        End Function

        Public Function ImprimeTexto(dadosEntrada As Byte()) As Integer Implements IEmissaoDocumentos.ImprimeTexto
            Return InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_ImprimeTexto(dadosEntrada)
        End Function


    End Class
End Namespace
