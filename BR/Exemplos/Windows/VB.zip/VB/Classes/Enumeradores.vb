Namespace InvoiCyFramework_EmissorOffLine.Classes
	Public Class Enumeradores
		Public Enum AmbienteEmissao
			AmbienteDocumento = 0
			Producao = 1
			Homologacao = 2
		End Enum


	End Class
End Namespace
