﻿Imports System.Runtime.InteropServices
Imports InvoicyFramework_EmissorOffline.InvoiCyFramework_EmissorOffLine.Classes
Imports InvoicyFramework_EmissorOffline.InvoiCyFramework_EmissorOffLine.Interfaces

Public Class Configuracoes
    Implements IConfiguracoes

    Public Function AlterarAmbiente(ambiente As Enumeradores.AmbienteEmissao) As Boolean Implements IConfiguracoes.AlterarAmbiente
        Return InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_AmbienteEmissao(CInt(ambiente)) = 1

    End Function

    Public Function ConfigurarDiretorio(diretorio As String) As Boolean Implements IConfiguracoes.ConfigurarDiretorio
        Return InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_ConfiguraDiretorio(diretorio) = 1

    End Function

    Public Function ConfigurarInvoicy(cnpj As String, chaveAcesso As String, chaveParceiro As String) As Boolean Implements IConfiguracoes.ConfigurarInvoicy
        Return InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_ConfiguraInvoicy(cnpj, chaveAcesso, chaveParceiro) = 1

    End Function

    Public Function ConfiguraSAT(codigoAtivacao As String, softwareHouseCNPJ As String, softwareHouseAssinatura As String) As Boolean Implements IConfiguracoes.ConfiguraSAT
        Return InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_ConfiguraSAT(codigoAtivacao, softwareHouseCNPJ, softwareHouseAssinatura) = 1

    End Function

    Public Function ConfiguraParametrosEmsisao(uf As Integer, idToken As Integer, csc As String, contingencia As Integer, urlQRCode As String, urlChaveAcesso As String) As Boolean Implements IConfiguracoes.ConfiguraParametrosEmsisao
        Return InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_InsereParametrosEmissao(uf, idToken, csc, contingencia, urlQRCode, urlChaveAcesso) = 1
    End Function

    Public Function ConfiguraEnderecoInvoicy(url As String) As Boolean Implements IConfiguracoes.ConfiguraEnderecoInvoicy
        Return InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_Configura("URLExecute", "https://homolog.invoicy.com.br/arecepcao.aspx") = 1
    End Function

    Public Function ConfiguracoesAdicionaisUF(UF As Integer, parametro As String, valor As String) As Integer Implements IConfiguracoes.ConfiguracoesAdicionaisUF
        Return InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_ConfiguraUF(UF, parametro, valor)
    End Function

    Public Function Configurar(parametro As String, valor As String) As Integer Implements IConfiguracoes.Configurar
        Return InvoiCyFramework_EmissorOffLine.[Lib].InvoiCyFramework.InvoiCyFramework_Configura(parametro, valor)
    End Function


    Public Function DefineSerieSequencialInicial(serie As Integer, sequencial As Integer) As Integer Implements IConfiguracoes.DefineSerieSequencialInicial
        If (serie > 0 And sequencial > 0) Then
            InvoiCyFramework_EmissorOffLine.Lib.InvoiCyFramework.InvoiCyFramework_Configura("SERIE_INICIAL_NFCE", serie.ToString())
            InvoiCyFramework_EmissorOffLine.Lib.InvoiCyFramework.InvoiCyFramework_Configura("SEQUENCIAL_INICIAL_NFCE", sequencial.ToString())
            Return 1
        Else
            Return 0
        End If
    End Function

    Public Function ObtemDataHoraUF(UF As Integer, aplicar As Integer) As String Implements IConfiguracoes.ObtemDataHoraUF
        Dim retornoDataHora = InvoiCyFramework_EmissorOffLine.Lib.InvoiCyFramework.InvoiCyFramework_ObtemDataHoraUF(UF, aplicar)
        Return Marshal.PtrToStringAnsi(retornoDataHora)
    End Function
End Class
