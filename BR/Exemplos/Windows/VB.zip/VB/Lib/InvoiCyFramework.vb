Imports System.Runtime.InteropServices

Namespace InvoiCyFramework_EmissorOffLine.Lib
    Public NotInheritable Class InvoiCyFramework
        Private Sub New()
        End Sub
        ''' <summary>
        ''' Alertas registrado pelo sistema
        ''' </summary>
        ''' <returns></returns>
        <DllImport("Lib/InvoiCyFramework.dll", CharSet:=CharSet.Ansi)>
        Public Shared Function InvoiCyFramework_Alertas() As IntPtr
        End Function



        ''' <summary>
        ''' Altera o ambiente de emissão
        ''' </summary>
        ''' <param name="ativa"> 1 = PRODUÇÃO. 2 = HOMOLOGAÇÃO</param>
        ''' <returns>retorna 1 em caso de sucesso</returns>
        <DllImport("Lib/InvoiCyFramework.dll", CharSet:=CharSet.Ansi)>
        Public Shared Function InvoiCyFramework_AmbienteEmissao(ativa As Integer) As Integer
        End Function



        ''' <summary>
        ''' Configurações gerais da biblioteca
        ''' </summary>
        ''' <param name="parametro">Nome do parâmetro</param>
        ''' <param name="valor">Valor do parâmetro</param>
        ''' <returns>Retorna 1 em caso de sucesso</returns>
        <DllImport("Lib/InvoiCyFramework.dll", CharSet:=CharSet.Ansi)>
        Public Shared Function InvoiCyFramework_Configura(parametro As String, valor As String) As Integer
        End Function



        ''' <summary>
        ''' Configura o diretório de armazenamento dos documentos
        ''' Chamar antes da emissão
        ''' </summary>
        ''' <param name="diretorio">Path do diretório</param>
        ''' <returns>retorna 1 em caso de sucesso</returns>
        <DllImport("Lib/InvoiCyFramework.dll", CharSet:=CharSet.Ansi)>
        Public Shared Function InvoiCyFramework_ConfiguraDiretorio(diretorio As String) As Integer
        End Function



        ''' <summary>
        ''' Configura o invoicy
        ''' </summary>
        ''' <param name="CNPJ">CNPJ - Somente números</param>
        ''' <param name="chaveAcesso">Chave de acesso</param>
        ''' <param name="chaveParceiro">Chave do parceiro</param>
        ''' <returns>Retorna 1 em caso de sucesso.</returns>
        <DllImport("Lib/InvoiCyFramework.dll", CharSet:=CharSet.Ansi)>
        Public Shared Function InvoiCyFramework_ConfiguraInvoicy(CNPJ As String, chaveAcesso As String, chaveParceiro As String) As Integer
        End Function



        ''' <summary>
        ''' Configura os parâmetros de emissão do SAT
        ''' </summary>
        ''' <param name="codigoAtivacao">Código de ativação</param>
        ''' <param name="softwareHouseCNPJ">Cnpj softwarehouse</param>
        ''' <param name="softwareHouseAssinatura">Assintatura softwarehouse</param>
        ''' <returns>Retorna 1 em caso de sucesso</returns>
        <DllImport("Lib/InvoiCyFramework.dll", CharSet:=CharSet.Ansi)>
        Public Shared Function InvoiCyFramework_ConfiguraSAT(codigoAtivacao As String, softwareHouseCNPJ As String, softwareHouseAssinatura As String) As Integer
        End Function



        ''' <summary>
        ''' Emite um documento fiscal ou envia um documento para armazenamento no invoiCy
        ''' </summary>
        ''' <param name="xmlEntrada">Dados em formato XML do documento que será emitido ou enviado para o invoiCy</param>
        ''' <param name="xmlParametro">Dados em formato XML do documento que será emitido ou enviado para o invoiCy</param>
        ''' <returns>Retorna XML com os dados da emissão ou da consulta</returns>
        <DllImport("Lib/InvoiCyFramework.dll", CharSet:=CharSet.Ansi, SetLastError:=True)>
        Public Shared Function InvoiCyFramework_EmiteDocumento(xmlEntrada As Byte(), xmlParametro As Byte()) As IntPtr
        End Function


        ''' <summary>
        ''' Configura os parâmetros de emissão para o contribuinte estadual
        ''' </summary>
        ''' <param name="UF">Número de dois dígitos referente ao código da UF que está sendo  configurada</param>
        ''' <param name="idToken">ID referente ao CSC</param>
        ''' <param name="CSC">Código CSC do contribuinte cadastrado na SEFAZ</param>
        ''' <param name="contingencia">Tipo de contingência do NFC-e sendo:
        '''    0 = Sem contingên cia,
        '''    1 = contingência offline,
        '''    2 = contingência SAT
        '''    </param>
        ''' <param name="consultaQRcode">URL de consulta do QRCode que será informado no DANFE</param>
        ''' <param name="consultaChave">URL de consulta da chave de acesso do documento que será informado no DANFE</param>
        ''' <returns>Retorna 1 em caso de sucesso</returns>
        <DllImport("Lib/InvoiCyFramework.dll", CharSet:=CharSet.Ansi)>
        Public Shared Function InvoiCyFramework_InsereParametrosEmissao(UF As Integer, idToken As Integer, CSC As String, contingencia As Integer, consultaQRcode As String, consultaChave As String) As Integer
        End Function



        ''' <summary>
        ''' Busca os dados do log da execução atual
        ''' </summary>
        ''' <returns>Busca os dados do log da execução atual</returns>
        <DllImport("Lib/InvoiCyFramework.dll", CharSet:=CharSet.Ansi)>
        Public Shared Function InvoiCyFramework_Log() As IntPtr
        End Function


        ''' <summary>
        ''' Recupera uma lista com todos os documentos ainda pendentes de envio
        ''' </summary>
        ''' <returns>string no formato XM L contendo listagem de documentos pendentes</returns>
        <DllImport("Lib/InvoiCyFramework.dll", CharSet:=CharSet.Ansi)>
        Public Shared Function InvoiCyFramework_RelatorioPendentes() As IntPtr
        End Function


        ''' <summary>
        ''' Versão da DLL
        ''' </summary>
        ''' <returns></returns>
        <DllImport("Lib/InvoiCyFramework.dll", CharSet:=CharSet.Ansi)>
        Public Shared Function InvoiCyFramework_Versao() As Integer
        End Function


        ''' <summary>
        ''' Descarta o documento informado e emite em contingência
        ''' </summary>
        ''' <param name="xmlEntrada">Documento XML</param>
        ''' <returns></returns>
        <DllImport("Lib/InvoiCyFramework.dll", CharSet:=CharSet.Ansi)>
        Public Shared Function InvoiCyFramework_EmiteContingencia(xmlEntrada As Byte()) As IntPtr
        End Function


        ''' <summary>
        ''' Força o envio dos documentos pendentes
        ''' </summary>
        ''' <returns></returns>
        <DllImport("Lib/InvoiCyFramework.dll", CharSet:=CharSet.Ansi)>
        Public Shared Function InvoiCyFramework_EnviaDocumentosPendentes() As Integer
        End Function


        <DllImport("Lib/InvoiCyFramework.dll", CharSet:=CharSet.Ansi)>
        Public Shared Function InvoiCyFramework_ConfiguraUF(UF As Integer, parametro As String, valor As String) As Integer
        End Function


        <DllImport("Lib/InvoiCyFramework.dll", CharSet:=CharSet.Ansi)>
        Public Shared Function InvoiCyFramework_ObtemDataHoraUF(ByVal UF As Integer, ByVal aplicar As Integer) As IntPtr
        End Function

        <DllImport("Lib/InvoiCyFramework.dll", CharSet:=CharSet.Ansi)>
        Public Shared Function InvoiCyFramework_ImprimeTexto(dadosEntrada As Byte()) As Integer
        End Function





    End Class
End Namespace
