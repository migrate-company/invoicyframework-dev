package com.migrate.framework.developers.elgin.minipdv;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import com.elgin.e1.Impressora.Android;
import com.elgin.e1.Impressora.Termica;
import com.migrate.gerentedocumento.Impressora.InterfaceElginMinipdv;

import java.util.Map;

public class PrinterServiceElginMiniPDV implements InterfaceElginMinipdv {
	public boolean pdvAndroid = false;
	public boolean minipdvElgin = false;
	public String numeroSérie = null;
	public String classeDispositivo = null;
	public String modeloDispositivo = null;
	public String versaoFirmware = null;
	private Activity activity = null;

	@Override
	public void setActivity(Activity activity) {
		try {
			this.activity = activity;
			Termica.setContext(activity);
			//1 Número de série
			this.numeroSérie = Android.GetDeviceInfo(1);
			//2	Classe do dispositivo
			this.classeDispositivo = Android.GetDeviceInfo(2);
			if (this.classeDispositivo.toUpperCase().contains("PDVANDROID")) this.pdvAndroid = true;
			//3	Modelo do dispositivo
			this.modeloDispositivo = Android.GetDeviceInfo(3);
			if (this.modeloDispositivo.toUpperCase().contains("MINIPDV M10"))
				this.minipdvElgin = true;
			//4	Versão de firmware
			this.versaoFirmware = Android.GetDeviceInfo(4);
		} catch (Exception e) {
			Log.i("ELGIN-MINIPDV", "Não foi possível obter recursos da biblioteca Elgin.");
		}
	}

	@Override
	public Boolean isValidDevice() {
		try {
			return (this.pdvAndroid && this.minipdvElgin) ? true : false;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public int printerStart() {
		if (this.isValidDevice()) {
			printerStop();
			return Termica.AbreConexaoImpressora(6, "M8", "", 0);
		} else { return com.elgin.e1.Impressora.Utilidades.CodigoErro.ERRO_FUNCAO_NAO_SUPORTADA; }
	}

	@Override
	public void printerStop() {
		if (this.isValidDevice()) Termica.FechaConexaoImpressora();
	}

	@Override
	public int AvancaLinhas(Map map) {
		if (this.isValidDevice()) {
			int lines = (Integer) map.get("quant");
			return Termica.AvancaPapel(lines);
		} else { return com.elgin.e1.Impressora.Utilidades.CodigoErro.ERRO_FUNCAO_NAO_SUPORTADA; }
	}

	@Override
	public int cutPaper(Map map) {
		if (this.isValidDevice()) {
			int lines = (Integer) map.get("quant");
			return Termica.Corte(lines);
		} else { return com.elgin.e1.Impressora.Utilidades.CodigoErro.ERRO_FUNCAO_NAO_SUPORTADA; }
	}

	@Override
	public int imprimeTexto(Map map) {
		if (this.isValidDevice()) {
			String text = (String) map.get("text");
			String align = (String) map.get("align");
			String font = (String) map.get("font");

			int fontSize = (Integer) map.get("fontSize");
			int alignValue = 0;
			int styleValue = 0;

			if (align.equals("Esquerda")) {
				alignValue = 0;
			} else if (align.equals("Centralizado")) {
				alignValue = 1;
			} else {
				alignValue = 2;
			}

			if (font.equals("FONT B")) {
				styleValue += 1;
			}
			if ((boolean) map.get("isUnderline")) {
				styleValue += 2;
			}
			if ((boolean) map.get("isBold")) {
				styleValue += 8;
			}

			return Termica.ImpressaoTexto(text, alignValue, styleValue, fontSize);
		} else { return com.elgin.e1.Impressora.Utilidades.CodigoErro.ERRO_FUNCAO_NAO_SUPORTADA; }
	}

	@Override
	public int imprimeLogotipo() {
		int id = this.activity.getResources().getIdentifier("logotipo","drawable", this.activity.getApplicationContext().getPackageName());

		if (id > 0) {
			try {
				Bitmap bitmap = BitmapFactory.decodeResource(this.activity.getApplicationContext().getResources(), id);
				return this.isValidDevice() ? Termica.ImprimeBitmap(bitmap) : com.elgin.e1.Impressora.Utilidades.CodigoErro.ERRO_FUNCAO_NAO_SUPORTADA;
			} catch (Exception e) {
				return com.elgin.e1.Impressora.Utilidades.CodigoErro.ERRO_FUNCAO_NAO_SUPORTADA;
			}
		} else {
			return com.elgin.e1.Impressora.Utilidades.CodigoErro.ARQUIVO_NAO_PODE_SER_ABERTO;
		}
	}

	@Override
	public int imprimeXMLNFCe(Map map) {
		if (this.isValidDevice()) {
			String xmlNFCe = (String) map.get("xmlNFCe");
			System.out.println(xmlNFCe);

			int indexcsc = (int) map.get("indexcsc");
			String csc = (String) map.get("csc");
			int param = (int) map.get("param");

			return Termica.ImprimeXMLNFCe(xmlNFCe, indexcsc, csc, param);
		} else {
			return com.elgin.e1.Impressora.Utilidades.CodigoErro.ERRO_FUNCAO_NAO_SUPORTADA;
		}
	}

	@Override
	public int abrirGaveta() {
		return this.isValidDevice() ? Termica.AbreGavetaElgin() : com.elgin.e1.Impressora.Utilidades.CodigoErro.ERRO_FUNCAO_NAO_SUPORTADA;
	}
}
