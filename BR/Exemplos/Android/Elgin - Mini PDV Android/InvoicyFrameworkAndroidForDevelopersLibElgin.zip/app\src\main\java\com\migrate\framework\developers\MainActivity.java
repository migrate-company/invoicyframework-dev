package com.migrate.framework.developers;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.migrate.framework.developers.vendas.Venda;

public class MainActivity extends AppCompatActivity {
    private Venda venda;
    private Button buttonEnviaDoc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.setTitle("Exemplo, InvoiCy Framework");

        // Instancia uma classe local para Vendas
        venda = new Venda(this);

        // Definição de Botão e Click para teste de emissão
        buttonEnviaDoc = findViewById(R.id.buttonEnviaDoc);
        buttonEnviaDoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String xmlEnvio = venda.xmlModelo();
                // Realiza a emissão, usando um modelo de XML com três itens
                venda.enviaDoc(xmlEnvio);
            }
        });
    }
}