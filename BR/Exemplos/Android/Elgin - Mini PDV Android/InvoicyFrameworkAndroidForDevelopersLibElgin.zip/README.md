Projeto destinado a demonstrar o uso da biblioteca do InvoiCy Framework Android, consumindo Interface de comunicação com a Biblioteca Elgin mini-PDV M8/M10


Para usar a biblioteca...

Necessário que "Project Structure/SDK Location" esteja definido para:
		. JDK location was moved to "Gradle Settings"
		- Gradle JDK. 11 version

Adicionando a biblioteca como dependência:

	. Copie o arquivo .aar da biblioteca do InvoiCy Framework para a pasta libs
		* Neste repositório, a biblioteca está em:
		InvoicyFrameworkAndroidForDevelopers/app/libs/
	
	. Copie os arquivos .aar da biblioteca Elgin Mini-pdv m8/m10 para a pasta libs
		* Neste repositório, estão sendo utilizados as versões disponíveis até a publicação deste exemplo
		InvoicyFrameworkAndroidForDevelopers/app/libs/
		

	. Clique File - Project Structure

	. Do lado esquerdo, selecione Dependencies

	. Em "All Dependencies", clique no botão com símbolo de "+"

	. Selecione "2 JAR/AAR Dependency"

	. Cole a localização/caminho onde está a biblioteca do InvoiCy Framework

	. Clique OK, para adicionar esta dependência ao projeto

	. Clique Ok, para salvar suas alterações

	
Dependências requeridas pela biblioteca InvoiCy Framework

    implementation 'com.google.zxing:core:3.3.0'
    api 'io.jsonwebtoken:jjwt-api:0.11.5'
    runtimeOnly 'io.jsonwebtoken:jjwt-impl:0.11.5'
    runtimeOnly('io.jsonwebtoken:jjwt-orgjson:0.11.5') {
        exclude group: 'org.json', module: 'json' //provided by Android natively
    }


Como usar:

	. A classe Minha Venda, é um modelo como deverá consumir os métodos da biblioteca InvoiCy
	Framework Android.
	
	. A classe Parametro, é um modelo como deverá inserir os parâmetros do emitente entre outros
	parâmetros de configuração.


![image](https://user-images.githubusercontent.com/101336870/177347948-ba23df6b-1707-4f6d-9b20-b643493d7a91.png)
