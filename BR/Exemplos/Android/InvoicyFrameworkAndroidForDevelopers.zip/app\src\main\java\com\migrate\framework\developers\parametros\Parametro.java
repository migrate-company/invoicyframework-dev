package com.migrate.framework.developers.parametros;

// modelo de parâmetros que devem ser adicionados ao XML de integração
public class Parametro {
    public Emitente emitente;
    public String impressoraActiva;
    public int ambiente;

    public class Emitente {
        //define uma classe para os dados de endereço
        public Ender ender;

        public String CNPJ;
        public String Nome;
        public String IE;
        public String CRT;
        public String chaveAcesso;
        public String chaveParceiro;
        public String mod;
        public String serie;
        public String nNF;
        public int UF;
        public int contingencia;

        public class Ender {
            public String xLgr;
            public String nro;
            public String xCpl;
            public String xBairro;
            public String cMun;
            public String xMun;
            public String UF;
            public String CEP;
            public String cPais;
            public String xPais;
            public String fone;
            public String fax;

            public Ender() {
            }
        }

        public Emitente() {
            // define os dados de endereço. Poderia vir de um database
            ender = new Ender();
        }
    }

    public Parametro() {
        emitente = new Emitente();
        this.ambiente = 2;
        this.impressoraActiva = "";
    }

    //  -------------------------------------------------------------------------------------------------------------------
    //  Este é o local onde seus dados do invoiCy, deverão ser informados
    //  O metodo abaixo é apenas uma sugestão para realizar testes antes aplicar seus conhecimentos em seu projeto oficial.
    //  -------------------------------------------------------------------------------------------------------------------
    public void LeituraDeConfiguracao() {

        // modelo de informações sobre o parceiro em uso
        this.emitente.CNPJ = "06354976000149";
        this.emitente.Nome = "MIGRATE";
        this.emitente.IE = "";
        this.emitente.CRT = "3";
        // definições de autorização na plataforma InvoiCy Migrate
        this.emitente.chaveParceiro = "";
        this.emitente.chaveAcesso = "";
        // definições de modelo e controle, paraemissão de documentos
        this.emitente.mod = "65";
        this.emitente.serie = "";
        this.emitente.nNF = "";
        // Definições de localidade e contingência
        this.emitente.UF = 43;
        this.emitente.contingencia = 1;
        // dados de endereço do emitente
        this.emitente.ender.xLgr = "RUA PADRE CACIQUE";
        this.emitente.ender.nro = "958";
        this.emitente.ender.xCpl = "02";
        this.emitente.ender.xBairro = "CENTRO";
        this.emitente.ender.cMun = "4321808";
        this.emitente.ender.xMun = "TRES DE MAIO";
        this.emitente.ender.UF = "RS";
        this.emitente.ender.CEP = "95960000";
        this.emitente.ender.cPais = "1058";
        this.emitente.ender.xPais = "BRASIL";
        this.emitente.ender.fone = "5137513322";
        this.emitente.ender.fax = "3335354830";
        // configuração do ambiente
        this.ambiente = 2;
        // formas de direcionar a saída de impressão
        /*
            1.  Impressora Ethernet:
                this.impressoraActiva = "SERVIDOR:192.168.0.104,9100";
            2.  Interface de impressão:
                this.impressoraActiva = "INTERFACE:"; //Quando aplicação implementa recursos de impressão

            * Para outras formas de impressão consulte o suporte de integração.
        */
//        this.impressoraActiva = "SERVIDOR:192.168.0.104,9100";
        this.impressoraActiva = "INTERFACE:"; //Quando aplicação implementa recursos de impressão
    }
}