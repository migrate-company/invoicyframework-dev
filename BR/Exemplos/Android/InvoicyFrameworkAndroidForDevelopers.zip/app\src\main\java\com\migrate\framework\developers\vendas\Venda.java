package com.migrate.framework.developers.vendas;

import android.graphics.Bitmap;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.print.PrintHelper;

import com.migrate.framework.developers.MainActivity;
import com.migrate.framework.developers.R;
import com.migrate.framework.developers.parametros.Parametro;
import com.migrate.gerentedocumento.InterfaceImpressora;
import com.migrate.gerentedocumento.InvoiCyFramework;
import com.migrate.gerentedocumento.LogIFW;
import com.migrate.gerentedocumento.Sistema.ContextoAplicativo;

public class Venda {
   private MainActivity ownerActivity;
   private InvoiCyFramework invoiCyFramework;
   private LogGer logger;
   private Impressora minhaImpressora;
   public static String xmlRetorno, xmlParametro;
   private String xmlEnvio;
   private int retorno = 0;
   private Parametro parametro; //apenas para organização do código, iremos definir uma classe para os parâmetros

   // Classe para salvar o Log de execução.
   public class LogGer implements LogIFW {
      public void Loga(String local, String mensagem) {
         insereLog(local + "-" + mensagem + "\n");
      }
   }

   public void insereLog(String mensagem) {
      final String logTexto = mensagem;

      ownerActivity.runOnUiThread(new Runnable() {
         @Override
         public void run() {
            TextView log = (TextView) ownerActivity.findViewById(R.id.logapp);
            ScrollView svLog = (ScrollView) ownerActivity.findViewById(R.id.svLogapp);

            if((log != null) && (logTexto != null)) {
               log.append(logTexto + "");
            }

            svLog.fullScroll(View.FOCUS_DOWN);
         }
      });
   }

   // Implementa classe para tratar a impressão da Danfe, quando não houver uma impressora definida.
   public class Impressora implements InterfaceImpressora {
      @Override
      public boolean ImprimeImagem(Bitmap bDocument) {
         String jobName;

         try {
            // Atribui o nNF do XML de retorno ao nome de arquivo...
            jobName = this.getNNF();

            if (jobName.trim().isEmpty())
               jobName = "Recibo NFCe";

            // Usa PrintHelper para salvar o arquivo da Danfe
            PrintHelper printHelper = new PrintHelper(ContextoAplicativo.contextoActivity);
            printHelper.setColorMode(PrintHelper.COLOR_MODE_MONOCHROME);
            printHelper.setScaleMode(PrintHelper.SCALE_MODE_FIT);
            printHelper.printBitmap(jobName, bDocument);

            return true;
         }
         catch (Exception e) {
            return false;
         }
      }

      // modelo para buscar o nNF no XML de retorno
      private String getNNF() {
         String sTextToFind, nNF;
         int iStartTextToFind;

         nNF = "";
         sTextToFind = ";DocNumero&gt;";
         iStartTextToFind = Venda.xmlRetorno.indexOf(sTextToFind);
         if (iStartTextToFind > 0) {
            iStartTextToFind += sTextToFind.length();

            sTextToFind = "&lt;/DocNumero";
            int iEndTextToFind = Venda.xmlRetorno.indexOf(sTextToFind);

            if (iEndTextToFind > 0)
               nNF =  Venda.xmlRetorno.substring(iStartTextToFind, iEndTextToFind);
         }

         return nNF;
      }
   }

   //Essencial para uso da biblioteca InvoiCy
   public Venda(MainActivity mainActivity) {
      ownerActivity = mainActivity;
      logger = new LogGer();
      minhaImpressora = new Impressora();
      String dadosDoc = null;

      // Definições essenciais.
      parametro = new Parametro();
      this.parametro.LeituraDeConfiguracao();

      this.configuraIFW();
   }

   public void configuraIFW() {
      // Instanciando biblioteca do InvoiCy Framework
      invoiCyFramework = new InvoiCyFramework(ownerActivity);

      // Configura log callback - Parâmetro pode ser nulo, ou não chamar o método de configuração.
      invoiCyFramework.ConfiguraLogCallback(logger);

      // Configura Impressora callback - Parâmetro pode ser nulo, ou não chamar o método de configuração.
      invoiCyFramework.ConfiguraInterfaceImpressora(minhaImpressora);

      // Configura dados acesso invoicy
      invoiCyFramework.ConfiguraInvoicy(this.parametro.emitente.CNPJ, this.parametro.emitente.chaveAcesso, this.parametro.emitente.chaveParceiro);

      // TIPO_CONTIUGENCIA : 0 - Desativada; 1 - Ativada; 2 - SAT
      invoiCyFramework.Configura("TIPO_CONTINGENCIA", String.valueOf(this.parametro.emitente.contingencia));

      // Configura impressora
      invoiCyFramework.Configura("IMPRESSORA_CANAL", this.parametro.impressoraActiva);

      // Define comunicação com o servidor de homologação
      invoiCyFramework.AmbienteEmissao(this.parametro.ambiente);
   }

   public void enviaDoc(final String _xmlEnvio) {
      Venda.xmlParametro = "<ParametrosAdicionais>" +
                              "<MensagemPromocional>Aproveite suas vendas com a Migrate</MensagemPromocional>" +
                              "<ImpressaoRecibo>1</ImpressaoRecibo>" +
                           "</ParametrosAdicionais>";

      new Thread() {
         @Override
         public void run() {
            try {
               // Local onde ocorre a emissão do documento contido no XML de envio, e Parametro
               xmlRetorno = invoiCyFramework.EmiteDocumento(_xmlEnvio, Venda.xmlParametro);

               // Gera um log com o XML de retorno. Lembre-se que o log é opcional.
               ContextoAplicativo.Loga("\n\n-----------------------------------------\nXML de retorno:\n-----------------------------------------\n" + xmlRetorno);
            }
            catch (Exception e) {
               java.io.StringWriter sw = new java.io.StringWriter();
               java.io.PrintWriter pw = new java.io.PrintWriter(sw);

               e.printStackTrace(pw);
               String sStackTrace = sw.toString();
               ContextoAplicativo.Loga("\n\nErro ao enviar:" + sStackTrace);
            }
         }
      }.start();
   }

   // Apenas monta um XML de exemplo ou modelo, contendo três itens alternando o CST, considerando o regime de Lucro Real e Presumido.
   // Lembre-se que este bloco é apenas uma referência.
   public String xmlModelo() {
      return "<Envio>" +
              "<ModeloDocumento>NFCe</ModeloDocumento>" +
              "<Versao>4.00</Versao>" +
              "<ide>"+
              "<cNF/>"+
              "<cUF>" + String.valueOf(this.parametro.emitente.UF)+ "</cUF>"+
              "<natOp>Venda</natOp>"+
              "<mod>" + this.parametro.emitente.mod + "</mod>"+
              "<serie>" + this.parametro.emitente.serie + "</serie>"+
              "<nNF>" + this.parametro.emitente.nNF + "</nNF>"+
              "<xxxdhEmi>2022-05-13T12:07:00</xxxdhEmi>"+
              "<fusoHorario>-03:00</fusoHorario>"+
              "<tpNf>1</tpNf>"+
              "<idDest>1</idDest>"+
              "<indFinal>1</indFinal>"+
              "<indPres>1</indPres>"+
              "<indIntermed>0</indIntermed>"+
              "<cMunFg>" + this.parametro.emitente.ender.cMun + "</cMunFg>"+
              "<tpImp>4</tpImp>"+
              "<tpEmis>1</tpEmis>"+
              "<tpAmb>" + String.valueOf(this.parametro.ambiente) + "</tpAmb>"+
              "<finNFe>1</finNFe>"+
              "</ide>"+
              "<emit>"+
              "<CNPJ_emit>" + this.parametro.emitente.CNPJ + "</CNPJ_emit>"+
              "<xNome>" + this.parametro.emitente.Nome + "</xNome>"+
              "<enderEmit>"+
              "<xLgr>" + this.parametro.emitente.ender.xLgr + "</xLgr>"+
              "<nro>" + this.parametro.emitente.ender.nro + "</nro>"+
              "<xCpl>" + this.parametro.emitente.ender.xCpl + "</xCpl>"+
              "<xBairro>" + this.parametro.emitente.ender.xBairro + "</xBairro>"+
              "<cMun>" + this.parametro.emitente.ender.cMun + "</cMun>"+
              "<xMun>" + this.parametro.emitente.ender.xMun + "</xMun>"+
              "<UF>" + this.parametro.emitente.ender.UF + "</UF>"+
              "<CEP>" + this.parametro.emitente.ender.CEP + "</CEP>"+
              "<cPais>" + this.parametro.emitente.ender.cPais + "</cPais>"+
              "<xPais>" + this.parametro.emitente.ender.xPais + "</xPais>"+
              "<fone>" + this.parametro.emitente.ender.fone + "</fone>"+
              "<fax>" + this.parametro.emitente.ender.fax + "</fax>"+
              "</enderEmit>"+
              "<IE>" + this.parametro.emitente.IE + "</IE>"+
              "<CRT>" + this.parametro.emitente.CRT + "</CRT>"+
              "</emit>"+
              "<det>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL</xProd>" +
              "<NCM>62093000</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>32.90</vUnCom>" +
              "<vProd>32.90</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>32.90</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>32.90</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>5.92</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>32.90</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>0.54</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>32.90</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>2.50</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>ESCOVA P MAMADEIRA AZUL 7241</xProd>" +
              "<NCM>96039000</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>14.90</vUnCom>" +
              "<vProd>14.90</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>14.90</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>14.90</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>2.68</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>14.90</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>0.25</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>14.90</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>1.13</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>ESCOVA P MAMADEIRA AZUL 7241</xProd>" +
              "<NCM>96039000</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>14.90</vUnCom>" +
              "<vProd>14.90</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>14.90</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>14.90</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>2.68</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>14.90</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>0.25</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>14.90</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>1.13</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>BALDE DE PRAIA MENINO 607</xProd>" +
              "<NCM>95030099</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>29.90</vUnCom>" +
              "<vProd>29.90</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>29.90</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>29.90</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>5.38</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>29.90</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>0.49</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>29.90</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>2.27</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>ESCOVA P MAMADEIRA AZUL 7241</xProd>" +
              "<NCM>96039000</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>14.90</vUnCom>" +
              "<vProd>14.90</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>14.90</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>14.90</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>2.68</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>14.90</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>0.25</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>14.90</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>1.13</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>CONJUNTO BRANDILI 53921 T 3 I21</xProd>" +
              "<NCM>61042200</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>69.93</vUnCom>" +
              "<vProd>69.93</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>69.93</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>69.93</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>12.59</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>69.93</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>1.15</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>69.93</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>5.31</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>ESCOVA P MAMADEIRA AZUL 7241</xProd>" +
              "<NCM>96039000</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>14.90</vUnCom>" +
              "<vProd>14.90</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>14.90</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>14.90</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>2.68</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>14.90</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>0.25</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>14.90</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>1.13</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>MOSQUITEIRO P CARRINHO 10002B</xProd>" +
              "<NCM>62093000</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>32.90</vUnCom>" +
              "<vProd>32.90</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>32.90</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>32.90</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>5.92</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>32.90</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>0.54</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>32.90</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>2.50</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>BALDE DE PRAIA MENINO 607</xProd>" +
              "<NCM>95030099</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>29.90</vUnCom>" +
              "<vProd>29.90</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>29.90</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>29.90</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>5.38</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>29.90</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>0.49</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>29.90</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>2.27</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>MOSQUITEIRO P CARRINHO 10002B</xProd>" +
              "<NCM>62093000</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>32.90</vUnCom>" +
              "<vProd>32.90</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>32.90</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>32.90</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>5.92</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>32.90</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>0.54</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>32.90</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>2.50</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>CONJUNTO BRANDILI 53921 T 3 I21</xProd>" +
              "<NCM>61042200</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>69.93</vUnCom>" +
              "<vProd>69.93</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>69.93</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>69.93</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>12.59</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>69.93</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>1.15</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>69.93</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>5.31</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>BALDE DE PRAIA MENINO 607</xProd>" +
              "<NCM>95030099</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>29.90</vUnCom>" +
              "<vProd>29.90</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>29.90</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>29.90</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>5.38</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>29.90</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>0.49</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>29.90</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>2.27</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>CONJUNTO BRANDILI 53921 T 3 I21</xProd>" +
              "<NCM>61042200</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>69.93</vUnCom>" +
              "<vProd>69.93</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>69.93</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>69.93</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>12.59</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>69.93</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>1.15</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>69.93</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>5.31</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>ESCOVA P MAMADEIRA AZUL 7241</xProd>" +
              "<NCM>96039000</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>14.90</vUnCom>" +
              "<vProd>14.90</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>14.90</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>14.90</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>2.68</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>14.90</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>0.25</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>14.90</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>1.13</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>31048</cProd>" +
              "<xProd>MACACAO LEMES 2327 T M I20</xProd>" +
              "<NCM>62093000</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>62.90</vUnCom>" +
              "<vProd>62.90</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>62.90</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>62.90</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>11.32</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>62.90</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>1.04</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>62.90</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>4.78</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>MOSQUITEIRO P CARRINHO 10002B</xProd>" +
              "<NCM>62093000</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>32.90</vUnCom>" +
              "<vProd>32.90</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>32.90</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>32.90</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>5.92</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>32.90</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>0.54</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>32.90</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>2.50</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>BALDE DE PRAIA MENINO 607</xProd>" +
              "<NCM>95030099</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>29.90</vUnCom>" +
              "<vProd>29.90</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>29.90</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>29.90</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>5.38</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>29.90</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>0.49</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>29.90</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>2.27</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>02561</cProd>" +
              "<xProd>MOSQUITEIRO P CARRINHO 10002B</xProd>" +
              "<NCM>62093000</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>32.90</vUnCom>" +
              "<vProd>32.90</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>32.90</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>32.90</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>5.92</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>32.90</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>0.54</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>32.90</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>2.50</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "<detItem>" +
              "<prod>" +
              "<cProd>31048</cProd>" +
              "<xProd>MACACAO LEMES 2327 T M I20</xProd>" +
              "<NCM>62093000</NCM>" +
              "<CFOP>5102</CFOP>" +
              "<uCOM>UN</uCOM>" +
              "<qCOM>1.000</qCOM>" +
              "<vUnCom>62.90</vUnCom>" +
              "<vProd>62.90</vProd>" +
              "<uTrib>UN</uTrib>" +
              "<qTrib>1.000</qTrib>" +
              "<vUnTrib>62.90</vUnTrib>" +
              "<indTot>1</indTot>" +
              "<cEAN>SEM GTIN</cEAN>" +
              "<cEANTrib>SEM GTIN</cEANTrib>" +
              "</prod>" +
              "<imposto>" +
              "<ICMS>" +
              "<ICMS00>" +
              "<orig>0</orig>" +
              "<CST>00</CST>" +
              "<modBC>3</modBC>" +
              "<vBC>62.90</vBC>" +
              "<pICMS>18.00</pICMS>" +
              "<vICMS_icms>11.32</vICMS_icms>" +
              "</ICMS00>" +
              "</ICMS>" +
              "<PIS>" +
              "<CST_pis>01</CST_pis>" +
              "<vBC_pis>62.90</vBC_pis>" +
              "<pPIS>1.65</pPIS>" +
              "<vPIS>1.04</vPIS>" +
              "</PIS>" +
              "<COFINS>" +
              "<CST_cofins>01</CST_cofins>" +
              "<vBC_cofins>62.90</vBC_cofins>" +
              "<pCOFINS>7.60</pCOFINS>" +
              "<vCOFINS>4.78</vCOFINS>" +
              "</COFINS>" +
              "</imposto>" +
              "</detItem>" +
              "</det>" +
              "<total>" +
              "<ICMStot>" +
              "<vBC_ttlnfe>694.19</vBC_ttlnfe>" +
              "<vICMS_ttlnfe>124.93</vICMS_ttlnfe>" +
              "<vICMSDeson_ttlnfe>0.00</vICMSDeson_ttlnfe>" +
              "<vBCST_ttlnfe>0.00</vBCST_ttlnfe>" +
              "<vST_ttlnfe>0.00</vST_ttlnfe>" +
              "<vProd_ttlnfe>694.19</vProd_ttlnfe>" +
              "<vFrete_ttlnfe>0.00</vFrete_ttlnfe>" +
              "<vSeg_ttlnfe>0.00</vSeg_ttlnfe>" +
              "<vDesc_ttlnfe>0.00</vDesc_ttlnfe>" +
              "<vII_ttlnfe>0.00</vII_ttlnfe>" +
              "<vIPI_ttlnfe>0.00</vIPI_ttlnfe>" +
              "<vPIS_ttlnfe>11.44</vPIS_ttlnfe>" +
              "<vCOFINS_ttlnfe>52.72</vCOFINS_ttlnfe>" +
              "<vOutro>0.00</vOutro>" +
              "<vNF>694.19</vNF>" +
              "<vTotTrib_ttlnfe>0.00</vTotTrib_ttlnfe>" +
              "<vFCP_ttlnfe>0.00</vFCP_ttlnfe>" +
              "<vFCPST_ttlnfe>0.00</vFCPST_ttlnfe>" +
              "<vFCPSTRet_ttlnfe>0.00</vFCPSTRet_ttlnfe>" +
              "<vIPIDevol_ttlnfe>0.00</vIPIDevol_ttlnfe>" +
              "</ICMStot>" +
              "</total>" +
              "<transp>" +
              "<modFrete>9</modFrete>" +
              "</transp>" +
              "<pag>" +
                 /*
                 "<pagItem>" +
                    "<indPag_pag>0</indPag_pag>" +
                    "<tPag>01</tPag>" +
                    "<vPag>694.19</vPag>" +
                 "</pagItem>" +
                 */
                  "<pagItem>" +
                     "<tPag>04</tPag>" +
                     "<vPag>285.00</vPag>" +
                     "<card>" +
                        "<tipoIntegracao>1</tipoIntegracao>" +
                        "<CNPJ_card>10726059000115</CNPJ_card>" +
                        "<tBand>01</tBand>" +
                        "<cAut>0606060394</cAut>" +
                     "</card>" +
                  "</pagItem>" +
                  "<pagItem>" +
                     "<tPag>03</tPag>" +
                     "<vPag>132.00</vPag>" +
                     "<card>" +
                        "<tipoIntegracao>1</tipoIntegracao>" +
                        "<CNPJ_card>10726059000115</CNPJ_card>" +
                        "<tBand>01</tBand>" +
                        "<cAut>0606060394</cAut>" +
                     "</card>" +
                  "</pagItem>" +
                  "<pagItem>" +
                     "<tPag>11</tPag>" +
                     "<vPag>47.00</vPag>" +
                  "</pagItem>" +
                  "<pagItem>" +
                     "<tPag>01</tPag>" +
                     "<vPag>129.00</vPag>" +
                  "</pagItem>" +
              "<pagItem>" +
               "<tPag>02</tPag>" +
                  "<vPag>101.19</vPag>" +
               "</pagItem>" +
              "</pag>" +
              "<vTroco>0.00</vTroco>" +
              "<infAdic>" +
              "<infAdFisco>Emitida em Homologação</infAdFisco>" +
              "</infAdic>" +
              "</Envio>";
   }
}