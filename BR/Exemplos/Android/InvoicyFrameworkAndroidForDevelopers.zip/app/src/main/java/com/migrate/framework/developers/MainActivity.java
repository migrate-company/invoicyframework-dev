package com.migrate.framework.developers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.migrate.framework.developers.vendas.Venda;

public class MainActivity extends AppCompatActivity {
    private Venda venda;
    private Button buttonEnviaDoc;
    private Button buttonCopyLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.setTitle("Exemplo, InvoiCy Framework");

        // Instancia uma classe local para Vendas
        venda = new Venda(this);

        // Definição de Botão e Click para teste de emissão
        buttonEnviaDoc = findViewById(R.id.buttonEnviaDoc);
        buttonEnviaDoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String xmlEnvio = venda.xmlModelo();
                // Realiza a emissão, usando um modelo de XML com três itens
                venda.enviaDoc(xmlEnvio);
            }
        });

        // Definição de Botão e Click para copiar texto de log para clipboard...
        buttonCopyLog = findViewById(R.id.buttonCopyLog);
        buttonCopyLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView logDeAtividade = findViewById(R.id.logapp);
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                // ClipData com o texto
                ClipData clip = ClipData.newPlainText("Texto copiado", logDeAtividade.getText().toString());
                // Copia o texto para a área de transferência
                clipboard.setPrimaryClip(clip);

                // mensagem de confirmação...
                Toast.makeText(getApplicationContext(), "Texto copiado para a área de transferência", Toast.LENGTH_LONG).show();
            }
        });
    }
}